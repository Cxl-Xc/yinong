package com.example.cxl.service.impl;

import com.example.cxl.entity.*;
import com.example.cxl.mapper.CommentMapper;
import com.example.cxl.service.ICommentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-05-18
 */
@Service
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment> implements ICommentService {

    @Resource
    private CommentMapper commentMapper;


    //根据userid查询
    @Override
    public String selectTokenByUserId(Integer userid) {
        return commentMapper.selectTokenByUserId(userid);
    }

    //插入帖子
    @Override
    public void insertAddComment(Integer userid,
                                 String commentText,
                                 String s,
                                 String s1,
                                 String s2,
                                 String s3,
                                 String s4,
                                 String s5,
                                 String s6,
                                 String s7,
                                 String s8, Integer commentCategoryId) {

        commentMapper.insertAddComment(userid, commentText, s, s1, s2, s3, s4, s5, s6, s7, s8, new Date(), commentCategoryId);

    }

    @Override
    public void insertAddComment2(Integer userid, String commentText) {
        commentMapper.insertAddComment2(userid, commentText, new Date());
    }

    @Override
    public Integer selectCommentCategoryIdBycommentCategoryClass(String commentCategoryClass) {
        return commentMapper.selectCommentCategoryIdBycommentCategoryClass(commentCategoryClass);
    }

    //评论加1
    @Override
    public void insertCommentsByCommentId(Integer commentId) {
        commentMapper.updateComments(commentId);
    }

    @Override
    public List<CommentVo> selectAllComment() {
        return commentMapper.selectAllComment();
    }

    @Override
    public String selectCommentCategoryClassByCommentCategoryId(String commentCategoryId) {
        return commentMapper.selectCommentCategoryClassByCommentCategoryId(commentCategoryId);
    }

    @Override
    public List<CommentVo> selectCommentByCommentCategoryId(Integer commentCategoryId) {
        return commentMapper.selectCommentByCommentCategoryId(commentCategoryId);
    }

    //向comment表插入数据
    @Override
    public void insertIntoComment(Comment comment) {
        commentMapper.insert(comment);
    }

    //向commentAddress插入数据
    @Override
    public void insertIntoCommentAddressByCommentId(Integer commentId) {
        commentMapper.insertIntoCommentAddressByCommentId(commentId);
    }

    //向commentAddress插入数据
    @Override
    public void insertIntoCommentAddressByCommentIdAndName(Integer commentId, String name) {
        commentMapper.insertIntoCommentAddressByCommentIdAndName(commentId, name);
    }

    //根据commentid向commentAddress查询数据
    @Override
    public List<CommentAddress> selectCommentAddressListByCommentId(Integer commentId) {
        return commentMapper.selectCommentAddressListByCommentId(commentId);
    }


    //根据id返回头像
    @Override
    public String selectPortraitAddressByuserId(Integer userid) {
        return commentMapper.selectPortraitAddressByuserId(userid);
    }

    @Override
    public List<CommentVo> selectCommentByCommentId(Integer commentId) {
        return commentMapper.selectCommentByCommentId(commentId);
    }

    @Override
    public String selectUserNameByUserId(Integer userid) {
        return commentMapper.selectUserNameByUserId(userid);
    }

    @Override
    public List<CollectsAndLikes> selectCommentIdByUserIdLikes(Integer userid) {
        return commentMapper.selectCommentIdByUserIdLikes(userid);
    }

    @Override
    public List<CollectsAndLikes> selectCommentIdByUserIdCollects(Integer userid) {
        return commentMapper.selectCommentIdByUserIdCollects(userid);
    }

    @Override
    public List<UserPortraitAddress> selectUserAddress(Integer userId) {
        return commentMapper.selectUserAddress(userId);
    }

    @Override
    public List<UserPortraitAddress> selectUserNameByUserId1(Integer userId) {
        return commentMapper.selectUserNameByUserId1(userId);
    }

    @Override
    public List<CommentVo> selectCommentByUserId(Integer userid) {
        return commentMapper.selectCommentByUserId(userid);
    }

    @Override
    public void deleteCommentIdByUserId(Integer userId) {
        commentMapper.deleteCommentIdByUserId(userId);
    }

    @Override
    //修改帖子的state为2
    public void deleteCommentIdByUserIdAndCommentId(Integer userId, Integer commentId) {
        commentMapper.deleteCommentIdByUserIdAndCommentId(userId, commentId);
    }

    @Override
    public List<CommentVo> selectAllCommentByIndex(Integer index) {

        Integer index2 = (index - 1) * 10;


        return commentMapper.selectAllCommentByIndex(index2);
    }

    @Override
    //查询全部数据的个数
    public Integer selectAllComment2(Integer index) {
        Integer index2 = (index - 1) * 10;
        return commentMapper.selectAllComment2(index2);
    }

    @Override
    public List<CommentVo> selectCommentByCommentCategoryIdByPage(Integer commentCategoryId, Integer index) {
        Integer index2 = (index - 1) * 10;
        return commentMapper.selectCommentByCommentCategoryIdByPage(commentCategoryId, index2);
    }

    @Override
    //先去查询全部的likes的commentId
    public List<Integer> selectLikesCommentByUserId(Integer userid) {
        return commentMapper.selectLikesCommentByUserId(userid);
    }

    //根据查询到的commentid去comment表查询全部信息
    @Override
    public CommentVo selectCommentByCommentIdForLikes(Integer integer) {
        return commentMapper.selectCommentByCommentIdForLikes(integer);
    }

    @Override
    //到collects表根据userid查询全部信息
    public List<Integer> selectCollectsCommentByUserId(Integer userid) {
        return commentMapper.selectCollectsCommentByUserId(userid);
    }

    @Override
    //删除comment   state为1
    public void updateCommentStateByUserIdAndCommentId(Integer userId, Integer commentId) {
        commentMapper.updateCommentStateByUserIdAndCommentId(userId, commentId);
    }

    @Override
    //删除这个帖子下面的子帖子
    public void updateCommentSonStateByUserIdAndCommentId(Integer userId, Integer commentId) {
        commentMapper.updateCommentSonStateByUserIdAndCommentId(userId, commentId);
    }

    @Override
    //删除这个帖子的collect
    public void updateCollectsStateByUserIdAndCommentId(Integer userId, Integer commentId) {
        commentMapper.updateCollectsStateByUserIdAndCommentId(userId, commentId);
    }

    //删除这个帖子下面的likes
    @Override
    public void updateLikesStateByUserIdAndCommentId(Integer userId, Integer commentId) {
        commentMapper.updateLikesStateByUserIdAndCommentId(userId, commentId);
    }

    @Override
    //查询总条数
    public Integer selectCount(Integer commentCategoryId) {
        return commentMapper.selectCounts(commentCategoryId);
    }

    @Override
    //查询全部总条数
    public Integer selectAllCounts() {
        return commentMapper.selectAllCounts();
    }

    @Override
    //查询全部删除的帖子
    public List<CommentVo> selectAllCommentByAdminDelete(Integer index) {

        Integer index2 = (index - 1) * 10;

        return commentMapper.selectAllCommentByAdminDelete(index2);
    }

    @Override
    //更具likes先后返回全部数据
    public List<CommentVo> selectAllCommentByIndexAndLikes(Integer index) {

        Integer index2 = (index - 1) * 10;

        return commentMapper.selectAllCommentByIndexAndLikes(index2);
    }

    @Override
    //修改帖子的state为0
    public void unDeleteCommentIdByAdminUserId(Integer commentId) {
        commentMapper.unDeleteCommentIdByAdminUserId(commentId);
    }

    @Override
    //修改帖子子帖子state为0
    public void updateCommentSonStateByUserIdAndCommentId2(Integer commentId) {
        commentMapper.updateCommentSonStateByUserIdAndCommentId2(commentId);
    }

    @Override
    //修改collect的state为0
    public void updateCollectsStateByUserIdAndCommentId2(Integer commentId) {
        commentMapper.updateCollectsStateByUserIdAndCommentId2(commentId);
    }

    @Override
    //修改likes的state为0
    public void updateLikesStateByUserIdAndCommentId2(Integer commentId) {
        commentMapper.updateLikesStateByUserIdAndCommentId2(commentId);
    }

    @Override
    public Integer selectAllCounts2() {
        return commentMapper.selectAllCount2();
    }

    @Override
//        //通过Id查询管理员删除的帖子
    public List<CommentVo> selectCommentByCommentIdAndAdminDelete(Integer commentId) {
        return commentMapper.selectCommentByCommentIdAndAdminDelete(commentId);
    }


}
