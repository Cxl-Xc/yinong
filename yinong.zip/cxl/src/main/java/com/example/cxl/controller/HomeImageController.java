package com.example.cxl.controller;


import com.example.cxl.service.ICommentService;
import com.example.cxl.service.IHomeImageService;
import com.example.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-06-08
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class HomeImageController {

    @Resource
    private IHomeImageService iHomeImageService;

    @Resource
    private ICommentService iCommentService;

    //获取首页图片
    @GetMapping("/selectHomeImageAddress")
    public Result selectHomeImageAddress() {

        //查询图片路径
        String HomeImageAddress = iHomeImageService.selectHomeImageAddress();

        return new Result(5, "查询成功", HomeImageAddress);

    }


    //修改首页图片
    @PostMapping("/changeHomeAddimage")
    public Result changeHomeAddimage(
            @RequestParam("userId") Integer userId,
            @RequestParam("files") MultipartFile file,
            @RequestParam("token") String token) throws IOException {

        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userId);

        if (token.equals(token2)) {


            String path = "/home/image/";//保存到指定的文件目录
            String path2 = "homeImage";//保存到指定的文件目录
            File dir = new File(path + path2);
            if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
            }

            file.transferTo(new File(dir.getAbsolutePath() + File.separator + file.getOriginalFilename()));
            String name = "/" + path2 + "/" + file.getOriginalFilename();//获取图片的名字

            //修改homeImageAddress的图片
            iHomeImageService.updateHomeImageAddress(name);
            return new Result(21, "修改成功，更新图片");


        } else {
            return new Result(-13, "登录失效，请重新登录");
        }
    }


}
