package com.example.cxl.service.impl;

import com.example.cxl.entity.User;
import com.example.cxl.entity.UserPortraitAddress;
import com.example.cxl.mapper.UserPortraitAddressMapper;
import com.example.cxl.service.IUserPortraitAddressService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-05-18
 */
@Service
public class UserPortraitAddressServiceImpl extends ServiceImpl<UserPortraitAddressMapper, UserPortraitAddress> implements IUserPortraitAddressService {


    @Resource
    private UserPortraitAddressMapper userPortraitAddressMapper;

    //先根据userId到user表查询是否有此用户
    @Override
    public User selectByUserId(Integer userid) {
        return userPortraitAddressMapper.selectByUserId(userid);
    }

    //插入地址
    @Override
    public void insertPortraitAddress(Integer userid, String name) {
        userPortraitAddressMapper.insertPortraitAddress(userid, name);
    }

    ////根据id查询他是否已经有头像
    @Override
    public String selectUserPortraitAddressById(Integer userid) {
        return userPortraitAddressMapper.selectUserPortraitAddressById(userid);
    }

    @Override
    public void updatePortraitAddress(Integer userid, String name) {
        userPortraitAddressMapper.updatePortraitAddress(userid, name);
    }
}
