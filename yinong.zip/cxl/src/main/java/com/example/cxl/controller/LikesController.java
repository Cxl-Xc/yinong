package com.example.cxl.controller;


import com.example.cxl.entity.Likes;
import com.example.cxl.entity.LikesVo;
import com.example.cxl.service.ICommentService;
import com.example.cxl.service.ILikesService;
import com.example.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import javax.annotation.Resource;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class LikesController {


    @Resource
    private ILikesService iLikesService;

    @Resource
    private ICommentService iCommentService;

    @PostMapping("/likes")
    public Result likes(@RequestBody LikesVo likesVo) {

        //先根据userid到comment表查询token的值
        String token = iCommentService.selectTokenByUserId(likesVo.getUserId());

        if (token.equals(likesVo.getToken())) {
            //先根据userid和commentid去likes表里查询是否有
            Likes likes = iLikesService.selectByUserIdAndCommentId(likesVo.getUserId(), likesVo.getCommentId());

            //根据查询到的值进行判断

            if (likes == null) {

                //向likes插入数据  并且实现comment表likes加1
                iLikesService.likesByUserIdAndCommentId(likesVo.getUserId(), likesVo.getCommentId());

                return new Result(11, "点赞成功 之前未点赞");
            } else {
                //说明数据库里面已经有点赞的记录  判断state   如果state=0  变为1  如果是1  变为0

                if (likes.getState().equals("0")) {
                    iLikesService.updateLikesState(likes.getCommentId());
                    return new Result(12, "修改成功 取消赞");
                } else {
                    iLikesService.updateLikesState2(likes.getCommentId());
                    return new Result(13, "修改成功 点赞");
                }


            }

        } else {
            return new Result(-13, "登录失效，请重新登录");
        }


    }
}
