package com.example.cxl.mapper;

import com.example.cxl.entity.PlantTechniqueSon;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
public interface PlantTechniqueSonMapper extends BaseMapper<PlantTechniqueSon> {


}
