package com.example.cxl.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.example.cxl.entity.CommentSon;
import com.example.cxl.entity.CommentSonVo1;
import com.example.cxl.entity.UserPortraitAddress;
import com.example.cxl.mapper.CommentSonMapper;
import com.example.cxl.service.ICommentSonService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
@Service
public class CommentSonServiceImpl extends ServiceImpl<CommentSonMapper, CommentSon> implements ICommentSonService {

    @Resource
    private CommentSonMapper commentSonMapper;

    @Override
    public void insertCommentByUserIdAndCommantId(Integer userId, Integer commentId, String commentSonText) {

        commentSonMapper.insertCommentByUserIdAndCommantId(userId, commentId, commentSonText, new Date());

    }

    @Override
    public List<CommentSonVo1> selectselectCommentSonByCommentId(Integer commentId) {
        return commentSonMapper.selectselectCommentSonByCommentId(commentId);
    }

    @Override
    public List<UserPortraitAddress> selectUserAddress(Integer userId) {
        return commentSonMapper.selectUserAddress(userId);
    }

    @Override
    //这里  肯定是有这个评论的 所以 直接删除 无需判断
    public void updateCommentSonState(String commentSonId, Integer userId) {
        commentSonMapper.updateCommentSonState(commentSonId, userId);
    }

    @Override
    //删除帖子数量
    public void updateComments(String commentSonId, Integer userId) {
        commentSonMapper.updateComments(commentSonId, userId);
    }

    @Override
    //查询到commentId
    public Integer selectCommentIdFromCommentSon(String commentSonId, Integer userId) {
        return commentSonMapper.selectCommentIdFroxmCommentSon(commentSonId, userId);
    }

    @Override
    //删除帖子数量
    public void updateCommentss(Integer commentId) {
        commentSonMapper.updateCommentss(commentId);
    }

    @Override
    //查询父帖子id
    public Integer selectCommentIdFromCommentSon1(String commentSonId) {
        return commentSonMapper.selectCommentIdFromCommentSon1(commentSonId);
    }

    @Override
    //获取下架的帖子的评论
    public List<CommentSonVo1> selectCommentSonByAmdinDeleteCommentId(Integer commentId) {
        return commentSonMapper.selectCommentSonByAmdinDeleteCommentId(commentId);
    }
}
