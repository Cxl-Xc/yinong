package com.example.cxl.mapper;

import com.example.cxl.entity.Pathogeny;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
public interface PathogenyMapper extends BaseMapper<Pathogeny> {

    //查询全部病因 分页显示
    List<Pathogeny> selectAlPathogenyByPage(Integer page2);

    //设置病因查询的state为1
    Integer updatePathogneyByPathogneyId(Integer pathogneyId);

    //分页like查询
    List<Pathogeny> selectPathogeny(Integer page2, String pathogenyTitle);

    //查询总条数
    Integer selectCountPathogeny();

    //查询总条数 like查询
    Integer selectCountPathogenyByLike(String pathogenyTitle);
}
