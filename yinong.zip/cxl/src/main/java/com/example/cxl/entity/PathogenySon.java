package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("pathogenySon")
public class PathogenySon implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 病因Id
     */
    @TableId("pathogenyId")
    private Integer pathogenyId;

    /**
     * 病因子标题
     */
    @TableField("pathogenySonTitle")
    private String pathogenySonTitle;

    /**
     * 病因子内容
     */
    @TableField("pathogenySonText")
    private String pathogenySonText;

    /**
     * 病因子图片
     */
    @TableField("pathogenySonImageAddress")
    private String pathogenySonImageAddress;


}
