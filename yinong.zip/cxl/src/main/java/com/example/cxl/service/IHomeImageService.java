package com.example.cxl.service;

import com.example.cxl.entity.HomeImage;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-08
 */
public interface IHomeImageService extends IService<HomeImage> {

    //查询图片路径
    String selectHomeImageAddress();

    //修改homeImageAddress的图片
    void updateHomeImageAddress(String name);
}
