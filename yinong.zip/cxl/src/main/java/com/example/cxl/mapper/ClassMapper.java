package com.example.cxl.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.cxl.entity.Class;
import com.example.cxl.entity.Image;
import com.example.cxl.entity.ImageVo;
import com.example.cxl.entity.ImageVo2;

import java.util.List;


/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-05-16
 */
public interface ClassMapper extends BaseMapper<Class> {

    List<Class> selectAll();

    //根据类别查询到类别id
    Integer seletByClassName(String className);

    List<ImageVo> selectByClassId(Integer classId);

    String selectByImageId(Integer imageId);

    List<ImageVo2> selectByClassId2(Image imageId);

    String selectByClassId3(String classId);


    List<ImageVo> selectByClassIdPage(Integer classId, Integer index);

    Integer selectAllImage(Integer classId);

    //查询总类别数
    Integer selectCountClass();


    //查询全部粮食数量
    Integer selectLangShiCount();

    //查询蔬菜
    Integer selectShuCai();

    //查询果类
    Integer selectGouLei();

    //查询药用
    Integer selectYaoYong();

    //查询油料
    Integer selectYouLiao();
}
