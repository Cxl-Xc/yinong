package com.example.cxl.service.impl;

import com.example.cxl.entity.Remind;
import com.example.cxl.mapper.RemindMapper;
import com.example.cxl.service.IRemindService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-05-30
 */
@Service
public class RemindServiceImpl extends ServiceImpl<RemindMapper, Remind> implements IRemindService {

    @Resource
    private RemindMapper remindMapper;

    @Override
    //查询state
    public String selectStataByUserId(Integer userid) {
        return remindMapper.selectStataByUserId(userid);
    }

    @Override
    //设置为1
    public void setStateByUserId(Integer userid) {
        remindMapper.setStateByUserId(userid);
    }

    @Override
    //设置为0
    public void setStateByUserId1(Integer userid) {
        remindMapper.setStateByUserId1(userid);
    }

    @Override
    //设置浇水时间
    public void setRemindTime(Integer userId, String time) {
        remindMapper.setRemindTime(userId, time);
    }

    @Override
    //查询之前设置的时间
    public String selectRemindIdTime(Integer userid) {
        return remindMapper.selectRemindIdTime(userid);
    }

    @Override
    //查询全部时间段
    public List<String> getAllRemindIdTime() {
        return remindMapper.getAllRemindIdTime();
    }
}
