package com.example.cxl.service.impl;

import com.example.cxl.entity.FeedBack;
import com.example.cxl.mapper.FeedBackMapper;
import com.example.cxl.service.IFeedBackService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
@Service
public class FeedBackServiceImpl extends ServiceImpl<FeedBackMapper, FeedBack> implements IFeedBackService {

    @Resource
    private FeedBackMapper feedBackMapper;

    @Override
    //提交反馈
    public Object insertFeedBack(Integer userId, String feedBakcText, String phoneOrEmail) {

        FeedBack feedBack=new FeedBack();
        feedBack.setFeedBakcText(feedBakcText);
        feedBack.setUserId(userId);
        feedBack.setPhoneOrEmail(phoneOrEmail);
        feedBack.setState("0");

        return feedBackMapper.insert(feedBack);
    }

    @Override
    //查询全部反馈 分页显示
    public List<FeedBack> selectAllFeedBack(Integer page) {

        Integer page2 = (page - 1) * 10;
        return feedBackMapper.selectAllFeedBack(page2);
    }

    @Override
    //修改反馈state
    public void updateFeedBackState(Integer feedBackId) {
        feedBackMapper.updateFeedBackState(feedBackId);
    }

    @Override
    //查询总条数
    public Integer selectCount() {
        return feedBackMapper.selectCount1();
    }
}
