package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("user_Portrait_Address")
public class UserPortraitAddress implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 用户id
     */

    private String username;

    /**
     * 用户头像地址
     */
    @TableField("portrait_Address")
    private String portraitAddress;


}
