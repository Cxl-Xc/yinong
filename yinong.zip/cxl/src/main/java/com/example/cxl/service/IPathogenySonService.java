package com.example.cxl.service;

import com.example.cxl.entity.PathogenySon;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
public interface IPathogenySonService extends IService<PathogenySon> {

}
