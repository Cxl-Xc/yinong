package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.io.StringReader;


/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class UserIdAndCommentIdAndToken implements Serializable {


    /**
     * 类别id
     */

    private Integer userId;


    private Integer commentId;

    private String token;


}
