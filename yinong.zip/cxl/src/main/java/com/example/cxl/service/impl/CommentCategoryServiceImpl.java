package com.example.cxl.service.impl;

import com.example.cxl.entity.CommentCategory;
import com.example.cxl.mapper.CommentCategoryMapper;
import com.example.cxl.service.ICommentCategoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-05-30
 */
@Service
public class CommentCategoryServiceImpl extends ServiceImpl<CommentCategoryMapper, CommentCategory> implements ICommentCategoryService {

    @Resource
    private CommentCategoryMapper commentCategoryMapper;

    @Override
    //查询全部comment类别
    public List<CommentCategory> selectAllCommentCategory() {
        return commentCategoryMapper.selectAllCommentCategory();
    }

    @Override
    //查询经验
    public Integer selectJinYan() {
        return commentCategoryMapper.selectJinYan();
    }

    @Override
    //查询投稿
    public Integer selectTouGao() {
        return commentCategoryMapper.selectTouGao();
    }

    @Override
    //查询求助
    public Integer selectQiuZhu() {
        return commentCategoryMapper.selectQiuZhu();
    }
}
