package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Value;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-04-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 用户id
     */
    @TableId(value = "userid", type = IdType.AUTO)
    private Integer userid;

    /**
     * 用户名称
     */
    private String username;

    /**
     * 用户密码
     */
    private String password;

    /**
     * ‘1’代表删除，'0'代表未删除
     */

    @TableLogic //逻辑删除字段  1代表删除 0代表未删除
    @TableField(fill = FieldFill.INSERT)
    private String state;

    /**
     * 用户绑定邮箱
     */
    private String email;

    /**
     * 用户token
     */
    private String token;


}
