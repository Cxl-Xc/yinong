package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("commentAddress")
public class CommentAddress implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * commentId
     */
    @TableField("commentId")
    private Integer commentId;

    /**
     * comment地址
     */
    @TableField("commentAddress")
    private String commentAddress;


}
