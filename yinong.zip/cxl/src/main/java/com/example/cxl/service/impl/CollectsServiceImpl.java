package com.example.cxl.service.impl;

import com.example.cxl.entity.Collects;
import com.example.cxl.mapper.CollectsMapper;
import com.example.cxl.service.ICollectsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
@Service
public class CollectsServiceImpl extends ServiceImpl<CollectsMapper, Collects> implements ICollectsService {

    @Resource
    private CollectsMapper collectsMapper;

    @Override
    //先根据userid和commentid去collects表里查询是否有
    public Collects selectByUserIdAndCommentId(Integer userId, Integer commentId) {
        return collectsMapper.selectByUserIdAndCommentId(userId, commentId);
    }

    @Override
    public void collectsByUserIdAndCommentId(Integer userId, Integer commentId) {
        collectsMapper.collectsByUserIdAndCommentId(userId, commentId, new Date());
        collectsMapper.updateCommentCollectsByCommentId(commentId);

    }

    @Override
    public void updateCollectsState(Integer commentId) {
        collectsMapper.updateCollectsState(commentId);
        collectsMapper.updateCommentCollectsByCommentId1(commentId);

    }

    @Override
    public void updateCollectsState2(Integer commentId) {
        collectsMapper.updateCollectsState2(commentId);
        collectsMapper.updateCommentCollectsByCommentId(commentId);
    }
}
