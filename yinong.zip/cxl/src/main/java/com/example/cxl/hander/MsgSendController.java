package com.example.cxl.hander;

import com.example.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.util.Random;

/**
 * @Author:szm
 * @Date: 2022/4/28
 * //发送qq邮箱验证
 */
@RestController
@RequiredArgsConstructor
public class MsgSendController {

    private final JavaMailSender mailSender; //注入QQ发送邮件的bean

    /**
     * 给qq邮箱发送消息
     */
    @GetMapping("/qqMsgSend")
    public Result qqMsgSend(String qq) {


        try {

            MimeMessage mimeMessage = this.mailSender.createMimeMessage();
            MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
            message.setFrom("chenxiaoli0111@qq.com");//设置发件qq邮箱


            message.setTo(qq);    //设置收件人
            message.setSubject("验证码");//设置标题

            //随机生成4位验证码
            Random r = new Random();
            int msg = r.nextInt(8000) + 1999;


            message.setText("你更改密码的的验证码是:" + msg);    //第二个参数true表示使用HTML语言来编写邮件
            this.mailSender.send(mimeMessage);

            return new Result(1, msg);

        } catch (Exception e) {

            return new Result(-1, "邮箱格式错误");

        }


    }
}

