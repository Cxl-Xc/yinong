package com.example.cxl.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-05-22
 */
@Controller
@RequestMapping("/commentAddress/comment-address")
public class CommentAddressController {

}
