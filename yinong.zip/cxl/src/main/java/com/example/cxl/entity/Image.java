package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Image implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 图片的自增id
     */
    @TableId(value = "imageId", type = IdType.AUTO)
    private Integer imageId;

    /**
     * 图片上用户id
     */
    private Integer userid;

    /**
     * 图片标题
     */
    @TableField("imageTitle")
    private String imageTitle;

    /**
     * 图片内容
     */
    @TableField("imageText")
    private String imageText;

    /**
     * 类别id
     */
    @TableField("classId")
    private Integer classId;

    /**
     * ‘1’代表删除，'0'代表未删除
     */
    @TableLogic //逻辑删除字段  1代表删除 0代表未删除
    @TableField(fill = FieldFill.INSERT)
    private String state;

    /**
     * 上传时间
     */
    private Date date;

    /**
     * 详细内容
     */
    @TableField("imageContent")
    private String imageContent;


}
