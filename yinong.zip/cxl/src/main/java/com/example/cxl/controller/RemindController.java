package com.example.cxl.controller;


import com.example.cxl.entity.User;
import com.example.cxl.service.IRemindService;
import com.example.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-05-30
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class RemindController {

    @Resource
    private IRemindService iRemindService;

    //设置是否开启浇水
    @PostMapping("/setRemindStateByUserId")
    public Result setRemindStateByUserId(@RequestBody User user) {


        if (user.getUserid() == null) {

            return new Result(-17, "参数为空", user.getUserid());
        } else {
            //先查询state
            String state = iRemindService.selectStataByUserId(user.getUserid());


            //判断state的状态
            if (state.equals("0")) {
                //设置为1
                iRemindService.setStateByUserId(user.getUserid());
                return new Result(24, "设置state为1", 1);


            } else {
                //设置为0
                iRemindService.setStateByUserId1(user.getUserid());
                return new Result(25, "设置state为0", 0);
            }
        }


    }

    //设置浇水时间
    @PostMapping("/setRemindTime")
    public Result setRemindTime(@RequestParam Integer userId, @RequestParam String time) {

        //设置浇水时间
        iRemindService.setRemindTime(userId, time);

        return new Result(26, "设置浇水时间成功");


    }


    //传用户id查询是1还是0
    @PostMapping("/selectStateByUserId")
    public Result selectStateByUserId(@RequestBody User user) {

        //先查询state
        String state = iRemindService.selectStataByUserId(user.getUserid());


        if (state == null) {

            return new Result(-18, "查询state失败");

        } else {

            //查询之前设置的时间
            String remindIdTime = iRemindService.selectRemindIdTime(user.getUserid());

            Map<String, String> remind = new HashMap<>();

            remind.put("state", state);
            remind.put("remindIdTime", remindIdTime);

            return new Result(27, "查询state成功", remind);


        }

    }


}
