package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("plantTechniqueSon")
public class PlantTechniqueSon implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 种植技巧id
     */
    @TableId("plantTechniqueId")
    private Integer plantTechniqueId;

    /**
     * 标题
     */
    @TableField("plantTechniqueSonTitle")
    private String plantTechniqueSonTitle;

    /**
     * 内容
     */
    @TableField("plantTechniqueSonText")
    private String plantTechniqueSonText;

    /**
     * 图片
     */
    @TableField("plantTechniqueSonImageAddress")
    private String plantTechniqueSonImageAddress;

    private String state;

}
