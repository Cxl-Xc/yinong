package com.example.cxl.controller;


import com.example.cxl.entity.FeedBack;
import com.example.cxl.service.ICommentService;
import com.example.cxl.service.IFeedBackService;
import com.example.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class FeedBackController {

    @Resource
    private IFeedBackService iFeedBackService;

    @Resource
    private ICommentService iCommentService;

    //提交反馈
    @PostMapping("/insertFeedBack")
    public Result insertFeedBack(@RequestParam Integer userId,
                                 @RequestParam String  token,
                                 @RequestParam String   feedBakcText,
                                 @RequestParam String   phoneOrEmail
                                 ){

        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userId);

        if (token.equals(token2)) {
            return new Result(36, "提交反馈成功",iFeedBackService.insertFeedBack(userId,feedBakcText,phoneOrEmail));
        }else{
            return new Result(-13, "登录失效，请重新登录");
        }


    }

    //查询全部反馈 分页显示
    @GetMapping("/selectAllFeedBackByPage")
    public Result selectAllFeedBackByPage(@RequestParam Integer page) {


        //分页查询全部反馈
        List<FeedBack> feedBackList=iFeedBackService.selectAllFeedBack(page);

        Map<String,List> feedBackListAndCount=new HashMap<>();

        List<Integer> count=new ArrayList<>();
        //插入总条数
        count.add(iFeedBackService.selectCount());

        feedBackListAndCount.put("feedBackList",feedBackList);
        feedBackListAndCount.put("Count", count);


        //判断是否有数据
        if (feedBackList.size() < 10) {

            return new Result(23, "查询成功已是最后一页", feedBackListAndCount);

        } else {

            return new Result(5, "查询成功", feedBackListAndCount);

        }


    }


    //删除反馈
    @PostMapping("/updateFeedBackState")
    public Result updateFeedBackState(@RequestParam Integer userId,
                                      @RequestParam String  token,
                                      @RequestParam Integer feedBackId
                                      ){


        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userId);

        if (token.equals(token2)) {
            iFeedBackService.updateFeedBackState(feedBackId);
            return new Result(37, "删除反馈成功");
        }else{
            return new Result(-13, "登录失效，请重新登录");
        }


    }





}
