package com.example.cxl.service;

import com.example.cxl.entity.Remind;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-05-30
 */
public interface IRemindService extends IService<Remind> {

    //查询state
    String selectStataByUserId(Integer userid);

    //设置为1
    void setStateByUserId(Integer userid);

    //设置为0
    void setStateByUserId1(Integer userid);

    //设置浇水时间
    void setRemindTime(Integer userId, String time);

    //查询之前设置的时间
    String selectRemindIdTime(Integer userid);

    //查询全部时间段
    List<String> getAllRemindIdTime();
}
