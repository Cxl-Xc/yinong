package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("commentCategory")
public class CommentCategory implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 帖子类别Id
     */
    @TableId(value = "commentCategoryId", type = IdType.AUTO)
    private Integer commentCategoryId;

    /**
     * 帖子类别
     */
    @TableField("commentCategoryClass")
    private String commentCategoryClass;

    /**
     * ‘1’代表删除，'0'代表未删除
     */
    private String state;


}
