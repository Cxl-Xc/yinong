package com.example.cxl.service;

import com.example.cxl.entity.Collects;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
public interface ICollectsService extends IService<Collects> {

    //先根据userid和commentid去collects表里查询是否有
    Collects selectByUserIdAndCommentId(Integer userId, Integer commentId);


    void collectsByUserIdAndCommentId(Integer userId, Integer commentId);

    void updateCollectsState(Integer commentId);

    void updateCollectsState2(Integer commentId);
}
