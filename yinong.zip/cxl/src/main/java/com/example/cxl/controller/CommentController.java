package com.example.cxl.controller;


import com.example.cxl.entity.*;
import com.example.cxl.service.ICommentService;
import com.example.cxl.service.IUserService;
import com.example.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-05-18
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class CommentController {

    @Resource
    private ICommentService iCommentService;


    //根据用户id和token 返回这个用户id点赞的所有帖子的全部信息
    @PostMapping("/selectCommentByIdAndTokenAndLike")
    public Result selectCommentByIdAndTokenAndLike(@RequestBody User user) {

        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(user.getUserid());

        if (token2.equals(user.getToken())) {
            //先去查询全部的likes的commentId
            List<Integer> likes = iCommentService.selectLikesCommentByUserId(user.getUserid());

            //根据查询到的commentid去comment表查询全部信息
            List<CommentVo> commentVoListByLikes = new ArrayList<>();
            for (int i = 0; i < likes.size(); i++) {
                commentVoListByLikes.add(iCommentService.selectCommentByCommentIdForLikes(likes.get(i)));

            }


            //for循环设置每条的CommentAddressList
            commentVoListByLikes.forEach(i -> i.setCommentAddressList(iCommentService.selectCommentAddressListByCommentId(i.getCommentId())));
            commentVoListByLikes.forEach(i -> i.setCommentAddressList(iCommentService.selectCommentAddressListByCommentId(i.getCommentId())));
            commentVoListByLikes.forEach(i -> i.setPortraitAddress(iCommentService.selectPortraitAddressByuserId(i.getUserid())));
            commentVoListByLikes.forEach(i -> i.setUsername(iCommentService.selectUserNameByUserId(i.getUserid())));

            //查询点赞
            List<CollectsAndLikes> likess = iCommentService.selectCommentIdByUserIdLikes(user.getUserid());
            //查询收藏
            List<CollectsAndLikes> collects = iCommentService.selectCommentIdByUserIdCollects(user.getUserid());

            Map<String, List> commentsAndLikesAndColletcs = new HashMap<>();

            commentsAndLikesAndColletcs.put("commentVoListByLikes", commentVoListByLikes);
            commentsAndLikesAndColletcs.put("collects", collects);
            commentsAndLikesAndColletcs.put("likes", likess);


            return new Result(5, "查询成功", commentsAndLikesAndColletcs);


        } else {
            return new Result(-13, "登录失效，请重新登录");
        }
    }

    //根据用户id和token 返回这个用户id收藏的所有帖子的全部信息
    @PostMapping("/selectCommentByIdAndTokenAndCollect")
    public Result selectCommentByIdAndTokenAndCollect(@RequestBody User user) {

        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(user.getUserid());

        if (token2.equals(user.getToken())) {
            //先去查询全部的collect的commentId
            List<Integer> collects = iCommentService.selectCollectsCommentByUserId(user.getUserid());

            //根据查询到的commentid去comment表查询全部信息
            List<CommentVo> commentVoListByCollects = new ArrayList<>();
            for (int i = 0; i < collects.size(); i++) {
                commentVoListByCollects.add(iCommentService.selectCommentByCommentIdForLikes(collects.get(i)));

            }

            //for循环设置每条的CommentAddressList
            commentVoListByCollects.forEach(i -> i.setCommentAddressList(iCommentService.selectCommentAddressListByCommentId(i.getCommentId())));
            commentVoListByCollects.forEach(i -> i.setCommentAddressList(iCommentService.selectCommentAddressListByCommentId(i.getCommentId())));
            commentVoListByCollects.forEach(i -> i.setPortraitAddress(iCommentService.selectPortraitAddressByuserId(i.getUserid())));
            commentVoListByCollects.forEach(i -> i.setUsername(iCommentService.selectUserNameByUserId(i.getUserid())));

            List<CollectsAndLikes> likess = iCommentService.selectCommentIdByUserIdLikes(user.getUserid());

            List<CollectsAndLikes> collectss = iCommentService.selectCommentIdByUserIdCollects(user.getUserid());

            Map<String, List> commentsAndLikesAndColletcs = new HashMap<>();

            commentsAndLikesAndColletcs.put("commentVoListByCollects", commentVoListByCollects);
            commentsAndLikesAndColletcs.put("collects", collectss);
            commentsAndLikesAndColletcs.put("likes", likess);


            return new Result(5, "查询成功", commentsAndLikesAndColletcs);


        } else {
            return new Result(-13, "登录失效，请重新登录");
        }
    }


    //根据userid  commentid  token删除帖子
    @PostMapping("/deleteCommentIdByUserId")
    public Result deleteCommentIdByUserId(@RequestBody UserIdAndCommentIdAndToken userIdAndCommentIdAndToken) {


        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userIdAndCommentIdAndToken.getUserId());

        if (token2.equals(userIdAndCommentIdAndToken.getToken())) {

            iCommentService.updateCommentStateByUserIdAndCommentId(userIdAndCommentIdAndToken.getUserId()
                    , userIdAndCommentIdAndToken.getCommentId());

            //删除与帖子相关的

            //1  删除这个帖子的子帖子
            iCommentService.updateCommentSonStateByUserIdAndCommentId(userIdAndCommentIdAndToken.getUserId(),
                    userIdAndCommentIdAndToken.getCommentId());

            //2 删除这个帖子的collects
            iCommentService.updateCollectsStateByUserIdAndCommentId(userIdAndCommentIdAndToken.getUserId(),
                    userIdAndCommentIdAndToken.getCommentId());

            //3 删除这个帖子下面的likes
            iCommentService.updateLikesStateByUserIdAndCommentId(userIdAndCommentIdAndToken.getUserId(),
                    userIdAndCommentIdAndToken.getCommentId());


            return new Result(22, "删除成功");

        } else {
            return new Result(-13, "登录失效，请重新登录");
        }

    }

    //根据userid  commentid  token删除帖子  管理员删除
    @PostMapping("/deleteCommentIdByAdminUserId")
    public Result deleteCommentIdByAdminUserId(@RequestBody UserIdAndCommentIdAndToken userIdAndCommentIdAndToken) {


        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userIdAndCommentIdAndToken.getUserId());

        if (token2.equals(userIdAndCommentIdAndToken.getToken())) {

            //修改帖子的state为2
            iCommentService.deleteCommentIdByUserIdAndCommentId(userIdAndCommentIdAndToken.getUserId()
                    , userIdAndCommentIdAndToken.getCommentId());

            //删除与帖子相关的

//            //1  删除这个帖子的子帖子
//            iCommentService.updateCommentSonStateByUserIdAndCommentId(userIdAndCommentIdAndToken.getUserId(),
//                    userIdAndCommentIdAndToken.getCommentId());

            //2 删除这个帖子的collects
            iCommentService.updateCollectsStateByUserIdAndCommentId(userIdAndCommentIdAndToken.getUserId(),
                    userIdAndCommentIdAndToken.getCommentId());

            //3 删除这个帖子下面的likes
            iCommentService.updateLikesStateByUserIdAndCommentId(userIdAndCommentIdAndToken.getUserId(),
                    userIdAndCommentIdAndToken.getCommentId());


            return new Result(30, "下架成功");

        } else {
            return new Result(-13, "登录失效，请重新登录");
        }

    }

    //根据userid  commentid  token上架帖子  管理员上架
    @PostMapping("/unDeleteCommentIdByAdminUserId")
    public Result unDeleteCommentIdByAdminUserId(@RequestBody UserIdAndCommentIdAndToken userIdAndCommentIdAndToken) {

        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userIdAndCommentIdAndToken.getUserId());

        if (token2.equals(userIdAndCommentIdAndToken.getToken())) {

            //修改帖子的state为0
            iCommentService.unDeleteCommentIdByAdminUserId(userIdAndCommentIdAndToken.getCommentId());

            //删除与帖子相关的

//            //1  修改帖子子帖子state
//            iCommentService.updateCommentSonStateByUserIdAndCommentId2(
//                    userIdAndCommentIdAndToken.getCommentId());

            //2 修改这个帖子的collects
            iCommentService.updateCollectsStateByUserIdAndCommentId2(
                    userIdAndCommentIdAndToken.getCommentId());

            //3 修改这个帖子下面的likes
            iCommentService.updateLikesStateByUserIdAndCommentId2(
                    userIdAndCommentIdAndToken.getCommentId());

            return new Result(29, "上架成功");

        } else {
            return new Result(-13, "登录失效，请重新登录");
        }

    }


    //查询全部下架的帖子
    @GetMapping("/selectAllCommentByAdminDelete")
    public Result selectAllCommentByAdminDelete(@RequestParam Integer userid, @RequestParam Integer index) {
        //查询全部下架的帖子
        List<CommentVo> comments = iCommentService.selectAllCommentByAdminDelete(index);
        //查询全部数据的个数
//        Integer all=iCommentService.selectAllComment2(index);

        comments.forEach(i -> i.setCommentCategoryId(iCommentService.selectCommentCategoryClassByCommentCategoryId(i.getCommentCategoryId())));
        comments.forEach(i -> i.setCommentAddressList(iCommentService.selectCommentAddressListByCommentId(i.getCommentId())));
        comments.forEach(i -> i.setPortraitAddress(iCommentService.selectPortraitAddressByuserId(i.getUserid())));
        comments.forEach(i -> i.setUsername(iCommentService.selectUserNameByUserId(i.getUserid())));

        List<CollectsAndLikes> likes = iCommentService.selectCommentIdByUserIdLikes(userid);

        List<CollectsAndLikes> collects = iCommentService.selectCommentIdByUserIdCollects(userid);

        //查询全部的帖子
        List<Integer> counts = new ArrayList<>();
        counts.add(iCommentService.selectAllCounts());

        Map<String, List> commentsAndLikesAndColletcs = new HashMap<>();

        commentsAndLikesAndColletcs.put("comments", comments);
        commentsAndLikesAndColletcs.put("collects", collects);
        commentsAndLikesAndColletcs.put("likes", likes);
        commentsAndLikesAndColletcs.put("counts", counts);

        if (comments.size() < 10) {

            return new Result(23, "查询成功已是最后一页", commentsAndLikesAndColletcs);

        } else {

            return new Result(5, "查询成功", commentsAndLikesAndColletcs);

        }

    }

    //通过Id查询管理员删除的帖子
    @PostMapping("/selectCommentByCommentIdAndAdminDelete")
    public Result selectCommentByCommentIdAndAdminDelete(@RequestBody Comment comment) {
        //通过Id查询管理员删除的帖子
        List<CommentVo> comments = iCommentService.selectCommentByCommentIdAndAdminDelete(comment.getCommentId());

        comments.forEach(i -> i.setCommentCategoryId(iCommentService.selectCommentCategoryClassByCommentCategoryId(i.getCommentCategoryId())));
        comments.forEach(i -> i.setCommentAddressList(iCommentService.selectCommentAddressListByCommentId(i.getCommentId())));
        comments.forEach(i -> i.setPortraitAddress(iCommentService.selectPortraitAddressByuserId(i.getUserid())));
        comments.forEach(i -> i.setUsername(iCommentService.selectUserNameByUserId(i.getUserid())));
        return new Result(5, "查询成功", comments);

    }


    //通过Id查询帖子
    @PostMapping("/selectCommentByCommentId")
    public Result selectCommentByCommentId(@RequestBody Comment comment) {

        List<CommentVo> comments = iCommentService.selectCommentByCommentId(comment.getCommentId());

        comments.forEach(i -> i.setCommentCategoryId(iCommentService.selectCommentCategoryClassByCommentCategoryId(i.getCommentCategoryId())));
        comments.forEach(i -> i.setCommentAddressList(iCommentService.selectCommentAddressListByCommentId(i.getCommentId())));
        comments.forEach(i -> i.setPortraitAddress(iCommentService.selectPortraitAddressByuserId(i.getUserid())));
        comments.forEach(i -> i.setUsername(iCommentService.selectUserNameByUserId(i.getUserid())));
        return new Result(5, "查询成功", comments);


    }


    //查询全部的帖子
    @GetMapping("/selectAllComment")
    public Result selectAllComment(@RequestParam Integer userid, @RequestParam Integer index) {

        List<CommentVo> comments = iCommentService.selectAllCommentByIndex(index);
        //查询全部数据的个数
//        Integer all=iCommentService.selectAllComment2(index);

        comments.forEach(i -> i.setCommentCategoryId(iCommentService.selectCommentCategoryClassByCommentCategoryId(i.getCommentCategoryId())));
        comments.forEach(i -> i.setCommentAddressList(iCommentService.selectCommentAddressListByCommentId(i.getCommentId())));
        comments.forEach(i -> i.setPortraitAddress(iCommentService.selectPortraitAddressByuserId(i.getUserid())));
        comments.forEach(i -> i.setUsername(iCommentService.selectUserNameByUserId(i.getUserid())));

        List<CollectsAndLikes> likes = iCommentService.selectCommentIdByUserIdLikes(userid);

        List<CollectsAndLikes> collects = iCommentService.selectCommentIdByUserIdCollects(userid);

        //查询全部的帖子
        List<Integer> counts = new ArrayList<>();
        counts.add(iCommentService.selectAllCounts2());

        Map<String, List> commentsAndLikesAndColletcs = new HashMap<>();

        commentsAndLikesAndColletcs.put("comments", comments);
        commentsAndLikesAndColletcs.put("collects", collects);
        commentsAndLikesAndColletcs.put("likes", likes);
        commentsAndLikesAndColletcs.put("counts", counts);

        if (comments.size() < 10) {

            return new Result(23, "查询成功已是最后一页", commentsAndLikesAndColletcs);

        } else {

            return new Result(5, "查询成功", commentsAndLikesAndColletcs);

        }

    }


    //查询全部的帖子按likes返回
    @GetMapping("/selectAllCommentOrderByLikes")
    public Result selectAllCommentOrderByLikes(@RequestParam Integer userid, @RequestParam Integer index) {

        //更具likes先后返回全部数据
        List<CommentVo> comments = iCommentService.selectAllCommentByIndexAndLikes(index);

        comments.forEach(i -> i.setCommentCategoryId(iCommentService.selectCommentCategoryClassByCommentCategoryId(i.getCommentCategoryId())));
        comments.forEach(i -> i.setCommentAddressList(iCommentService.selectCommentAddressListByCommentId(i.getCommentId())));
        comments.forEach(i -> i.setPortraitAddress(iCommentService.selectPortraitAddressByuserId(i.getUserid())));
        comments.forEach(i -> i.setUsername(iCommentService.selectUserNameByUserId(i.getUserid())));

        List<CollectsAndLikes> likes = iCommentService.selectCommentIdByUserIdLikes(userid);

        List<CollectsAndLikes> collects = iCommentService.selectCommentIdByUserIdCollects(userid);

        //查询全部的帖子
        List<Integer> counts = new ArrayList<>();
        counts.add(iCommentService.selectAllCounts2());

        Map<String, List> commentsAndLikesAndColletcs = new HashMap<>();

        commentsAndLikesAndColletcs.put("comments", comments);
        commentsAndLikesAndColletcs.put("collects", collects);
        commentsAndLikesAndColletcs.put("likes", likes);
        commentsAndLikesAndColletcs.put("counts", counts);

        if (comments.size() < 10) {

            return new Result(23, "查询成功已是最后一页", commentsAndLikesAndColletcs);

        } else {

            return new Result(5, "查询成功", commentsAndLikesAndColletcs);

        }

    }

    //根据类别查询帖子
    @PostMapping("/selectCommentByCommentCategoryClass")
    public Result selectCommentByCommentCategoryClass(@RequestBody CommentVo2 comment) {
        //查询类别id
        Integer commentCategoryId = iCommentService.selectCommentCategoryIdBycommentCategoryClass(comment.getCommentCategoryId());

        if (commentCategoryId == null) {

            return new Result(-16, "查询失败，未查询到该类");

        } else {


            List<CommentVo> comments = iCommentService.selectCommentByCommentCategoryIdByPage(commentCategoryId, comment.getIndex());
            comments.forEach(i -> i.setCommentAddressList(iCommentService.selectCommentAddressListByCommentId(i.getCommentId())));
            comments.forEach(i -> i.setPortraitAddress(iCommentService.selectPortraitAddressByuserId(i.getUserid())));
            comments.forEach(i -> i.setUsername(iCommentService.selectUserNameByUserId(i.getUserid())));

            List<CollectsAndLikes> likes = iCommentService.selectCommentIdByUserIdLikes(comment.getUserid());

            List<CollectsAndLikes> collects = iCommentService.selectCommentIdByUserIdCollects(comment.getUserid());

            //查询总条数
            List<Integer> counts = new ArrayList<>();
            counts.add(iCommentService.selectCount(commentCategoryId));

            Map<String, List> commentsAndLikesAndColletcs = new HashMap<>();


            commentsAndLikesAndColletcs.put("comments", comments);
            commentsAndLikesAndColletcs.put("collects", collects);
            commentsAndLikesAndColletcs.put("likes", likes);
            commentsAndLikesAndColletcs.put("counts", counts);

            if (comments.size() < 10) {

                return new Result(23, "查询成功已是最后一页", commentsAndLikesAndColletcs);

            } else {

                return new Result(5, "查询成功", commentsAndLikesAndColletcs);
            }


        }
    }


    //根据userid和token查询全部的帖子
    @PostMapping("selectCommentsByUserId")
    public Result selectCommentsByUserId(@RequestBody User user) {
        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(user.getUserid());

        if (token2.equals(user.getToken())) {
            List<CommentVo> comments = iCommentService.selectCommentByUserId(user.getUserid());
            comments.forEach(i -> i.setCommentAddressList(iCommentService.selectCommentAddressListByCommentId(i.getCommentId())));
            comments.forEach(i -> i.setPortraitAddress(iCommentService.selectPortraitAddressByuserId(i.getUserid())));
            comments.forEach(i -> i.setUsername(iCommentService.selectUserNameByUserId(i.getUserid())));

            List<CollectsAndLikes> likes = iCommentService.selectCommentIdByUserIdLikes(user.getUserid());

            List<CollectsAndLikes> collects = iCommentService.selectCommentIdByUserIdCollects(user.getUserid());

            Map<String, List> commentsAndLikesAndColletcs = new HashMap<>();

            commentsAndLikesAndColletcs.put("comments", comments);
            commentsAndLikesAndColletcs.put("collects", collects);
            commentsAndLikesAndColletcs.put("likes", likes);

            return new Result(5, "查询成功", commentsAndLikesAndColletcs);


        } else {
            return new Result(-13, "登录失效，请重新登录");
        }
    }


    //先发布无图片的帖子
    @PostMapping("/commentQianZhi")
    public Result commentQianZhi(@RequestParam("userId") Integer userid,
                                 @RequestParam(value = "commentText", defaultValue = "") String commentText,
                                 @RequestParam("token") String token,
                                 @RequestParam("commentCategoryClass") String commentCategoryClass) {

        System.out.println("commentQianZhi");

        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userid);
        //根据commentCategoryClass到commentCategory表里查询是否有这个类别 返回类别id
        Integer commentCategoryId = iCommentService.selectCommentCategoryIdBycommentCategoryClass(commentCategoryClass);

        if (token.equals(token2)) {
            if (commentCategoryId == null) {
                return new Result(-15, "发帖类别不存在");
            } else {


                Comment comment = new Comment();
                comment.setUserid(userid);
                comment.setCommentText(commentText);
                comment.setCommentTime(new Date());
                comment.setLikes("0");
                comment.setCollects("0");
                comment.setComments("0");
                comment.setState("0");
                comment.setCommentCategoryId(Integer.toString(commentCategoryId));

                iCommentService.insertIntoComment(comment);

                return new Result(17, "插入comment成功", comment.getCommentId());

            }

        } else {
            return new Result(-13, "登录失效，请重新登录");
        }
    }

    //实现上传图片
    @PostMapping("/commentAddImage")
    public Result commentAddImage(@RequestParam("userId") Integer userid,
                                  @RequestParam("commentId") Integer commentId,
                                  @RequestParam("token") String token,
                                  @RequestParam(value = "files") MultipartFile files) throws IOException {

        System.out.println("commentAddImage");

        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userid);

        if (token.equals(token2)) {

            if (files.isEmpty()) {
                //空的  直接向commentAddress插入数据

                iCommentService.insertIntoCommentAddressByCommentId(commentId);
                return new Result(18, "根据commentId向commentAddress插入数据成功");

            } else {


                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");

                String path = "/home/image/";//保存到指定的文件目录
                String path2 = "comment/" + userid + "/" + commentId + "的图片" + df.format(new Date());//保存到指定的文件目录
                File dir = new File(path + path2);
                if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                    dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
                }

                files.transferTo(new File(dir.getAbsolutePath() + File.separator + files.getOriginalFilename()));
                String name = "/" + path2 + "/" + files.getOriginalFilename();//获取图片的名字

                //向commentAddress插入数据
                iCommentService.insertIntoCommentAddressByCommentIdAndName(commentId, name);
                return new Result(18, "根据commentId向commentAddress插入数据成功");

            }


        } else {
            return new Result(-13, "登录失效，请重新登录");
        }


    }


    //实现发布帖子
    @PostMapping("/comment1")
    public Result comment(@RequestParam("userId") Integer userid,
                          @RequestParam(value = "commentText", defaultValue = "") String commentText,
                          @RequestParam(value = "files") MultipartFile[] files,
                          @RequestParam("token") String token,
                          @RequestParam("commentCategoryClass") String commentCategoryClass
    ) throws Exception {


        for (int i = 0; i < files.length; i++) {
            System.out.println(files[i]);
        }


        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userid);
        //根据commentCategoryClass到commentCategory表里查询是否有这个类别 返回类别id
        Integer commentCategoryId = iCommentService.selectCommentCategoryIdBycommentCategoryClass(commentCategoryClass);


        //判断token  如果不一样 返回失效 一样 进行评论
        if (token2.equals(token)) {

            if (commentCategoryId != null) {

                String filesIsEmpty = "isnotnull";
                for (MultipartFile file : files) {    //for循环遍历数组 将图片存储到指定路径

                    if (file.getOriginalFilename().isEmpty()) {
                        filesIsEmpty = "isnull";
                    }


                }


                if (commentText.isEmpty() && filesIsEmpty.equals("isnull")) {


                    return new Result(-14, "commentText和files不能同时为空");

                } else if (commentText.isEmpty() && filesIsEmpty.equals("isnotnull")) {


                    //        String path = "/home/image/" ;//保存到指定的文件目录
                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");

                    String path = "/home/image/";//保存到指定的文件目录
                    String path2 = "comment/" + userid + "/" + commentText + df.format(new Date());//保存到指定的文件目录
                    File dir = new File(path + path2);
                    if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                        dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
                    }

                    String name = "";//定义 获取图片的名字的变量 name
                    List<String> commentAddress = new ArrayList<>();
                    for (int i = 0; i < 9; i++) {

                        commentAddress.add(null);

                    }
                    List<String> commentAddress2 = new ArrayList<>();
                    for (MultipartFile file : files) {    //for循环遍历数组 将图片存储到指定路径

                        file.transferTo(new File(dir.getAbsolutePath() + File.separator + file.getOriginalFilename()));
                        name = "/" + path2 + "/" + file.getOriginalFilename();//获取图片的名字

                        //向addimage表添加与add表addid关联的addimage路径

                        commentAddress2.add(name);

                    }

                    for (int i = 0; i < commentAddress2.size(); i++) {

                        commentAddress.set(i, commentAddress2.get(i));


                    }

                    //向comment插入帖子数据

                    iCommentService.insertAddComment(userid,
                            commentText,
                            commentAddress.get(0),
                            commentAddress.get(1),
                            commentAddress.get(2),
                            commentAddress.get(3),
                            commentAddress.get(4),
                            commentAddress.get(5),
                            commentAddress.get(6),
                            commentAddress.get(7),
                            commentAddress.get(8), commentCategoryId);


                    return new Result(7, "发贴成功,commentText为空,files不为空");

                } else if (!commentText.isEmpty() && filesIsEmpty.equals("isnull")) {


                    iCommentService.insertAddComment2(userid, commentText);
                    return new Result(8, "发贴成功,commentText不为空,files为空");

                } else if (!commentText.isEmpty() && filesIsEmpty.equals("isnotnull")) {

                    //        String path = "/home/image/" ;//保存到指定的文件目录
                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");

                    String path = "/home/image/";//保存到指定的文件目录
                    String path2 = "comment/" + userid + "/" + commentText + df.format(new Date());//保存到指定的文件目录
                    File dir = new File(path + path2);
                    if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                        dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
                    }

                    String name = "";//定义 获取图片的名字的变量 name
                    List<String> commentAddress = new ArrayList<>();
                    for (int i = 0; i < 9; i++) {

                        commentAddress.add(null);

                    }
                    List<String> commentAddress2 = new ArrayList<>();
                    for (MultipartFile file : files) {    //for循环遍历数组 将图片存储到指定路径

                        file.transferTo(new File(dir.getAbsolutePath() + File.separator + file.getOriginalFilename()));
                        name = "/" + path2 + "/" + file.getOriginalFilename();//获取图片的名字

                        //向addimage表添加与add表addid关联的addimage路径

                        commentAddress2.add(name);

                    }

                    for (int i = 0; i < commentAddress2.size(); i++) {

                        commentAddress.set(i, commentAddress2.get(i));


                    }

                    //向comment插入帖子数据

                    iCommentService.insertAddComment(userid,
                            commentText,
                            commentAddress.get(0),
                            commentAddress.get(1),
                            commentAddress.get(2),
                            commentAddress.get(3),
                            commentAddress.get(4),
                            commentAddress.get(5),
                            commentAddress.get(6),
                            commentAddress.get(7),
                            commentAddress.get(8), commentCategoryId);


                    return new Result(9, "发贴成功,commentTextAndfiles都不空");

                }

                return new Result(7, "发贴成功");
            } else {
                return new Result(-15, "发帖类别不存在");
            }


        } else {
            return new Result(-13, "登录失效，请重新登录");
        }


    }


}
