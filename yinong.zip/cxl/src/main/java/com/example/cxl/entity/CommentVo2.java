package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class CommentVo2 implements Serializable {


    /**
     * 评论者id
     */
    private Integer userid;


    /**
     * 评论数
     */
    private String comments;


    private Integer index;


    private String commentCategoryId;


}
