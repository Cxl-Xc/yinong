package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;

import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.TableField;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-06-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("plantTechnique")
public class PlantTechnique implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 种植技巧id
     */
    @TableId(value = "plantTechniqueId", type = IdType.AUTO)
    private Integer plantTechniqueId;

    /**
     * 种植标题
     */
    @TableField("plantTechniqueTitle")
    private String plantTechniqueTitle;

    /**
     * 种植内容
     */
    @TableField("plantTechniqueText")
    private String plantTechniqueText;

    /**
     * 种植首页图片
     */
    @TableField("plantTechniqueImageAddress")
    private String plantTechniqueImageAddress;

    /**
     * 0是未删除 1是删除
     */
    private String state;

    /**
     * 上传时间
     */
    private Date time;


}
