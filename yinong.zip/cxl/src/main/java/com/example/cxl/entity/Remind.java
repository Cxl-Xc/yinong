package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Remind implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 提醒id
     */
    @TableId(value = "remindId", type = IdType.AUTO)
    private Integer remindId;

    /**
     * 用户id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 提醒时间
     */
    @TableField("remindIdTime")
    private String remindIdTime;

    private String state;


}
