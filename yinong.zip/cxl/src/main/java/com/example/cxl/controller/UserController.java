package com.example.cxl.controller;


import com.example.cxl.entity.*;


import com.example.cxl.service.ICommentService;
import com.example.cxl.service.IUserService;
import com.example.cxl.utils.Result;

import lombok.RequiredArgsConstructor;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.mail.internet.MimeMessage;
import java.util.*;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-04-29
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class UserController {

    //注入
    @Resource
    private IUserService userService;

    @Resource
    private ICommentService iCommentService;

    private final JavaMailSender mailSender; //注入QQ发送邮件的bean


    //修改管理员权限
    @PostMapping("/updateUserRole")
    public Result updateUserRole(@RequestParam Integer userId,
                                 @RequestParam String token,
                                 @RequestParam Integer adminUserId
                                 ){

        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userId);

        if (token.equals(token2)) {

            //先判断userId对应的身份
            String userRole=userService.selectUserRoleByUserId(userId);

            if (userRole.equals("superAdmin")){

                //查询adminUserId的权限
                String adminRole=userService.selectUserRoleByUserId(adminUserId);
                //是admin  变为unAdmin
                if (adminRole.equals("admin")) {
                    userService.updateUserRoleToUnAdmin(adminUserId);
                    return new Result(39, "修改成功 变为umAdmin");
                    //是unAdmin变成admin
                } else if (adminRole.equals("unAdmin")) {
                    userService.updateUserRoleToAdmin(adminUserId);
                    return new Result(40, "修改成功 变为admin");
                }

            }else{
                return new Result(-22, "不是超级管理员不可操作" );
            }

            return new Result(-22, "不是超级管理员不可操作" );

        }else{

            return new Result(-13, "登录失效，请重新登录");

        }



    }



    //查询全部管理员用户和被下权限的管理员用户
    @GetMapping("/selectAllAdminAndUnAdmin")
    public Result selectAllAdminAndUnAdmin(){

        //查询全部管理员账号和被下权限的管理员账号的Id
        List<UserSelectRoleAdmin> userSelectRoleAdminList=userService.selectAllAdminAndUnAdminId();
        //设置用户头像
        userSelectRoleAdminList.forEach(i -> i.setPortraitAddress(userService.getPortraitAddress(i.getUserid())));
        //设置用户名
        userSelectRoleAdminList.forEach(i ->i.setUsername(userService.getUsername(i.getUserid())));

        return new Result(38, "查询管理员和被下权限的管理员成功", userSelectRoleAdminList);
    }


    //删除用户
    @PostMapping("/updateUserState")
    public Result updateUserState(@RequestParam Integer adminUserId,
                                  @RequestParam String token,
                                  @RequestParam Integer userId
                                  ){


        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(adminUserId);

        if (token.equals(token2)) {
            //先查询管理员权限
            String adminRole=userService.selectUserRole(adminUserId);
            //查询用户权限
            String userRole=userService.selectUserRole(userId);

            if (adminRole.equals("superAdmin") && (userRole.equals("user") || userRole.equals("admin"))){
                //删除用户权限
                userService.deleteUserRole(userId);
                userService.updateUserState(userId);
                return new Result(33, "超级管理员删除普通用户或管理员成功");

            }else if (adminRole.equals("admin") && userRole.equals("user")){
                //删除用户权限
                userService.deleteUserRole(userId);
                userService.updateUserState(userId);
                return new Result(34, "管理员删除普通用户成功");

            }else {
                return new Result(-20, "权限不允许");
            }

        }else{
            return new Result(-13, "登录失效，请重新登录");
        }

    }


    //like查询用户
    @GetMapping("/selectUserByUserName")
    public Result selectUserByUserName(@RequestParam String userName) {


        //like查询用户返回
        List<UserLike> userLikeList = userService.selectUserByUserName(userName);

        //判断是否有数据
        if (userLikeList.size() == 0) {
            return new Result(-19, "查询失败 没有对应的用户");
        } else {
            //设置每项的头像
            userLikeList.forEach(i -> i.setPortraitAddress(userService.getPortraitAddress(i.getUserid())));
            userLikeList.forEach(i ->i.setRole(userService.selectUserRole(i.getUserid())));
            List<UserLike> userLikeList1=new ArrayList<>();
            for (int i = 0; i <userLikeList.size(); i++) {
                if (userLikeList.get(i).getRole().equals("user")) {
                    userLikeList1.add(userLikeList.get(i));
                }
            }

            return new Result(5, "查询成功", userLikeList1);
        }

    }

    //查询全部用户
    @PostMapping("/selectAllUser")
    public Result selectUserByUserName(@RequestParam Integer page) {

        //查询所有role为user的用户
        List<UserLike> userRoleList = userService.selectUserIdWhereIsUserByPage(page);

        userRoleList.forEach(i ->i.setUsername(userService.getUsername(i.getUserid())));
        userRoleList.forEach(i ->i.setPortraitAddress(userService.getPortraitAddress(i.getUserid())));


        List<Integer> Count=new ArrayList<>();
        Count.add(userRoleList.size());


        Map<String, List> userAllAndCount = new HashMap<>();
        userAllAndCount.put("UserAll", userRoleList);
        userAllAndCount.put("Count", Count);


        //判断是否有数据
        if (userRoleList.size() < 10) {

            return new Result(23, "查询成功已是最后一页", userAllAndCount);

        } else {

            return new Result(5, "查询成功", userAllAndCount);

        }

    }


    @PostMapping("/selectCommentId")
    public Result selectCommentId(@RequestBody User user) {


        //查询用户喜欢的帖子id
        List<LikesVo2> likesId = userService.selectCommentIdFromLikes(user.getUserid());
        //查询用户收藏的帖子id
        List<CollectsVo2> collectsId = userService.selectCommentIdFromCollects(user.getUserid());

        Map<String, List> m1 = new HashMap();

        m1.put("likes", likesId);
        m1.put("collects", collectsId);


        return new Result(19, "查询成功", m1);

    }


    //登录
    @PostMapping("/loginCheck")
    @ResponseBody
    public Result login(@RequestBody UserLogin user1) {


        User user = new User();
        user.setUsername(user1.getUsernameOrEmail());
        user.setPassword(user1.getPassword());
        Result result = userService.loginCheck(user);
        return result;
    }


    //账号注册
    @PostMapping("/register")
    public Result register(@RequestBody UserPo user1) {

        User user = userService.selectByUsernameOrEmail(user1.getUsername(), user1.getEmail());

        if (user1.getUsername() == null
                || user1.getPassword() == null
                || user1.getCaptcha1() == null
                || user1.getEmail() == null
                || !user1.getCaptcha1().equals(user1.getCaptcha2())
        ) {

            return new Result(0, "账号或者密码或者验证码或者邮箱为空 失败");//账号或者密码或者验证码或者邮箱为空 注册失败

        } else {

            User user2 = new User();
            user2.setUsername(user1.getUsername());
            user2.setPassword(user1.getPassword());
            user2.setEmail(user1.getEmail());


            //判断账号是否已经存在

            if (user != null) {
                //查询成功 该账号已经注册 code=-1  用户已存在
                return new Result(-1, "该账号已经注册,用户已存在");
            } else {
                //查询失败 注册 返回code=1 注册条数
                Integer data = (Integer) userService.register(user2);
                //用户权限
                userService.role(user2.getUserid());
                //上传默认头像
                userService.insertIntoUserPortrait(user2.getUserid());
                //设置默认浇水时间
                userService.insertRemind(user2.getUserid());

                return new Result(1, "注册成功", data);
            }
        }


    }

    //修改密码
    @PostMapping("changePassword")
    public Result changePassword(@RequestBody User user) {

        //先根据id查询该账号是否存在
        User user1 = userService.selectById(user.getUserid());

        if (user1 != null) {
            //修改密码
            return new Result(2, "修改密码成功", userService.changePassword(user.getUserid(), user.getPassword()));
        } else {
            //账号不存在 返回code=-1
            return new Result(-2, "修改密码失败 账号不存在");
        }

    }


    //忘记密码
    @PostMapping("/forgetPassword")
    public Result forgetPassword(@RequestBody UserPo user1) {

//        User user = userService.selectByUsernameAndEmail(user1.getUsername(), user1.getEmail());

        User user = userService.selectByEmail(user1.getEmail());

        if (user1.getUsername() == null
                || user1.getPassword() == null
                || user1.getCaptcha1() == null
                || user1.getEmail() == null
                || !user1.getCaptcha1().equals(user1.getCaptcha2())
        ) {

            return new Result(0, "账号或者密码或者验证码或者邮箱为空 失败");//账号或者密码或者验证码或者邮箱为空 修改失败
        }

        if (user == null) {
            //账号不存在 返回code=-1
            return new Result(-3, "账号不存在");
        } else {
            return new Result(2, "修改密码成功", userService.changePassword(user.getUserid(), user1.getPassword()));

        }


    }


    //获取校验用户名
    @PostMapping("/verifyUsername")
    public Result verifyUsername(@RequestBody User user) {

        User user1 = userService.selectByUsername(user.getUsername());

        if (user1 == null) {

            return new Result(1, "账号不存在 可以注册");

        } else {

            return new Result(-4, "账号已经存在 注册失败");

        }


    }


    //校验邮箱并发送验证码
    @PostMapping("/verifyEmailAndSendEmail")
    public Result verifyEmailAndSendEmail(@RequestBody User user) {

        User user1 = userService.selectByEmail(user.getEmail());

        if (user1 == null) {

            return new Result(-3, "账号不存在");

        } else {

            try {

                MimeMessage mimeMessage = this.mailSender.createMimeMessage();
                MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
                message.setFrom("chenxiaoli0111@qq.com");//设置发件qq邮箱

                message.setTo(user.getEmail());    //设置收件人
                message.setSubject("验证码");//设置标题

                //随机生成4位验证码
                Random r = new Random();
                int msg = r.nextInt(8000) + 1999;


                message.setText("你更改密码的的验证码是:" + msg);    //第二个参数true表示使用HTML语言来编写邮件
                this.mailSender.send(mimeMessage);

                return new Result(1, msg);

            } catch (Exception e) {

                return new Result(-1, "邮箱格式错误");

            }
        }
    }

    //校验邮箱的验证码
    @PostMapping("/verifyCode")
    public Result verifyCode(@RequestBody UserPo userPo) {

        if (!userPo.getCaptcha1().equals(userPo.getCaptcha2()) || userPo.getCaptcha1() == null) {
            return new Result(-7, "验证码错误或不存在");
        } else {
            return new Result(4, "验证码正确");
        }
    }

    //校验完成之后的修改密码
    @PostMapping("/beforeVerifyChangePassword")
    public Result beforeVerifyChangePassword(@RequestBody User user) {


        if (user.getPassword() == null) {
            return new Result(-8, "密码为空，请输入密码");
        } else {
            return new Result(2, "修改密码成功", userService.changePasswordByEmail(user.getEmail(), user.getPassword()));
        }

    }

    //根据账号id  返回username  and  email
    @PostMapping("/getUsernameAndEmail")
    public Result getUsernameAndEmail(@RequestBody UserJo userJo) {

        UserJo1 userJo1 = userService.getUsernameAndEmailAndPortraitAddress(userJo.getUserid());


        if (userJo1 != null) {
            return new Result(5, "查询成功", userJo1);
        } else {
            return new Result(-9, "查询失败，用户不存在");
        }


    }


}
