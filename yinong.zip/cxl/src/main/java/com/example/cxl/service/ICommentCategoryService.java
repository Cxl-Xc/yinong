package com.example.cxl.service;

import com.example.cxl.entity.CommentCategory;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-05-30
 */
public interface ICommentCategoryService extends IService<CommentCategory> {
    //查询全部comment类别
    List<CommentCategory> selectAllCommentCategory();


    //查询经验
    Integer selectJinYan();

    //查询投稿
    Integer selectTouGao();

    //查询求助
    Integer selectQiuZhu();
}
