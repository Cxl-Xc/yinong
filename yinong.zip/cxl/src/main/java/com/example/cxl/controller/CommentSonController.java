package com.example.cxl.controller;


import com.example.cxl.entity.*;
import com.example.cxl.service.ICommentService;
import com.example.cxl.service.ICommentSonService;
import com.example.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class CommentSonController {


    @Resource
    private ICommentSonService iCommentSonService;

    @Resource
    ICommentService iCommentService;


    //删除帖子的评论
    @PostMapping("/updateCommentSonState")
    public Result updateCommentSonState(@RequestBody CommentSonVo2 commentSonVo2) {

        //先根据userid到comment表查询token的值
        String token = iCommentService.selectTokenByUserId(commentSonVo2.getUserId());

        if (token.equals(commentSonVo2.getToken())) {

            //这里  肯定是有这个评论的 所以 直接删除 无需判断
            iCommentSonService.updateCommentSonState(commentSonVo2.getCommentSonId(), commentSonVo2.getUserId());

            //查询到子帖子的父帖子id
            Integer commentId = iCommentSonService.selectCommentIdFromCommentSon1(commentSonVo2.getCommentSonId());

            //删除帖子数量
            System.out.println("删除帖子评论数量");
            iCommentSonService.updateCommentss(commentId);

            return new Result(28, "删除评论成功");

        } else {

            return new Result(-13, "登录失效，请重新登录");

        }


    }

    //帖子的子评论的发布
    @PostMapping("/commentSon")
    public Result commentSon(@RequestBody CommentSonVo commentSonVo) {

        //先根据userid到comment表查询token的值
        String token = iCommentService.selectTokenByUserId(commentSonVo.getUserId());

        if (token.equals(commentSonVo.getToken())) {

            iCommentSonService.insertCommentByUserIdAndCommantId(commentSonVo.getUserId(),
                    commentSonVo.getCommentId(), commentSonVo.getCommentSonText());
            iCommentService.insertCommentsByCommentId(commentSonVo.getCommentId());

            return new Result(10, "评论成功");
        } else {
            return new Result(-13, "登录失效，请重新登录");

        }

    }

    //根据父comment查询评论
    @PostMapping("/selectCommentSonByCommentId")
    public Result selectCommentSonByCommentId(@RequestBody Comment comment) {

        List<CommentSonVo1> commentSonList =
                iCommentSonService.selectselectCommentSonByCommentId(comment.getCommentId());
//        //iCommentSonService.selectUserAddress(i.getUserId()))
        commentSonList.forEach(i -> i.setUserPortraitAddressList(iCommentService.selectUserAddress(i.getUserId())));

        return new Result(5, "查询成功", commentSonList);

    }


    //根据父comment查询下架的帖子的评论
    @PostMapping("/selectCommentSonByAmdinDeleteCommentId")
    public Result selectCommentSonByAmdinDeleteCommentId(@RequestBody Comment comment) {

        List<CommentSonVo1> commentSonList =
                iCommentSonService.selectCommentSonByAmdinDeleteCommentId(comment.getCommentId());

        commentSonList.forEach(i -> i.setUserPortraitAddressList(iCommentService.selectUserAddress(i.getUserId())));

        return new Result(5, "查询成功", commentSonList);

    }
}
