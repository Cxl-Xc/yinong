package com.example.cxl.controller;


import com.example.cxl.entity.CommentCategory;
import com.example.cxl.service.ICommentCategoryService;
import com.example.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-05-30
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class CommentCategoryController {


    @Resource
    private ICommentCategoryService iCommentCategoryService;

    //查询全部comment类别
    @GetMapping("/selectAllCommentCategory")
    public Result selectAllCommentCategory() {
        //查询全部comment类别
        List<CommentCategory> commentCategoryList = iCommentCategoryService.selectAllCommentCategory();

        //定义一个map用于存放总条数和类别
        Map<String, List> categoryListAndCounts = new HashMap<>();

        //查询经验
        Integer jinYan = iCommentCategoryService.selectJinYan();
        //查询投稿
        Integer touGao = iCommentCategoryService.selectTouGao();
        //查询求助
        Integer qiuZhu = iCommentCategoryService.selectQiuZhu();


        //new5个list用于存放
        List jinYans = new ArrayList();
        jinYans.add(jinYan);

        List touGaos = new ArrayList();
        touGaos.add(touGao);

        List qiuZhus = new ArrayList();
        qiuZhus.add(qiuZhu);

        categoryListAndCounts.put("jinYan", jinYans);
        categoryListAndCounts.put("touGao", touGaos);
        categoryListAndCounts.put("qiuZhu", qiuZhus);
        categoryListAndCounts.put("commentCategoryList", commentCategoryList);

        return new Result(5, "查询成功", categoryListAndCounts);


    }

}
