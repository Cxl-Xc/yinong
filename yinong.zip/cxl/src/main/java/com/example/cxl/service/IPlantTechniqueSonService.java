package com.example.cxl.service;

import com.example.cxl.entity.PlantTechniqueSon;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
public interface IPlantTechniqueSonService extends IService<PlantTechniqueSon> {

}
