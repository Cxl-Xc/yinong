package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class CommentVo3 implements Serializable {


    /**
     * 评论id
     */

    @TableId(value = "commentId", type = IdType.AUTO)
    private Integer commentId;

    /**
     * 评论者id
     */
    private Integer userId;


    private String token;


}
