package com.example.cxl.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
@Controller
@RequestMapping("/pathogenySon/pathogeny-son")
public class PathogenySonController {

}
