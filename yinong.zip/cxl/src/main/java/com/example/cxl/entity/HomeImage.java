package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-06-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("homeImage")
public class HomeImage implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 首页图片Id
     */
    @TableId("homeImageId")
    private Integer homeImageId;

    /**
     * 首页图片路径
     */
    @TableField("homeImageAddress")
    private String homeImageAddress;


}
