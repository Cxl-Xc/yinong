package com.example.cxl.mapper;

import com.example.cxl.entity.HomeImage;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-06-08
 */
public interface HomeImageMapper extends BaseMapper<HomeImage> {

    //查询图片路径
    String selectHomeImageAddress();

    //修改homeImageAddress
    void updateHomeImageAddress(String name);
}
