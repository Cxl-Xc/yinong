package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class CommentSonVo2 implements Serializable {

    /**
     * 发布评论者Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 帖子子评论内容
     */

    private String commentSonId;

    /**
     * token
     */
    private String token;


}
