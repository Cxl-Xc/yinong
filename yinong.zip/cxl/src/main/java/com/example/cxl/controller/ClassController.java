package com.example.cxl.controller;

import com.example.cxl.entity.*;
import com.example.cxl.entity.Class;
import com.example.cxl.service.IClassService;
import com.example.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-05-16
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class ClassController {

    @Resource
    private IClassService iClassService;

    //查询全部类别
    @GetMapping("/getAllClassName")
    public Result getAllClassName() {

        //定义一个map用于存放总条数和类别
        Map<String, List> classNameListAndCountClass = new HashMap<>();

        //查询粮食
        Integer liangShi = iClassService.selectLangShiCount();
        //查询蔬菜
        Integer shuCai = iClassService.selectShuCai();
        //查询果类
        Integer gouLei = iClassService.selectGouLei();
        //查询药用
        Integer yaoYong = iClassService.selectYaoYong();
        //查询油料
        Integer youLiao = iClassService.selectYouLiao();

        //new5个list用于存放
        List liangShis = new ArrayList();
        liangShis.add(liangShi);

        List shuCais = new ArrayList();
        shuCais.add(shuCai);

        List gouLeis = new ArrayList();
        gouLeis.add(gouLei);

        List yaoYongs = new ArrayList();
        yaoYongs.add(yaoYong);

        List youLiaos = new ArrayList();
        youLiaos.add(youLiao);

        classNameListAndCountClass.put("AllClassName", iClassService.selectAll());
        classNameListAndCountClass.put("liangShis", liangShis);
        classNameListAndCountClass.put("shuCais", shuCais);
        classNameListAndCountClass.put("gouLeis", gouLeis);
        classNameListAndCountClass.put("yaoYongs", yaoYongs);
        classNameListAndCountClass.put("youLiaos", youLiaos);

        return new Result(5, "查询成功", classNameListAndCountClass);

    }

    //根据类别在image表查询全部信息
    @PostMapping("/selectByClassName")
    public Result selectByClassName(@RequestBody Class classname) {
        //根据类别名称查询
        Integer classId = iClassService.selectByClassName(classname.getClassName());
        //根据类别id查询
        List<ImageVo> images = iClassService.selectByClassId(classId);
        //设置头像地址
        images.forEach(i -> i.setImageAddress(iClassService.selectByImageId(i.getImageId())));


        if (images != null) {
            return new Result(5, "查询成功", images);
        } else {
            return new Result(-10, "查询失败，未查询到数据");
        }

    }


    //根据类别在image表查询全部信息
    @PostMapping("/selectByClassName1")
    public Result selectByClassName1(@RequestBody ClassAndPages classAndPages) {

        //根据类别查询到类别id
        Integer classId = iClassService.selectByClassName(classAndPages.getClassName());

        //根据类别id和分页查询数据
        List<ImageVo> images = iClassService.selectByClassIdPage(classId, classAndPages.getPages());
        //设置头像地址
        images.forEach(i -> i.setImageAddress(iClassService.selectByImageId(i.getImageId())));
        //查询全部类别id
        Integer AllImage = iClassService.selectAllImage(classId);

        List<Integer> AllImages = new ArrayList<>();
        AllImages.add(AllImage);

        Map<String, List> m1 = new HashMap<>();


        m1.put("images", images);
        m1.put("AllImage", AllImages);

        return new Result(20, "分页查询成功", m1);

    }


    //根据图片id返回title  text  className  address
    @PostMapping("/selectByImageId")
    public Result selectByImageId(@RequestBody Image imageId) {

        //根据id查询
        List<ImageVo2> images = iClassService.selectByImageId2(imageId);
        //设置头像和类别名
        images.forEach(i -> i.setImageAddress(iClassService.selectByImageId(i.getImageId())));
        images.forEach(i -> i.setClassName(iClassService.selectByClassId2(i.getClassId())));


        if (images != null) {
            return new Result(5, "查询成功", images);
        } else {
            return new Result(-10, "查询失败，未查询到数据");
        }


    }


}
