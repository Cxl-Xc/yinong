package com.example.cxl.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.cxl.entity.CommentSon;
import com.example.cxl.entity.CommentSonVo1;
import com.example.cxl.entity.UserPortraitAddress;

import java.util.List;


/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
public interface ICommentSonService extends IService<CommentSon> {

    void insertCommentByUserIdAndCommantId(Integer userId, Integer commentId, String commentSonText);

    List<CommentSonVo1> selectselectCommentSonByCommentId(Integer commentId);

    List<UserPortraitAddress> selectUserAddress(Integer userId);

    //这里  肯定是有这个评论的 所以 直接删除 无需判断
    void updateCommentSonState(String commentSonId, Integer userId);

    // 删除帖子数量
    void updateComments(String commentSonId, Integer userId);

    //查询到commentid
    Integer selectCommentIdFromCommentSon(String commentSonId, Integer userId);

    //删除帖子数量
    void updateCommentss(Integer commentId);

    //查询父帖子id
    Integer selectCommentIdFromCommentSon1(String commentSonId);

    //获取下架的帖子的评论
    List<CommentSonVo1> selectCommentSonByAmdinDeleteCommentId(Integer commentId);
}
