package com.example.cxl.controller;


import com.example.cxl.entity.PlantTechnique;
import com.example.cxl.entity.PlantTechniqueSon;
import com.example.cxl.service.ICommentService;
import com.example.cxl.service.IPathogenyService;
import com.example.cxl.service.IPlantTechniqueService;
import com.example.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-06-08
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class PlantTechniqueController {

    @Resource
    private IPlantTechniqueService iPlantTechniqueService;

    @Resource
    private ICommentService iCommentService;

    @Resource
    private IPathogenyService iPathogenyService;

    //返回病因技巧的总数和种植技巧的总数
    @GetMapping("/selectCountPlantTechniqueAndPathogeny")
    public Result  selectCountPlantTechniqueAndPathogeny(){

        //查询种植技巧的总数
        Integer plantTechniqueCounts=iPlantTechniqueService.selectCountAllPlantTechnique();

        //查询病因总数
        Integer pathogenyCounts = iPathogenyService.selectCountPathogeny();

        Map<String, Integer> counts = new HashMap<>();

        counts.put("plantTechniqueCounts", plantTechniqueCounts);
        counts.put("pathogenyCounts", pathogenyCounts);

        return new Result(5, "查询成功", counts);

    }

    //根据标题like查询
    @PostMapping("/selectPlantTechnique")
    public Result selectPlantTechnique(@RequestParam Integer page,@RequestParam String plantTechniqueTitle) {

        //分页like查询全部plantTechnique
        List<PlantTechnique> plantTechniqueList = iPlantTechniqueService.selectPlantTechnique(page,plantTechniqueTitle);

        List<Integer> Count = new ArrayList<>();
        //查询总条数Like查询
        Count.add(iPlantTechniqueService.selectCountAllPlantTechniqueByLike(plantTechniqueTitle));

        Map<String, List> allPlantTechnique = new HashMap<>();
        allPlantTechnique.put("plantTechniqueList", plantTechniqueList);
        allPlantTechnique.put("Count", Count);


        //判断是否有数据
        if (plantTechniqueList.size() < 10) {

            return new Result(23, "查询成功已是最后一页", allPlantTechnique);

        } else {

            return new Result(5, "查询成功", allPlantTechnique);

        }

    }


    //随机返回种植技巧里面的一个技巧内容
    @GetMapping("/getPlantTechniqueSonText")
    public Result getPlantTechniqueSonText(){


        //先查询全部的数据
        List<String> plantTechniqueSonTextList=iPlantTechniqueService.getPlantTechniqueSonText();

        Random rm=new Random();
        int s=rm.nextInt(plantTechniqueSonTextList.size());

        return  new Result(44,"随机返回技巧成功",plantTechniqueSonTextList.get(s));

    }




    //根据plantTechniqueId删除plantTechnique
    @PostMapping("/updatePlantTechniqueByPlantTechniqueId")
    public Result updatePlantTechniqueByPlantTechniqueId(@RequestParam Integer userId,
                                                         @RequestParam String token,
                                                         @RequestParam Integer plantTechniqueId
    ) {
        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userId);

        if (token.equals(token2)) {
            //修改种植技巧的state为1
            Integer delete = iPlantTechniqueService.updatePlantTechniqueByPlantTechniqueId(plantTechniqueId);
            if (delete != null) {
                return new Result(35, "删除种植技巧成功");
            } else {
                return new Result(-21, "删除种植技巧失败");
            }
        } else {
            return new Result(-13, "登录失效，请重新登录");
        }

    }


    //根据plantTechniqueId获取全部plantTechniqueSon信息
    @PostMapping("/selectAllPlantTechniqueSon")
    public Result selectAllPlantTechniqueSon(@RequestParam Integer plantTechniqueId) {

        //查询全部plantTechniqueSon
        List<PlantTechniqueSon> plantTechniqueSonList = iPlantTechniqueService.selectPlantTechniqueSonByPlantTechniqueId(plantTechniqueId);


        return new Result(5, "查询成功", plantTechniqueSonList);


    }

    //获取全部种植技巧 分页显示
    @GetMapping("/selectAllPlantTechnique")
    public Result selectAllPlantTechnique(@RequestParam Integer page) {

        //分页查询全部plantTechnique
        List<PlantTechnique> plantTechniqueList = iPlantTechniqueService.selectAllPlantTechniqueByPage(page);

        List<Integer> Count = new ArrayList<>();
        Count.add(iPlantTechniqueService.selectCountAllPlantTechnique());

        Map<String, List> allPlantTechnique = new HashMap<>();
        allPlantTechnique.put("plantTechniqueList", plantTechniqueList);
        allPlantTechnique.put("Count", Count);


        //判断是否有数据
        if (plantTechniqueList.size() < 10) {

            return new Result(23, "查询成功已是最后一页", allPlantTechnique);

        } else {

            return new Result(5, "查询成功", allPlantTechnique);

        }


    }


    //实现上传种植技巧前置
    @PostMapping("/addPlantTechniqueQianZhi")
    public Result addPlantTechniqueQianZhi(@RequestParam Integer userId,
                                           @RequestParam String token,
                                           @RequestParam String plantTechniqueTitle,
                                           @RequestParam String plantTechniqueText,
                                           @RequestParam MultipartFile plantTechinqueImageAddress
    ) throws IOException {

        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userId);

        if (token.equals(token2)) {

            //时间
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");

            String path = "/home/image/";//保存到指定的文件目录
            String path2 = "plantTechniqueImageAddress/" + userId + "/"
                    + plantTechniqueTitle + "的图片" + df.format(new Date());//保存到指定的文件目录
            File dir = new File(path + path2);
            if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
            }

            plantTechinqueImageAddress.transferTo(new File(dir.getAbsolutePath() + File.separator
                    + plantTechinqueImageAddress.getOriginalFilename()));
            String plantTechniqueImageAddress2 = "/" + path2 + "/" + plantTechinqueImageAddress.getOriginalFilename();//获取图片的名字


            //生成种植技巧对象
            PlantTechnique plantTechnique = new PlantTechnique();
            //添加属性
            //设置  标题
            plantTechnique.setPlantTechniqueTitle(plantTechniqueTitle);
            //设置  内容
            plantTechnique.setPlantTechniqueText(plantTechniqueText);
            //设置  地址
            plantTechnique.setPlantTechniqueImageAddress(plantTechniqueImageAddress2);
            //设置   state
            plantTechnique.setState("0");
            //设置  时间
            plantTechnique.setTime(new Date());

            //插入数据库
            iPlantTechniqueService.insertPlantTechnique(plantTechnique);

            //插入成功 返回plantTechniqueId
            return new Result(31, "插入种植技巧成功", plantTechnique.getPlantTechniqueId());

        } else {
            return new Result(-13, "登录失效，请重新登录");
        }

    }


    //上传种植技巧后置
    @PostMapping("/addPlantTechniqueHouZhi")
    public Result addPlantTechniqueHouZhi(@RequestParam Integer userId,
                                          @RequestParam String token,
                                          @RequestParam Integer plantTechniqueId,
                                          @RequestParam String plantTechniqueSonTitle,
                                          @RequestParam String plantTechniqueSonText,
                                          @RequestParam MultipartFile plantTechniqueSonImageAddress
    ) throws IOException {
        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userId);

        if (token.equals(token2)) {
            //时间
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");

            String path = "/home/image/";//保存到指定的文件目录
            String path2 = "plantTechniqueImageAddress/" + userId + "/"
                    + plantTechniqueSonTitle + "的图片" + df.format(new Date());//保存到指定的文件目录
            File dir = new File(path + path2);
            if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
            }

            plantTechniqueSonImageAddress.transferTo(new File(dir.getAbsolutePath() + File.separator
                    + plantTechniqueSonImageAddress.getOriginalFilename()));
            String plantTechniqueImageAddress2 = "/" + path2 + "/" + plantTechniqueSonImageAddress.getOriginalFilename();//获取图片的名字

            //生成对象
            PlantTechniqueSon plantTechniqueSon = new PlantTechniqueSon();
            //赋值
            plantTechniqueSon.setPlantTechniqueId(plantTechniqueId);
            plantTechniqueSon.setPlantTechniqueSonTitle(plantTechniqueSonTitle);
            plantTechniqueSon.setPlantTechniqueSonText(plantTechniqueSonText);
            plantTechniqueSon.setPlantTechniqueSonImageAddress(plantTechniqueImageAddress2);
            plantTechniqueSon.setState("0");

            //插入数据库
            iPlantTechniqueService.insertPlantTechniqueSon(plantTechniqueSon);

            return new Result(32, "插入种植技巧Son成功");

        } else {
            return new Result(-13, "登录失效，请重新登录");
        }


    }


}
