package com.example.cxl.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.cxl.entity.Class;
import com.example.cxl.entity.Image;
import com.example.cxl.entity.ImageVo;
import com.example.cxl.entity.ImageVo2;
import com.example.cxl.mapper.ClassMapper;
import com.example.cxl.service.IClassService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;


/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-05-16
 */
@Service
public class ClassServiceImpl extends ServiceImpl<ClassMapper, Class> implements IClassService {

    @Resource
    ClassMapper classMapper;

    @Override
    public List<Class> selectAll() {
        return (List<Class>) classMapper.selectAll();
    }

    @Override
    //根据类别查询到类别id
    public Integer selectByClassName(String className) {
        return classMapper.seletByClassName(className);
    }

    @Override
    public List<ImageVo> selectByClassId(Integer classId) {
        return classMapper.selectByClassId(classId);
    }

    @Override
    public String selectByImageId(Integer imageId) {
        return classMapper.selectByImageId(imageId);
    }

    @Override
    public List<ImageVo2> selectByImageId2(Image imageId) {
        return classMapper.selectByClassId2(imageId);
    }

    @Override
    public String selectByClassId2(String classId) {
        return classMapper.selectByClassId3(classId);
    }

    @Override
    public List<ImageVo> selectByClassIdPage(Integer classId, String pages) {

        Integer index = (Integer.parseInt(pages) - 1) * 5;

        return classMapper.selectByClassIdPage(classId, index);
    }

    @Override
    public Integer selectAllImage(Integer classId) {
        return classMapper.selectAllImage(classId);
    }

    @Override
    //查询总类别数
    public Integer selectCountClass() {
        return classMapper.selectCountClass();
    }

    @Override
    //查询全部粮食的数量
    public Integer selectLangShiCount() {
        return classMapper.selectLangShiCount();
    }

    @Override
    //查询蔬菜
    public Integer selectShuCai() {
        return classMapper.selectShuCai();
    }

    @Override
    //查询果类
    public Integer selectGouLei() {
        return classMapper.selectGouLei();
    }

    @Override
    //查询药用
    public Integer selectYaoYong() {
        return classMapper.selectYaoYong();
    }

    @Override
    //查询油料
    public Integer selectYouLiao() {
        return classMapper.selectYouLiao();
    }


}
