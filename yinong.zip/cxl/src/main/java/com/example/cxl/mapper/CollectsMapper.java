package com.example.cxl.mapper;

import com.example.cxl.entity.Collects;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.Date;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
public interface CollectsMapper extends BaseMapper<Collects> {

    //先根据userid和commentid去collects表里查询是否有
    Collects selectByUserIdAndCommentId(Integer userId, Integer commentId);

    void collectsByUserIdAndCommentId(Integer userId, Integer commentId, Date date);

    void updateCommentCollectsByCommentId(Integer commentId);

    void updateCollectsState(Integer commentId);

    void updateCommentCollectsByCommentId1(Integer commentId);

    void updateCollectsState2(Integer commentId);
}
