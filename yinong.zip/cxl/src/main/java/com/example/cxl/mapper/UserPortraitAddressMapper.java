package com.example.cxl.mapper;

import com.example.cxl.entity.User;
import com.example.cxl.entity.UserPortraitAddress;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-05-18
 */
public interface UserPortraitAddressMapper extends BaseMapper<UserPortraitAddress> {

    User selectByUserId(Integer userid);

    void insertPortraitAddress(Integer userid, String name);

    String selectUserPortraitAddressById(Integer userid);

    void updatePortraitAddress(Integer userid, String name);
}
