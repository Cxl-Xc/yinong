package com.example.cxl.service;

import com.example.cxl.entity.CommentAddress;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-05-22
 */
public interface ICommentAddressService extends IService<CommentAddress> {

}
