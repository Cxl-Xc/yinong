package com.example.cxl.service.impl;

import com.example.cxl.entity.CommentAddress;
import com.example.cxl.mapper.CommentAddressMapper;
import com.example.cxl.service.ICommentAddressService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-05-22
 */
@Service
public class CommentAddressServiceImpl extends ServiceImpl<CommentAddressMapper, CommentAddress> implements ICommentAddressService {

}
