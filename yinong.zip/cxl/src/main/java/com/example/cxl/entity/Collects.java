package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.time.LocalDateTime;
import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Collects implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 收藏Id
     */
    @TableId(value = "collectsId", type = IdType.AUTO)
    private Integer collectsId;

    /**
     * 收藏者Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 帖子Id
     */
    @TableField("commentId")
    private Integer commentId;

    /**
     * ’0‘代表为删除 ’1‘代表删除
     */
    @TableLogic //逻辑删除字段  1代表删除 0代表未删除
    @TableField(fill = FieldFill.INSERT)
    private String state;

    /**
     * 最后收藏时间
     */
    @TableField("lastCollectsTime")
    private LocalDateTime lastCollectsTime;


}
