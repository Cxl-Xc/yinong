package com.example.cxl.service;

import com.example.cxl.entity.Pathogeny;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.cxl.entity.PathogenySon;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
public interface IPathogenyService extends IService<Pathogeny> {

    //向病因表插入数据
    void insertPathogeny(Pathogeny pathogeny);

    //插入数据库
    void insertPathogenySon(PathogenySon pathogenySon);

    //查询全部病因 分页显示
    List<Pathogeny> selectAlPathogenyByPage(Integer page);

    //根据病因id 查询 病因子
    List<PathogenySon> selectPathogenySonByPathogenyId(Integer pathogenyId);

    //设置病因查询的state为1
    Integer updatePathogneyByPathogneyId(Integer pathogneyId);

    //分页like查询
    List<Pathogeny> selectPathogeny(Integer page, String pathogenyTitle);

    //查询总条数
    Integer selectCountPathogeny();

    //查询总条数like查询
    Integer selectCountPathogenyByLike(String pathogenyTitle);
}
