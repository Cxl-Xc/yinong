package com.example.cxl.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.cxl.entity.Class;
import com.example.cxl.entity.Image;
import com.example.cxl.entity.ImageVo;
import com.example.cxl.entity.ImageVo2;

import java.util.List;


/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-05-16
 */
public interface IClassService extends IService<Class> {

    List<Class> selectAll();

    //根据类别查询到类别id
    Integer selectByClassName(String className);


    List<ImageVo> selectByClassId(Integer classId);

    String selectByImageId(Integer imageId);

    List<ImageVo2> selectByImageId2(Image imageId);

    String selectByClassId2(String classId);

    //根据classid分页查询
    List<ImageVo> selectByClassIdPage(Integer classId, String pages);

    Integer selectAllImage(Integer classId);

    //查询总类别数
    Integer selectCountClass();

    //查询全部粮食的数量
    Integer selectLangShiCount();

    //查询蔬菜
    Integer selectShuCai();

    //查询果类
    Integer selectGouLei();

    //查询药用
    Integer selectYaoYong();

    //查询油类
    Integer selectYouLiao();
}
