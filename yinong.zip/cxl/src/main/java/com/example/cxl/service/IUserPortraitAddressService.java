package com.example.cxl.service;

import com.example.cxl.entity.User;
import com.example.cxl.entity.UserPortraitAddress;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-05-18
 */
public interface IUserPortraitAddressService extends IService<UserPortraitAddress> {

    //先根据userId到user表查询是否有此用户
    User selectByUserId(Integer userid);

    //插入地址
    void insertPortraitAddress(Integer userid, String name);

    ////根据id查询他是否已经有头像
    String selectUserPortraitAddressById(Integer userid);

    void updatePortraitAddress(Integer userid, String name);
}
