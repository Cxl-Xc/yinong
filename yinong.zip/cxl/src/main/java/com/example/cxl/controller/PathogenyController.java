package com.example.cxl.controller;


import com.example.cxl.entity.Pathogeny;
import com.example.cxl.entity.PathogenySon;
import com.example.cxl.entity.PlantTechnique;
import com.example.cxl.entity.PlantTechniqueSon;
import com.example.cxl.service.ICommentService;
import com.example.cxl.service.IPathogenyService;
import com.example.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class PathogenyController {

    @Resource
    private IPathogenyService iPathogenyService;

    @Resource
    private ICommentService iCommentService;

    //根据标题like查询
    @PostMapping("/selectPathogney")
    public Result selectPathogney(@RequestParam Integer page,@RequestParam String pathogenyTitle) {

        //分页like查询全部pathogeny
        List<Pathogeny> pathogenyList = iPathogenyService.selectPathogeny(page,pathogenyTitle);

        List<Integer> Count = new ArrayList<>();
        //查询总条数
        Count.add(iPathogenyService.selectCountPathogenyByLike(pathogenyTitle));

        Map<String, List> allPlantTechnique = new HashMap<>();
        allPlantTechnique.put("plantTechniqueList", pathogenyList);
        allPlantTechnique.put("Count", Count);


        //判断是否有数据
        if (pathogenyList.size() < 10) {

            return new Result(23, "查询成功已是最后一页", allPlantTechnique);

        } else {

            return new Result(5, "查询成功", allPlantTechnique);

        }

    }


    //根据pathogneyId删除pathogney
    @PostMapping("/updatePathogneyByPathogneyId")
    public Result updatePathogneyByPathogneyId(@RequestParam Integer userId,
                                                         @RequestParam String token,
                                                         @RequestParam Integer pathogneyId
    ) {
        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userId);

        if (token.equals(token2)) {
            //修改病因查询的state为1
            Integer delete = iPathogenyService.updatePathogneyByPathogneyId(pathogneyId);
            if (delete != null) {
                return new Result(43, "删除病因查询成功");
            } else {
                return new Result(-21, "删除病因查询失败");
            }
        } else {
            return new Result(-13, "登录失效，请重新登录");
        }

    }



    //根据pathogenyId获取全部病因查询子信息
    @PostMapping("/selectAllPathogenySon")
    public Result selectAllPathogenySon(@RequestParam Integer pathogenyId) {

        //查询全部pathogenyIdSon
        List<PathogenySon> pathogenySonSonList = iPathogenyService.selectPathogenySonByPathogenyId(pathogenyId);

        return new Result(5, "查询成功", pathogenySonSonList);

    }


    //获取全部病因查询 分页显示
    @GetMapping("/selectAllPathogeny")
    public Result selectAllPathogeny(@RequestParam Integer page) {

        //分页查询全部selectAllPathogeny
        List<Pathogeny> pathogenyList = iPathogenyService.selectAlPathogenyByPage(page);

        List<Integer> Count = new ArrayList<>();
        //插入总条数
        Count.add(iPathogenyService.selectCountPathogeny());

        Map<String, List> allPathogeny = new HashMap<>();
        allPathogeny.put("plantTechniqueList", pathogenyList);
        allPathogeny.put("Count", Count);


        //判断是否有数据
        if (pathogenyList.size() < 10) {

            return new Result(23, "查询成功已是最后一页", allPathogeny);

        } else {

            return new Result(5, "查询成功", allPathogeny);

        }


    }




    //实现上传病因查询前置
    @PostMapping("/addPathogenyQianZhi")
    public Result addPathogenyQianZhi(@RequestParam Integer userId,
                                           @RequestParam String token,
                                           @RequestParam String pathogenyTitle,
                                           @RequestParam String pathogenyText,
                                           @RequestParam MultipartFile pathogenyImageAddress
    ) throws IOException {

        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userId);

        if (token.equals(token2)) {

            //时间
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");

            String path = "/home/image/";//保存到指定的文件目录
            String path2 = "pathogenyImageAddress/" + userId + "/"
                    + pathogenyTitle + "的图片" + df.format(new Date());//保存到指定的文件目录
            File dir = new File(path + path2);
            if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
            }

            pathogenyImageAddress.transferTo(new File(dir.getAbsolutePath() + File.separator
                    + pathogenyImageAddress.getOriginalFilename()));
            String plantTechniqueImageAddress2 = "/" + path2 + "/" + pathogenyImageAddress.getOriginalFilename();//获取图片的名字


            //生成种植技巧对象
            Pathogeny pathogeny=new Pathogeny();
            //添加属性
            //设置  标题
            pathogeny.setPathogenyTitle(pathogenyTitle);
            //设置  内容
            pathogeny.setPathogenyText(pathogenyText);
            //设置  地址
            pathogeny.setPathogenyImageAddress(plantTechniqueImageAddress2);
            //设置   state
            pathogeny.setState("0");
            //设置  时间
            pathogeny.setTime(new Date());

            //插入数据库
            iPathogenyService.insertPathogeny(pathogeny);

            //插入成功 返回plantTechniqueId
            return new Result(41, "插入病因成功", pathogeny.getPathogenyId());

        } else {
            return new Result(-13, "登录失效，请重新登录");
        }

    }

    //上传病因查询后置
    @PostMapping("/addPathogenyHouZhi")
    public Result addPathogenyHouZhi(@RequestParam Integer userId,
                                          @RequestParam String token,
                                          @RequestParam Integer pathogenyId,
                                          @RequestParam String pathogenySonTitle,
                                          @RequestParam String pathogenySonText,
                                          @RequestParam MultipartFile pathogenySonImageAddress
    ) throws IOException {
        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userId);

        if (token.equals(token2)) {
            //时间
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");

            String path = "/home/image/";//保存到指定的文件目录
            String path2 = "pathogenyImageAddress/" + userId + "/"
                    + pathogenySonTitle + "的图片" + df.format(new Date());//保存到指定的文件目录
            File dir = new File(path + path2);
            if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
            }

            pathogenySonImageAddress.transferTo(new File(dir.getAbsolutePath() + File.separator
                    + pathogenySonImageAddress.getOriginalFilename()));
            String plantTechniqueImageAddress2 = "/" + path2 + "/" + pathogenySonImageAddress.getOriginalFilename();//获取图片的名字

            //生成对象
            PathogenySon pathogenySon=new PathogenySon();
            //赋值
            pathogenySon.setPathogenyId(pathogenyId);
            pathogenySon.setPathogenySonTitle(pathogenySonTitle);
            pathogenySon.setPathogenySonText(pathogenySonText);
            pathogenySon.setPathogenySonImageAddress(plantTechniqueImageAddress2);

            //插入数据库
            iPathogenyService.insertPathogenySon(pathogenySon);

            return new Result(42, "插入病因查询Son成功");

        } else {
            return new Result(-13, "登录失效，请重新登录");
        }


    }





}
