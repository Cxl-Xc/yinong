package com.example.cxl.mapper;

import com.example.cxl.entity.Likes;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.Date;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
public interface LikesMapper extends BaseMapper<Likes> {

    Likes selectByUserIdAndCommentId(Integer userId, Integer commentId);

    void likesByUserIdAndCommentId(Integer userId, Integer commentId, Date date);

    void updateCommentLikesByCommentId(Integer commentId);

    void updateLikesState(Integer commentId);

    void updateLikesState2(Integer commentId);

    void updateCommentLikesByCommentId1(Integer commentId);
}
