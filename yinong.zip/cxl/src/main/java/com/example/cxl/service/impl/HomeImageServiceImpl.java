package com.example.cxl.service.impl;

import com.example.cxl.entity.HomeImage;
import com.example.cxl.mapper.HomeImageMapper;
import com.example.cxl.service.IHomeImageService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-06-08
 */
@Service
public class HomeImageServiceImpl extends ServiceImpl<HomeImageMapper, HomeImage> implements IHomeImageService {

    @Resource
    private HomeImageMapper homeImageMapper;

    //修改homeImageAddress的图片
    @Override
    public void updateHomeImageAddress(String name) {

        homeImageMapper.updateHomeImageAddress(name);

    }

    //  查询图片路径
    @Override
    public String selectHomeImageAddress() {
        return homeImageMapper.selectHomeImageAddress();
    }
}
