package com.example.cxl.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.cxl.entity.CommentSon;
import com.example.cxl.entity.CommentSonVo1;
import com.example.cxl.entity.UserPortraitAddress;

import java.util.Date;
import java.util.List;


/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
public interface CommentSonMapper extends BaseMapper<CommentSon> {

    void insertCommentByUserIdAndCommantId(Integer userId, Integer commentId, String commentSonText, Date date);

    List<CommentSonVo1> selectselectCommentSonByCommentId(Integer commentId);

    //这里  肯定是有这个评论的 所以 直接删除 无需判断
    List<UserPortraitAddress> selectUserAddress(Integer userId);

    void updateCommentSonState(String commentSonId, Integer userId);

    //删除帖子数量
    void updateComments(String commentSonId, Integer userId);

    //查询到commentid
    Integer selectCommentIdFroxmCommentSon(String commentSonId, Integer userId);

    //删除帖子数量
    void updateCommentss(Integer commentId);

    //查询父帖子id
    Integer selectCommentIdFromCommentSon1(String commentSonId);

    //获取下架的帖子的评论
    List<CommentSonVo1> selectCommentSonByAmdinDeleteCommentId(Integer commentId);
}
