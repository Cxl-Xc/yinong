package com.example.cxl.mapper;

import com.example.cxl.entity.CommentCategory;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-05-30
 */
public interface CommentCategoryMapper extends BaseMapper<CommentCategory> {
    //查询全部comment类别
    List<CommentCategory> selectAllCommentCategory();

    //查询经验
    Integer selectJinYan();

    //查询投稿
    Integer selectTouGao();

    //查询求助
    Integer selectQiuZhu();
}
