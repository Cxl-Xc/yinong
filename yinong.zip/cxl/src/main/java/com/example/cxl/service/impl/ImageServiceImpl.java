package com.example.cxl.service.impl;

import com.example.cxl.entity.Image;
import com.example.cxl.mapper.ImageMapper;
import com.example.cxl.service.IImageService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-05-16
 */
@Service
public class ImageServiceImpl extends ServiceImpl<ImageMapper, Image> implements IImageService {

    @Resource
    private ImageMapper imageMapper;

    @Override
    public void insertImageAddress(Integer imageId, String name) {

        imageMapper.insertImageAddress(imageId, name);
    }

    @Override
    public Integer insertImage(Integer userid, String title, String text, Integer className, String imageContent) {

        Image image = new Image();
        image.setUserid(userid);
        image.setImageTitle(title);
        image.setImageText(text);
        image.setClassId(className);
        image.setDate(new Date());
        image.setImageContent(imageContent);
        imageMapper.insert(image);
        return image.getImageId();
    }


    @Override
    public Integer selectByClassName(String className) {
        return imageMapper.selectByClassName(className);
    }

    @Override
    public void deleteAddimages(Integer imageId) {
        imageMapper.deleteAddimages(imageId);
    }

    @Override
    public void updateImage(Integer imageId, Integer userid, String title, String text, Integer classId, String imageContent) {
        Image image = new Image();
        image.setImageId(imageId);
        image.setUserid(userid);
        image.setImageTitle(title);
        image.setImageText(text);
        image.setClassId(classId);
        image.setDate(new Date());
        image.setImageContent(imageContent);

        imageMapper.updateImage(image);
    }

    @Override
    public void updateImageAddress(Integer imageId, String name) {
        imageMapper.updateImageAddress(imageId, name);
    }
}
