package com.example.cxl.hander;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

//自动填充的插件
@Component
public class MyMetaObjectHandler implements MetaObjectHandler {
    @Override   //插入数据的时候填充
    public void insertFill(MetaObject metaObject) {
        //先获取到identity的值 再进行判断 如果为1  不变 如果不是1 填充为0
        Object identity = getFieldValByName("identity", metaObject);
        if (identity != "1") {
            setFieldValByName("identity", "0", metaObject);
        }

        //先获取到state的值 为空 填充0
        Object state = getFieldValByName("state", metaObject);
        if (state == null) {
            setFieldValByName("state", "0", metaObject);
        }

    }

    @Override   //更新数据的时候填充
    public void updateFill(MetaObject metaObject) {

    }
}
