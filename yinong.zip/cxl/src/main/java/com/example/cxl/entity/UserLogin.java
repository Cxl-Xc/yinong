package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-04-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class UserLogin implements Serializable {


    /**
     * 用户名称
     */
    private String usernameOrEmail;

    /**
     * 用户密码
     */
    private String password;


}
