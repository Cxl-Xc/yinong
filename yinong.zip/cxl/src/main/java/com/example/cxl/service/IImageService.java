package com.example.cxl.service;

import com.example.cxl.entity.Image;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-05-16
 */
public interface IImageService extends IService<Image> {

    //插入地址
    void insertImageAddress(Integer imageId, String name);

    //插入图片
    Integer insertImage(Integer userid, String title, String text, Integer className, String imageContent);

    //根据className查询是否存在id
    Integer selectByClassName(String className);

    //删除
    void deleteAddimages(Integer imageId);

    void updateImage(Integer imageId, Integer userid, String title, String text, Integer classId, String imageContent);

    void updateImageAddress(Integer imageId, String name);
}

