package com.example.cxl.utils;

import lombok.Data;

@Data
public class Result {

    private Integer code;
    private String message;
    private Object data;
    private Object token;
    private String role;


    public Result(Integer code, String message, Object data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public Result(Integer code, String message) {
        this.code = code;
        this.message = message;

    }

    public Result(Integer code, Object data) {
        this.code = code;
        this.data = data;

    }

    public Result(Integer code) {
        this.code = code;

    }

    public Result(Integer code, String message , Object data,Object token) {
        this.code = code;
        this.message = message;
        this.data = data;
        this.token=token;

    }

    public Result(Integer code, Object data,Object token) {
        this.code = code;
        this.data = data;
        this.token=token;

    }

    public Result(Integer code, Object data,Object token,String role) {
        this.code = code;
        this.data = data;
        this.token=token;
        this.role=role;

    }
    public Result(Integer code, String message,Object data,Object token,String role) {
        this.code = code;
        this.message = message;
        this.data = data;
        this.token=token;
        this.role=role;

    }

}
