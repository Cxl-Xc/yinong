package com.example.cxl.service;

import com.example.cxl.entity.*;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-05-18
 */
public interface ICommentService extends IService<Comment> {

    //根据userid查询token的值
    String selectTokenByUserId(Integer userid);

    //插入帖子
    void insertAddComment(Integer userid, String commentText, String s, String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, Integer commentCategoryId);

    void insertAddComment2(Integer userid, String commentText);

    Integer selectCommentCategoryIdBycommentCategoryClass(String commentCategoryClass);

    void insertCommentsByCommentId(Integer commentId);

    List<CommentVo> selectAllComment();

    String selectCommentCategoryClassByCommentCategoryId(String commentCategoryId);

    List<CommentVo> selectCommentByCommentCategoryId(Integer commentCategoryId);

    //向comment插入数据
    void insertIntoComment(Comment comment);

    //向commentAddress插入数据
    void insertIntoCommentAddressByCommentId(Integer commentId);

    //向commentAddress插入数据
    void insertIntoCommentAddressByCommentIdAndName(Integer commentId, String name);

    //根据commentId在commentAddress查询数据
    List<CommentAddress> selectCommentAddressListByCommentId(Integer commentId);

    //根据userid返回头像
    String selectPortraitAddressByuserId(Integer userid);

    List<CommentVo> selectCommentByCommentId(Integer commentId);

    String selectUserNameByUserId(Integer userid);

    List<CollectsAndLikes> selectCommentIdByUserIdLikes(Integer userid);

    List<CollectsAndLikes> selectCommentIdByUserIdCollects(Integer userid);


    List<UserPortraitAddress> selectUserAddress(Integer userId);

    List<UserPortraitAddress> selectUserNameByUserId1(Integer userId);

    //根据userid查询帖子
    List<CommentVo> selectCommentByUserId(Integer userid);

    void deleteCommentIdByUserId(Integer userId);

    //修改帖子的state为2
    void deleteCommentIdByUserIdAndCommentId(Integer userId, Integer commentId);

    List<CommentVo> selectAllCommentByIndex(Integer index);

    Integer selectAllComment2(Integer index);

    List<CommentVo> selectCommentByCommentCategoryIdByPage(Integer commentCategoryId, Integer index);

    //先去查询全部的likes的commentId
    List<Integer> selectLikesCommentByUserId(Integer userid);

    //根据查询到的commentid去comment表查询全部信息
    CommentVo selectCommentByCommentIdForLikes(Integer integer);

    //到collects表根据userid查询全部信息
    List<Integer> selectCollectsCommentByUserId(Integer userid);

    //删除comment
    void updateCommentStateByUserIdAndCommentId(Integer userId, Integer commentId);

    //删除这个帖子下面的子帖子
    void updateCommentSonStateByUserIdAndCommentId(Integer userId, Integer commentId);

    //删除这个帖子的collects
    void updateCollectsStateByUserIdAndCommentId(Integer userId, Integer commentId);

    //删除这个帖子下面的likes
    void updateLikesStateByUserIdAndCommentId(Integer userId, Integer commentId);

    //查询总条数
    Integer selectCount(Integer commentCategoryId);

    //查询全部总条数
    Integer selectAllCounts();

    //查询全部下架的帖子
    List<CommentVo> selectAllCommentByAdminDelete(Integer index);

    //更具likes先后返回全部数据
    List<CommentVo> selectAllCommentByIndexAndLikes(Integer index);

    //修改帖子的state为0
    void unDeleteCommentIdByAdminUserId(Integer commentId);

    //修改帖子子帖子state为0
    void updateCommentSonStateByUserIdAndCommentId2(Integer commentId);

    //修改collects的state为0
    void updateCollectsStateByUserIdAndCommentId2(Integer commentId);

    //修改likes的state为0
    void updateLikesStateByUserIdAndCommentId2(Integer commentId);

    Integer selectAllCounts2();

    //通过Id查询管理员删除的帖子
    List<CommentVo> selectCommentByCommentIdAndAdminDelete(Integer commentId);
}
