package com.example.cxl.mapper;

import com.example.cxl.entity.*;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-04-29
 */
public interface UserMapper extends BaseMapper<User> {

    //根据账号密码查询是否有这个账号
    User selectUsernameAndPassword(String username, String password);


    //更具账号名称查询账号
    User selectByusername(String username);


    //查询id对应的user权限
    String selectByIdForrole(Integer userid);

    //根据id修改密码
    Integer changePassword(Integer userid, String password);


    //根据账号名称或者邮箱查询账号
    User selectByusernameOrEmail(String username, String email);


    //根据用户名和邮箱查询账号
    User selectByusernameAndEmail(String username, String email);

    //根据邮箱查询账号
    User selectByEmail(String email);

    //根据邮箱修改密码
    Integer changePasswordByEmail(String email, String password);

    //根据id插入用户权限
    void role(Integer userid);

    //根据id查询账号和邮箱
    UserJo selectUsernameAndEmail(Integer userid);

    //根据id向数据库插入token
    void insertTokenByUserId(Integer userid, String token);

    void insertIntoUserPortrait(Integer userid);

    Integer selectCommentId(Integer userid);

    //查询用户喜欢的帖子id
    List<LikesVo2> selectCommentIdFromLikes(Integer userid);

    List<CollectsVo2> selectCommentIdFromCollects(Integer userid);

    //设置浇水时间
    void insertRemind(Integer userid);

    //查询账户
    UserJo1 getUsernameAndEmailAndPortraitAddress(Integer userid);

    //like查询用户
    List<UserLike> selectUserByUserName(String userName);

    //设置每项的头像
    String getPortraitAddress(Integer userid);

    //查询全部用户
    List<UserLike> selectAllUser(Integer page2);

    //查询管理员权限
    String selectUserRole(Integer adminUserId);

    //删除用户
    void updateUserState(Integer userId);

    //查询全部管理员账号和被下权限的管理员账号的Id
    List<UserSelectRoleAdmin> selectAllAdminAndUnAdminId();

    //获取用户名
    String getUsername(Integer userid);

    //判断userid对应的身份权限
    String selectUserRoleByUserId(Integer userId);

    //修改权限为unAdmin
    void updateUserRoleToUnAdmin(Integer adminUserId);

    //修改权限为admin
    void updateUserRoleToAdmin(Integer adminUserId);

    //查询所有权限为user的用户
    List<UserLike> selectUserIdWhereIsUser();

    //查询所有权限为user的用户分页显示
    List<UserLike> selectUserIdWhereIsUserByPage(Integer page2);

    //删除用户权限
    void deleteUserRole(Integer userId);
}
