package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ImageVo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 图片的自增id
     */
    @TableId(value = "imageId", type = IdType.AUTO)
    private Integer imageId;


    /**
     * 图片标题
     */
    @TableField("imageTitle")
    private String imageTitle;

    /**
     * 图片内容
     */
    @TableField("imageText")
    private String imageText;


    private String imageContent;


    private String imageAddress;


}
