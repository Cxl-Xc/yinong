package com.example.cxl.controller;


import com.example.cxl.entity.User;
import com.example.cxl.service.IUserPortraitAddressService;
import com.example.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-05-18
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class UserPortraitAddressController {

    @Resource
    private IUserPortraitAddressService iUserPortraitAddressService;

    @PostMapping("/addUserPortrait")
    public Result upload(@RequestParam("userId") Integer userid,
                         @RequestParam("files") MultipartFile file
    ) throws Exception {


        //先根据userId到user表查询是否有此用户
        User user = iUserPortraitAddressService.selectByUserId(userid);

        if (user != null) {


            //        String path = "F:/image/" ;//保存到指定的文件目录
            //        String path = "/usr/local/img/" ;//保存到指定的文件目录

            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");

            String path = "/home/image/";//保存到指定的文件目录
            String path2 = "userPortraitAddress/" + userid + "/PortraitAddress" + df.format(new Date());//保存到指定的文件目录
            File dir = new File(path + path2);
            if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
            }

            file.transferTo(new File(dir.getAbsolutePath() + File.separator + file.getOriginalFilename()));
            String name = "/" + path2 + "/" + file.getOriginalFilename();//获取图片的名字

            //插入地址
            iUserPortraitAddressService.updatePortraitAddress(userid, name);


            return new Result(6, "上传成功", name);


        } else {
            return new Result(-11, "上传失败,用户不存在");

        }


    }


}
