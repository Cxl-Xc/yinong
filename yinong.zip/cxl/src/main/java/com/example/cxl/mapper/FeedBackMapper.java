package com.example.cxl.mapper;

import com.example.cxl.entity.FeedBack;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
public interface FeedBackMapper extends BaseMapper<FeedBack> {

    //查询全部反馈  分页显示
    List<FeedBack> selectAllFeedBack(Integer page2);

    //修改反馈state
    void updateFeedBackState(Integer feedBackId);

    //查询总条数
    Integer selectCount1();
}
