package com.example.cxl.service;

import com.example.cxl.entity.Likes;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
public interface ILikesService extends IService<Likes> {

    Likes selectByUserIdAndCommentId(Integer userId, Integer commentId);

    void likesByUserIdAndCommentId(Integer userId, Integer commentId);

    void updateLikesState(Integer commentId);

    void updateLikesState2(Integer commentId);
}
