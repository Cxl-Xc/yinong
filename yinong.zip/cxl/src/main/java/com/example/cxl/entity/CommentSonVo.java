package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class CommentSonVo implements Serializable {

    //参数类

    /**
     * 发布评论者Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 父帖子Id
     */
    @TableField("commentId")
    private Integer commentId;

    /**
     * 帖子子评论内容
     */
    @TableField("commentSonText")
    private String commentSonText;

    /**
     * token
     */
    private String token;


}
