package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Pathogeny implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 病因Id
     */
    @TableId(value = "pathogenyId", type = IdType.AUTO)
    private Integer pathogenyId;

    /**
     * 病因标题
     */
    @TableField("pathogenyTitle")
    private String pathogenyTitle;

    /**
     * 病因内容
     */
    @TableField("pathogenyText")
    private String pathogenyText;

    /**
     * 病因图片地址
     */
    @TableField("pathogenyImageAddress")
    private String pathogenyImageAddress;

    /**
     * 0是有  1是无
     */
    private String state;

    /**
     * 时间
     */
    private Date time;


}
