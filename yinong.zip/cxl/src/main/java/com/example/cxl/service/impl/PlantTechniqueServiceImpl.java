package com.example.cxl.service.impl;

import com.example.cxl.entity.PlantTechnique;
import com.example.cxl.entity.PlantTechniqueSon;
import com.example.cxl.mapper.PlantTechniqueMapper;
import com.example.cxl.mapper.PlantTechniqueSonMapper;
import com.example.cxl.service.IPlantTechniqueService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-06-08
 */
@Service
public class PlantTechniqueServiceImpl extends ServiceImpl<PlantTechniqueMapper, PlantTechnique> implements IPlantTechniqueService {

    @Resource
    private PlantTechniqueMapper plantTechniqueMapper;

    @Resource
    private PlantTechniqueSonMapper plantTechniqueSonMapper;

    @Override
    //插入数据库
    public void insertPlantTechnique(PlantTechnique plantTechnique) {
        plantTechniqueMapper.insert(plantTechnique);
    }

    @Override
    //分页查询全部plantTechnique
    public List<PlantTechnique> selectAllPlantTechniqueByPage(Integer page) {
        Integer page2 = (page - 1) * 10;
        return plantTechniqueMapper.selectAllPlantTechniqueByPage(page2);
    }

    @Override
    //查询plantTechniqueSon
    public List<PlantTechniqueSon> selectPlantTechniqueSonByPlantTechniqueId(Integer plantTechniqueId) {
        return plantTechniqueMapper.selectPlantTechniqueSonByPlantTechniqueId(plantTechniqueId);
    }

    @Override
    //插入数据库
    public void insertPlantTechniqueSon(PlantTechniqueSon plantTechniqueSon) {
        plantTechniqueSonMapper.insert(plantTechniqueSon);
    }

    @Override
    //修改种植技巧的state为1
    public Integer updatePlantTechniqueByPlantTechniqueId(Integer plantTechniqueId) {
        plantTechniqueMapper.updateplantTechniqueSonState(plantTechniqueId);
        return plantTechniqueMapper.updatePlantTechniqueByPlantTechniqueId(plantTechniqueId);
    }

    @Override
    //查询全部的数据
    public List<String> getPlantTechniqueSonText() {
        return plantTechniqueMapper.getPlantTechniqueSonText();
    }

    @Override
    //分页like查询全部的plantTechniuqe
    public List<PlantTechnique> selectPlantTechnique(Integer page, String plantTechniqueTitle) {
        Integer page2 = (page - 1) * 10;
        return plantTechniqueMapper.selectPlantTechnique(page2,plantTechniqueTitle);
    }

    @Override
    //查询总条数
    public Integer selectCountAllPlantTechnique() {
        return plantTechniqueMapper.selectCountAllPlantTechnique();
    }

    @Override
    //查询总条数 like查询
    public Integer selectCountAllPlantTechniqueByLike(String plantTechniqueTitle) {
        return plantTechniqueMapper.selectCountAllPlantTechniqueByLike(plantTechniqueTitle);
    }

    @Override
    //根据state查询信息
    public List<PlantTechniqueSon> selectPlantTechniqueTextByState() {
        return plantTechniqueMapper.selectPlantTechniqueTextByState();
    }

    @Override
    //根据id插入数据
    public String getPlantTechniqueSonTextById(Integer plantTechniqueId) {
        return plantTechniqueMapper.getPlantTechniqueSonTextById(plantTechniqueId);
    }
}
