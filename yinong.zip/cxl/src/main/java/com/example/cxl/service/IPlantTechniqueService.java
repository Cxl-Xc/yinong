package com.example.cxl.service;

import com.example.cxl.entity.PlantTechnique;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.cxl.entity.PlantTechniqueSon;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-08
 */
public interface IPlantTechniqueService extends IService<PlantTechnique> {

    //插入数据库
    void insertPlantTechnique(PlantTechnique plantTechnique);

    //分页查询全部planttechnique
    List<PlantTechnique> selectAllPlantTechniqueByPage(Integer page);

    //查询全部plantTechniqueSon
    List<PlantTechniqueSon> selectPlantTechniqueSonByPlantTechniqueId(Integer plantTechniqueId);

    //插入数据库
    void insertPlantTechniqueSon(PlantTechniqueSon plantTechniqueSon);

    //修改种植技巧的state为1
    Integer updatePlantTechniqueByPlantTechniqueId(Integer plantTechniqueId);

    //查询全部的Text数据
    List<String> getPlantTechniqueSonText();

    //分页like查询全部的plantTechnique
    List<PlantTechnique> selectPlantTechnique(Integer page, String plantTechniqueTitle);

    //查询总条数
    Integer selectCountAllPlantTechnique();

    //查询总条数like查询
    Integer selectCountAllPlantTechniqueByLike(String  plantTechniqueTitle);

    //根据state查询信息
    List<PlantTechniqueSon> selectPlantTechniqueTextByState();


    //根据id插入数据
    String getPlantTechniqueSonTextById(Integer plantTechniqueId);
}
