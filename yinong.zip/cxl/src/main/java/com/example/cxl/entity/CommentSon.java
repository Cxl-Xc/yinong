package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("commentSon")
public class CommentSon implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 帖子子评论Id
     **/
    @TableId(value = "commentSonId", type = IdType.AUTO)
    private Integer commentSonId;

    /**
     * 发布评论者Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 父帖子Id
     */
    @TableField("commentId")
    private Integer commentId;

    /**
     * 帖子子评论内容
     */
    @TableField("commentSonText")
    private String commentSonText;

    /**
     * ‘1’代表删除，'0'代表未删除
     */
    @TableLogic //逻辑删除字段  1代表删除 0代表未删除
    @TableField(fill = FieldFill.INSERT)
    private String state;

    /**
     * 评论时间
     */
    private LocalDateTime date;


}
