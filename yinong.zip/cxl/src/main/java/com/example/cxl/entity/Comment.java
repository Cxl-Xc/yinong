package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.time.LocalDateTime;
import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Comment implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 评论id
     */

    @TableId(value = "commentId", type = IdType.AUTO)
    private Integer commentId;

    /**
     * 评论者id
     */
    private Integer userid;

    /**
     * 评论者评论
     */
    @TableField("commentText")
    private String commentText;


    /**
     * 评论者上传时间
     */
    @TableField("commentTime")
    private Date commentTime;

    /**
     * 点赞数
     */
    private String likes;

    /**
     * 收藏数
     */
    private String collects;

    /**
     * 评论数
     */
    private String comments;


    /**
     * ‘1’代表删除，'0'代表未删除
     */
    @TableLogic //逻辑删除字段  1代表删除 0代表未删除
    @TableField(fill = FieldFill.INSERT)
    private String state;

    @TableField("commentCategoryId")
    private String commentCategoryId;


}
