package com.example.cxl.controller;


import com.example.cxl.entity.Collects;
import com.example.cxl.entity.CollectsVo;
import com.example.cxl.entity.Likes;
import com.example.cxl.service.ICollectsService;
import com.example.cxl.service.ICommentService;
import com.example.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import javax.annotation.Resource;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class CollectsController {

    @Resource
    private ICollectsService iCollectsService;


    @Resource
    private ICommentService iCommentService;

    @PostMapping("/collects")
    public Result collects(@RequestBody CollectsVo collectsVo) {

        //先根据userid到comment表查询token的值
        String token = iCommentService.selectTokenByUserId(collectsVo.getUserId());

        if (token.equals(collectsVo.getToken())) {

            //先根据userid和commentid去collects表里查询是否有
            Collects collects = iCollectsService.selectByUserIdAndCommentId(collectsVo.getUserId(), collectsVo.getCommentId());

            //根据查询到的值进行判断

            if (collects == null) {

                //向collects插入数据  并且实现comment表collects加1
                iCollectsService.collectsByUserIdAndCommentId(collectsVo.getUserId(), collectsVo.getCommentId());

                return new Result(14, "收藏成功 之前未收藏");
            } else {
                //说明数据库里面已经有点赞的记录  判断state   如果state=0  变为1  如果是1  变为0

                if (collects.getState().equals("0")) {
                    iCollectsService.updateCollectsState(collectsVo.getCommentId());
                    return new Result(15, "修改成功 取消收藏");
                } else {
                    iCollectsService.updateCollectsState2(collectsVo.getCommentId());
                    return new Result(16, "修改成功 收藏");
                }


            }

        } else {

            return new Result(-13, "登录失效，请重新登录");
        }


    }


}
