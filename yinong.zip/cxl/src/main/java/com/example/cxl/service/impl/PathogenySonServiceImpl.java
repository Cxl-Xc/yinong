package com.example.cxl.service.impl;

import com.example.cxl.entity.PathogenySon;
import com.example.cxl.mapper.PathogenySonMapper;
import com.example.cxl.service.IPathogenySonService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
@Service
public class PathogenySonServiceImpl extends ServiceImpl<PathogenySonMapper, PathogenySon> implements IPathogenySonService {

}
