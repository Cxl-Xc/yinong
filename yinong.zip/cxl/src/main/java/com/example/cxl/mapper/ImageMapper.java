package com.example.cxl.mapper;

import com.example.cxl.entity.Image;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-05-16
 */
public interface ImageMapper extends BaseMapper<Image> {

    void insertImageAddress(Integer imageId, String name);


    Integer selectByClassName(String className);

    void deleteAddimages(Integer imageId);

    void updateImage(@Param("image") Image image);

    void updateImageAddress(Integer imageId, String name);
}
