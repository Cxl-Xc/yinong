package com.example.cxl.service.impl;

import com.example.cxl.entity.*;
import com.example.cxl.hander.TokenUtil;
import com.example.cxl.mapper.UserMapper;
import com.example.cxl.service.IUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.cxl.utils.Result;

import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-04-29
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {

    @Resource
    UserMapper userMapper;


    @Resource
    TokenUtil tokenUtil;


    //登录
    @Override
    public Result loginCheck(User user) {
        //根据账号密码查询账号是否存在
        User user2 = userMapper.selectUsernameAndPassword(user.getUsername(), user.getPassword());
        if (user2 == null) {
            return new Result(-5, "账号不存在或密码错误 登录失败");//登录失败 账号不存在或者密码错误 返回code=0
        } else {
            //查询是否为管理员权限账号
            String role = userMapper.selectByIdForrole(user2.getUserid());
            String token = tokenUtil.generateToken(user2);
            userMapper.insertTokenByUserId(user2.getUserid(), token);
            return new Result(3, "登录成功", user2, token, role);//登录成功 返回code=1 id token role
        }


    }


    //根据username查询
    @Override
    public User selectByUsername(String username) {

        return userMapper.selectByusername(username);


    }

    @Override
    //注册
    public Object register(User user1) {
        return userMapper.insert(user1);
    }

    //根据id查询该账号是否存在
    @Override
    public User selectById(Integer userid) {
        return userMapper.selectById(userid);
    }

    @Override
    //根据id修改密码
    public Integer changePassword(Integer userid, String password) {
        return (Integer) userMapper.changePassword(userid, password);
    }

    //根据username或email查询账号是否存在
    @Override
    public User selectByUsernameOrEmail(String username, String email) {
        return userMapper.selectByusernameOrEmail(username, email);
    }

    @Override
    public User selectByUsernameAndEmail(String username, String email) {
        return userMapper.selectByusernameAndEmail(username, email);
    }

    @Override
    public User selectByEmail(String email) {
        return userMapper.selectByEmail(email);
    }

    @Override
    public Integer changePasswordByEmail(String email, String password) {
        return (Integer) userMapper.changePasswordByEmail(email, password);
    }

    //根据id在用户权限表里面注册权限
    @Override
    public void role(Integer userid) {

        userMapper.role(userid);

    }


    //根据userid查询usernameandEmail
    @Override
    public UserJo getUsernameAndEmail(Integer userid) {


        return userMapper.selectUsernameAndEmail(userid);
    }

    @Override
    public void insertIntoUserPortrait(Integer userid) {

        userMapper.insertIntoUserPortrait(userid);


    }

    @Override
    public Integer selectCommentId(Integer userid) {
        return userMapper.selectCommentId(userid);
    }

    @Override
    //查询用户喜欢的帖子id
    public List<LikesVo2> selectCommentIdFromLikes(Integer userid) {
        return userMapper.selectCommentIdFromLikes(userid);
    }

    @Override
    public List<CollectsVo2> selectCommentIdFromCollects(Integer userid) {
        return userMapper.selectCommentIdFromCollects(userid);
    }

    //设置浇水时间
    @Override
    public void insertRemind(Integer userid) {
        userMapper.insertRemind(userid);
    }

    @Override
    //查询用户
    public UserJo1 getUsernameAndEmailAndPortraitAddress(Integer userid) {
        return userMapper.getUsernameAndEmailAndPortraitAddress(userid);
    }

    @Override
    //like查询用户
    public List<UserLike> selectUserByUserName(String userName) {
        return userMapper.selectUserByUserName(userName);
    }

    //查询全部用户
    @Override
    public List<UserLike> selectAllUser(Integer page) {

        Integer page2 = (page - 1) * 10;

        return userMapper.selectAllUser(page2);
    }

    @Override
    //查询管理员权限
    public String selectUserRole(Integer adminUserId) {
        return userMapper.selectUserRole(adminUserId);
    }

    @Override
    //删除用户
    public void updateUserState(Integer userId) {
        userMapper.updateUserState(userId);
    }

    @Override
    //设置每项的头像
    public String getPortraitAddress(Integer userid) {
        return userMapper.getPortraitAddress(userid);
    }

    @Override
    //获取用户名
    public String getUsername(Integer userid) {
        return userMapper.getUsername(userid);
    }

    @Override
//    查询全部管理员账号和被下权限的管理员账号的Id
    public List<UserSelectRoleAdmin> selectAllAdminAndUnAdminId() {
        return userMapper.selectAllAdminAndUnAdminId();
    }

    @Override
    //判断userId对应的身份权限
    public String selectUserRoleByUserId(Integer userId) {
        return userMapper.selectUserRoleByUserId(userId);
    }

    @Override
    //修改权限为unAdmin
    public void updateUserRoleToUnAdmin(Integer adminUserId) {
        userMapper.updateUserRoleToUnAdmin(adminUserId);

    }

    @Override
    //修改权限为admin
    public void updateUserRoleToAdmin(Integer adminUserId) {

        userMapper.updateUserRoleToAdmin(adminUserId);

    }

    @Override
    //查询所有权限为user的用户
    public List<UserLike> selectUserIdWhereIsUser() {
        return userMapper.selectUserIdWhereIsUser();
    }

    @Override
    //查询所有权限为user的用户分页显示
    public List<UserLike> selectUserIdWhereIsUserByPage(Integer page) {
        Integer page2 = (page - 1) * 10;
        return userMapper.selectUserIdWhereIsUserByPage(page2);
    }

    @Override
    //删除用户权限
    public void deleteUserRole(Integer userId) {
        userMapper.deleteUserRole(userId);
    }
}
