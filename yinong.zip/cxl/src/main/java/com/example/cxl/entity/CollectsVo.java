package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class CollectsVo implements Serializable {


    /**
     * 收藏者Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 帖子Id
     */
    @TableField("commentId")
    private Integer commentId;


    /**
     * token
     */
    private String token;


}
