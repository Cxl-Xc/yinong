package com.example.cxl.mapper;

import com.example.cxl.entity.*;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-05-18
 */
public interface CommentMapper extends BaseMapper<Comment> {

    String selectTokenByUserId(Integer userid);

    void insertAddComment(Integer userid, String commentText, String s, String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, Date date, Integer commentCategoryId);

    void insertAddComment2(Integer userid, String commentText, Date date);

    Integer selectCommentCategoryIdBycommentCategoryClass(String commentCategoryClass);

    void updateComments(Integer commentId);

    List<CommentVo> selectAllComment();

    String selectCommentCategoryClassByCommentCategoryId(String commentCategoryId);

    List<CommentVo> selectCommentByCommentCategoryId(Integer commentCategoryId);


    //向commentAddress插入数据
    void insertIntoCommentAddressByCommentId(Integer commentId);

    void insertIntoCommentAddressByCommentIdAndName(Integer commentId, String name);

    List<CommentAddress> selectCommentAddressListByCommentId(Integer commentId);

    String selectPortraitAddressByuserId(Integer userid);

    List<CommentVo> selectCommentByCommentId(Integer commentId);

    String selectUserNameByUserId(Integer userid);

    List<CollectsAndLikes> selectCommentIdByUserIdLikes(Integer userid);

    List<CollectsAndLikes> selectCommentIdByUserIdCollects(Integer userid);


    List<UserPortraitAddress> selectUserAddress(Integer userId);

    List<UserPortraitAddress> selectUserNameByUserId1(Integer userId);

    List<CommentVo> selectCommentByUserId(Integer userid);

    void deleteCommentIdByUserId(Integer userId);

    //修改帖子的state为2
    void deleteCommentIdByUserIdAndCommentId(Integer userId, Integer commentId);


    List<CommentVo> selectAllCommentByIndex(Integer index2);

    Integer selectAllComment2(Integer index2);

    List<CommentVo> selectCommentByCommentCategoryIdByPage(Integer commentCategoryId, Integer index2);

    //先去查询全部的likes的commentId
    List<Integer> selectLikesCommentByUserId(Integer userid);

    //根据查询到的commentid去comment表查询全部信息
    CommentVo selectCommentByCommentIdForLikes(Integer integer);

    //到collects表根据userid查询全部信息
    List<Integer> selectCollectsCommentByUserId(Integer userid);

    //删除comment
    void updateCommentStateByUserIdAndCommentId(Integer userId, Integer commentId);

    //删除这个帖子下面的子帖子
    void updateCommentSonStateByUserIdAndCommentId(Integer userId, Integer commentId);

    //删除这个帖子的collects
    void updateCollectsStateByUserIdAndCommentId(Integer userId, Integer commentId);

    //删除这个帖子下面的likes
    void updateLikesStateByUserIdAndCommentId(Integer userId, Integer commentId);

    //查询总条数
    Integer selectCounts(Integer commentCategoryId);

    //查询全部总条数
    Integer selectAllCounts();

    //查询全部删除的帖子
    List<CommentVo> selectAllCommentByAdminDelete(Integer index2);

    //查询全部帖子 更具likes返回
    List<CommentVo> selectAllCommentByIndexAndLikes(Integer index2);

    //修改帖子state为0
    void unDeleteCommentIdByAdminUserId(Integer commentId);

    //修改帖子子帖子state为0
    void updateCommentSonStateByUserIdAndCommentId2(Integer commentId);

    //修改collect的state为0
    void updateCollectsStateByUserIdAndCommentId2(Integer commentId);

    //修改likes的state为0
    void updateLikesStateByUserIdAndCommentId2(Integer commentId);

    Integer selectAllCount2();

    //通过Id查询管理员删除的帖子
    List<CommentVo> selectCommentByCommentIdAndAdminDelete(Integer commentId);
}
