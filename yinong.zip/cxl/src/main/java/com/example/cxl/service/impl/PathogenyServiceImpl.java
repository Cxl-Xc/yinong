package com.example.cxl.service.impl;

import com.example.cxl.entity.Pathogeny;
import com.example.cxl.entity.PathogenySon;
import com.example.cxl.mapper.PathogenyMapper;
import com.example.cxl.mapper.PathogenySonMapper;
import com.example.cxl.service.IPathogenyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
@Service
public class PathogenyServiceImpl extends ServiceImpl<PathogenyMapper, Pathogeny> implements IPathogenyService {

    @Resource
    private PathogenyMapper pathogenyMapper;

    @Resource
    private PathogenySonMapper pathogenySonMapper;

    @Override
    //向病因表插入数据
    public void insertPathogeny(Pathogeny pathogeny) {
        pathogenyMapper.insert(pathogeny);
    }

    @Override
    //插入数据
    public void insertPathogenySon(PathogenySon pathogenySon) {
        pathogenySonMapper.insert(pathogenySon);
    }

    @Override
    //查询全部病因分页显示
    public List<Pathogeny> selectAlPathogenyByPage(Integer page) {
        Integer page2 = (page - 1) * 10;
        return pathogenyMapper.selectAlPathogenyByPage(page2);
    }

    @Override
    //根据病因id  查询子
    public List<PathogenySon> selectPathogenySonByPathogenyId(Integer pathogenyId) {
        return pathogenySonMapper.selectPathogenySonByPathogenyId(pathogenyId);
    }

    @Override
    //设置病因查询的state为1
    public Integer updatePathogneyByPathogneyId(Integer pathogneyId) {
        return pathogenyMapper.updatePathogneyByPathogneyId(pathogneyId);
    }

    @Override
    //分页liek查询
    public List<Pathogeny> selectPathogeny(Integer page, String pathogenyTitle) {
        Integer page2 = (page - 1) * 10;
        return pathogenyMapper.selectPathogeny(page2,pathogenyTitle);
    }

    @Override
    //查询总条数
    public Integer selectCountPathogeny() {
        return pathogenyMapper.selectCountPathogeny();
    }

    @Override
    //查询总条数 like查询
    public Integer selectCountPathogenyByLike(String pathogenyTitle) {
        return pathogenyMapper.selectCountPathogenyByLike(pathogenyTitle);
    }
}
