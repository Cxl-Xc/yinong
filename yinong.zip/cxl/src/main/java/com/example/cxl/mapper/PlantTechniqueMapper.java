package com.example.cxl.mapper;

import com.example.cxl.entity.PlantTechnique;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.cxl.entity.PlantTechniqueSon;

import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-06-08
 */
public interface PlantTechniqueMapper extends BaseMapper<PlantTechnique> {


    //查询全部plantTechnique
    List<PlantTechnique> selectAllPlantTechniqueByPage(Integer page2);

    //查询plantTechniqueSon
    List<PlantTechniqueSon> selectPlantTechniqueSonByPlantTechniqueId(Integer plantTechniqueId);

    //修改种植技巧的state为1
    Integer updatePlantTechniqueByPlantTechniqueId(Integer plantTechniqueId);

    //查询全部的数据
    List<String> getPlantTechniqueSonText();

    //分页like查询
    List<PlantTechnique> selectPlantTechnique(Integer page2, String plantTechniqueTitle);

    //查询总条数
    Integer selectCountAllPlantTechnique();

    //查询总条数 like查询
    Integer selectCountAllPlantTechniqueByLike(String plantTechniqueTitle);

    //根据state查询信息
    List<PlantTechniqueSon> selectPlantTechniqueTextByState();

    //根据id插入数据
    String getPlantTechniqueSonTextById(Integer plantTechniqueId);

    //修改state
    void updateplantTechniqueSonState(Integer plantTechniqueId);
}
