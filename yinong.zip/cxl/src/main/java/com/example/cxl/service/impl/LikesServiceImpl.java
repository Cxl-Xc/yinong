package com.example.cxl.service.impl;

import com.example.cxl.entity.Likes;
import com.example.cxl.mapper.LikesMapper;
import com.example.cxl.service.ILikesService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
@Service
public class LikesServiceImpl extends ServiceImpl<LikesMapper, Likes> implements ILikesService {


    @Resource
    private LikesMapper likesMapper;

    @Override
    public Likes selectByUserIdAndCommentId(Integer userId, Integer commentId) {
        return likesMapper.selectByUserIdAndCommentId(userId, commentId);
    }

    @Override
    public void likesByUserIdAndCommentId(Integer userId, Integer commentId) {
        likesMapper.likesByUserIdAndCommentId(userId, commentId, new Date());
        likesMapper.updateCommentLikesByCommentId(commentId);


    }

    @Override
    public void updateLikesState(Integer commentId) {
        likesMapper.updateLikesState(commentId);
        likesMapper.updateCommentLikesByCommentId1(commentId);
    }

    @Override
    public void updateLikesState2(Integer commentId) {
        likesMapper.updateLikesState2(commentId);
        likesMapper.updateCommentLikesByCommentId(commentId);
    }
}
