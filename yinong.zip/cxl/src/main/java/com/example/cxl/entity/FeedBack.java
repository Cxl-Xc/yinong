package com.example.cxl.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("feedBack")
public class FeedBack implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 反馈Id
     */
    @TableId(value = "feedBackId", type = IdType.AUTO)
    private Integer feedBackId;

    /**
     * 反馈内容
     */
    @TableField("feedBakcText")
    private String feedBakcText;

    /**
     * 用户Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 电话或邮箱
     */
    @TableField("phoneOrEmail")
    private String phoneOrEmail;

    @TableField("state")
    private String state;


}
