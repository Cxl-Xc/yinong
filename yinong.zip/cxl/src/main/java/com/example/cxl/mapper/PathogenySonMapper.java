package com.example.cxl.mapper;

import com.example.cxl.entity.PathogenySon;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
public interface PathogenySonMapper extends BaseMapper<PathogenySon> {

    //更具id查询子
    List<PathogenySon> selectPathogenySonByPathogenyId(Integer pathogenyId);
}
