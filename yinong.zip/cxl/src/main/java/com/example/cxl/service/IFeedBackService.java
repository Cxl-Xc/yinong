package com.example.cxl.service;

import com.example.cxl.entity.FeedBack;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-09
 */
public interface IFeedBackService extends IService<FeedBack> {

    //提交反馈
    Object insertFeedBack(Integer userId, String feedBakcText, String phoneOrEmail);

    //查询全部反馈 分页显示
    List<FeedBack> selectAllFeedBack(Integer page);

    //修改反馈state
    void updateFeedBackState(Integer feedBackId);

    //查询总条数
    Integer selectCount();
}
