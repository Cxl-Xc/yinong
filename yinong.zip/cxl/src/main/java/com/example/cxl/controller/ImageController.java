package com.example.cxl.controller;


import com.example.cxl.entity.Image;
import com.example.cxl.service.ICommentService;
import com.example.cxl.service.IImageService;
import com.example.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-05-16
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class ImageController {

    @Resource
    private IImageService imageService;

    @Resource
    private ICommentService iCommentService;

    //修改1
    @PostMapping("/changeAddimages")
    public Result changeAddimages(@RequestParam("imageId") Integer imageId,
                                  @RequestParam("userId") Integer userid,
                                  @RequestParam("files") MultipartFile file,
                                  @RequestParam("token") String token) throws IOException {

        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userid);

        if (token.equals(token2)) {

            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");

            String path = "/home/image/";//保存到指定的文件目录
            String path2 = "imageAddress/" + userid + "/" + "更新" + df.format(new Date());//保存到指定的文件目录
            File dir = new File(path + path2);
            if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
            }

            file.transferTo(new File(dir.getAbsolutePath() + File.separator + file.getOriginalFilename()));
            String name = "/" + path2 + "/" + file.getOriginalFilename();//获取图片的名字

            imageService.updateImageAddress(imageId, name);
            return new Result(21, "修改成功，更新图片");


        } else {
            return new Result(-13, "登录失效，请重新登录");
        }
    }

    //修改2
    @PostMapping("/changeAddimages2")
    public Result changeAddimages2(@RequestParam("imageId") Integer imageId,
                                   @RequestParam("userId") Integer userid,
                                   @RequestParam("imageTitle") String title,
                                   @RequestParam("imageText") String text,
                                   @RequestParam("className") String className,
                                   @RequestParam("token") String token,
                                   @RequestParam("imageContent") String imageContent) throws IOException {

        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userid);

        if (token.equals(token2)) {

            //先根据className到class表查询是否有此类 返回id
            Integer classId = imageService.selectByClassName(className);

//            if (file.isEmpty()) {


            imageService.updateImage(imageId, userid, title, text, classId, imageContent);
            return new Result(21, "修改成功，先更新数据");
        } else {
            return new Result(-13, "登录失效，请重新登录");
        }
    }


    //删除
    @PostMapping("/deleteAddimages")
    public Result deleteAddimages(@RequestBody Image image) {

        imageService.deleteAddimages(image.getImageId());

        return new Result(18, "删除addimage成功");
    }


    //上传图片
    @PostMapping("/addimages")
    public Result upload(@RequestParam("userId") Integer userid,
                         @RequestParam("imageTitle") String title,
                         @RequestParam("imageText") String text,
                         @RequestParam("className") String className,
                         @RequestParam("files") MultipartFile file,
                         @RequestParam("token") String token,
                         @RequestParam("imageContent") String imageContent
    ) throws Exception {


        //先根据userid到comment表查询token的值
        String token2 = iCommentService.selectTokenByUserId(userid);

        //判断token  如果不一样 返回失效 一样 进行评论
        if (token2.equals(token)) {
            //先根据className到class表查询是否有此类 返回id
            Integer classId = imageService.selectByClassName(className);

//        String path = "F:/image/" ;//保存到指定的文件目录
//        String path = "/usr/local/img/" ;//保存到指定的文件目录

            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");

            String path = "/home/image/";//保存到指定的文件目录
            String path2 = "imageAddress/" + userid + "/" + title + df.format(new Date());//保存到指定的文件目录
            File dir = new File(path + path2);
            if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
            }

            file.transferTo(new File(dir.getAbsolutePath() + File.separator + file.getOriginalFilename()));
            String name = "/" + path2 + "/" + file.getOriginalFilename();//获取图片的名字


            //返回id
            Integer imageId = imageService.insertImage(userid, title, text, classId, imageContent);

            imageService.insertImageAddress(imageId, name);


            return new Result(6, "上传成功");
        } else {
            return new Result(-13, "登录失效，请重新登录");
        }


    }


}
