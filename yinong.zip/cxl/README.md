# 易农平台项目设计文档
*By* ***陈乃垚、徐子健*** *2021.06*   
*[系统访问地址] (https://www.xiaochengya.xyz)*

## 功能设计
###	小程序端功能设计

> 1. 登录
> 2. 新用户注册
> 3. 忘记密码
> 4. 搜索查看种植技巧
> 5. 搜索查看种植病因
> 6. 首页随机刷新种植小知识
> 7. 首页推荐处按点赞数显示发布的帖子
> 8. 首页推荐处可查看帖子的评论，可实现点赞，收藏和评论帖子
> 9. 在百草谱可按类别显示各种农作物，点击农作物可查看详细内容
> 10. 在社区页面可按照时间先后显示全部帖子，可以查看全部帖子，也可以按照分类查看
> 11. 在社区页面点击发布帖子，可以实现帖子的发布
> 12. 在我的页面点击头像可以设置头像
> 13. 在我的页面点击点赞可以查看历史点赞的帖子
> 14. 在我的页面点击收藏可以查看历史收藏的帖子
> 15. 在我的页面点击帖子可以查看我发布的评论
> 16. 在我的页面点击意见反馈可以发布自己的意见
> 17. 在我的页面点击修改密码可以通过邮箱验证修改密码
> 18. 退出登录

### 后端管理功能设计

> 1. 登录
> 2. 首页管理：查看数据，更换首页图片
> 3. 用户管理：超级管理员删除普通用户，禁用管理员权限，管理员删除普通用户
> 4. 百科管理：查看上传百科数据，查看百科数据删除百科数据，修改百科数据
> 5. 帖子管理：查看所有帖子，下架帖子，上架帖子，删除帖子评论
> 6. 种植技巧管理：上传种植技巧，查看种植技巧，删除种植技巧
> 7. 种植病因管理：上传病因技巧，查看病因技巧，删除病因技巧

## 模块设计（Controller）

> 1. ClassController
> 2. CollectsController
> 3. CommentCategoryController
> 4. CommentController
> 5. CommentSonController
> 6. FeedBackController
> 7. HomeImageController
> 8. ImageController
> 9. LikesController
> 10. PathogenyController
> 11. PlantTechniqueController
> 12. UserController
> 4. UserPortraitAddressController
> 4. MsgSendController

## 易农模块设计
### 1. 数据表设计
- 百草谱类别表（class）
>| 字段 | 数据类型 | 说明 | 默认值 |
>| --- | --- | --- | --- |
>| classId | int | 类别id | 自动增长 |
>| className | varchar(255) | 类别名称 | 空 |
>| state | varchar(255) | ‘1’代表删除，'0'代表未删除 | 空 |

- 收藏表（collects）
>| 字段 | 数据类型 | 说明 | 默认值 |
>| --- | --- | --- | --- |
>| collectsId | int | 收藏Id | 自动增长 |
>| userId | int | 收藏者Id | 空 |
>| commentId | int | 帖子Id | 空 |
>| state | varchar(255) | ’0‘代表为删除 ’1‘代表删除 | 空 |
>| lastCollectsTime | datetime | 最后收藏时间 | 空 |

- 帖子表（comment）

>| 字段              | 数据类型      | 说明                       | 默认值   |
>| ----------------- | ------------- | -------------------------- | -------- |
>| commentId         | int           | 评论id                     | 自动增长 |
>| userid            | int           | 评论者id                   | 空       |
>| commentText       | varchar(1000) | 评论者评论                 | 空       |
>| commentTime       | datetime      | 评论者上传时间             | 空       |
>| likes             | varchar(255)  | 点赞数                     | 空       |
>| collects          | varchar(255)  | 收藏数                     | 空       |
>| comments          | varchar(255)  | 评论数                     | 空       |
>| state             | varchar(255)  | ‘1’代表删除，'0'代表未删除 | 空       |
>| commentCategoryId | int           | 发帖类别id                 | 空       |

- 帖子图片表（commentaddress）

>| 字段           | 数据类型     | 说明        | 默认值   |
>| -------------- | ------------ | ----------- | -------- |
>| commentId      | int          | commentId   | 自动增长 |
>| commentAddress | varchar(255) | comment地址 | 空       |

- 帖子类别表（commentcategory）

>| 字段                 | 数据类型     | 说明                       | 默认值   |
>| -------------------- | ------------ | -------------------------- | -------- |
>| commentCategoryId    | int          | 帖子类别Id                 | 自动增长 |
>| commentCategoryClass | varchar(255) | 帖子类别                   | 空       |
>| state                | varchar(255) | ‘1’代表删除，'0'代表未删除 | 空       |

- 帖子评论表（commentson）

>| 字段           | 数据类型     | 说明                       | 默认值   |
>| -------------- | ------------ | -------------------------- | -------- |
>| commentSonId   | int          | 帖子子评论Id               | 自动增长 |
>| userId         | int          | 发布评论者Id               | 空       |
>| commentId      | int          | 父帖子Id                   | 空       |
>| commentSonText | varchar(255) | 帖子子评论内容             | 空       |
>| state          | varchar(255) | ‘1’代表删除，'0'代表未删除 | 空       |
>| date           | datetime     | 评论时间                   | 空       |

- 反馈表（feedback）

>| 字段         | 数据类型     | 说明       | 默认值   |
>| ------------ | ------------ | ---------- | -------- |
>| feedBackId   | int          | 反馈Id     | 自动增长 |
>| feedBakcText | varchar(255) | 反馈内容   | 空       |
>| userId       | int          | 用户Id     | 空       |
>| phoneOrEmail | varchar(255) | 电话或邮箱 | 空       |
>| state        | varchar(255) | 0有  1 无  | 空       |

- 首页图片表（homeimage）

>| 字段             | 数据类型     | 说明         | 默认值   |
>| ---------------- | ------------ | ------------ | -------- |
>| homeImageId      | int          | 首页图片Id   | 自动增长 |
>| homeImageAddress | varchar(255) | 首页图片路径 | 空       |

- 百草谱表（image）

>| 字段         | 数据类型      | 说明                       | 默认值   |
>| ------------ | ------------- | -------------------------- | -------- |
>| imageId      | int           | 图片的自增id               | 自动增长 |
>| userid       | int           | 图片上用户id               | 空       |
>| imageTitle   | varchar(255)  | 图片标题                   | 空       |
>| imageText    | varchar(255)  | 图片内容                   | 空       |
>| classId      | int           | 类别id                     | 空       |
>| state        | varchar(255)  | ‘1’代表删除，'0'代表未删除 | 空       |
>| date         | datetime      | 上传时间                   | 空       |
>| imageContent | varchar(1000) | 详细内容                   | 空       |

- 百草谱图片表（image_address）

>| 字段         | 数据类型     | 说明     | 默认值   |
>| ------------ | ------------ | -------- | -------- |
>| imageId      | int          | 图片id   | 自动增长 |
>| imageAddress | varchar(255) | 图片地址 | 空       |

- 点赞表（likes）

>| 字段         | 数据类型     | 说明                       | 默认值   |
>| ------------ | ------------ | -------------------------- | -------- |
>| likesId      | int          | 喜欢Id                     | 自动增长 |
>| userId       | int          | 用户Id                     | 空       |
>| commentId    | int          | 帖子Id                     | 空       |
>| state        | varchar(255) | ‘1’代表删除，'0'代表未删除 | 空       |
>| lastLikeTime | datetime     | 最后点赞的时间             | 空       |

- 种植病因表（pathogeny）

>| 字段                  | 数据类型     | 说明         | 默认值   |
>| --------------------- | ------------ | ------------ | -------- |
>| pathogenyId           | int          | 病因Id       | 自动增长 |
>| pathogenyTitle        | varchar(255) | 病因标题     | 空       |
>| pathogenyText         | varchar(255) | 病因内容     | 空       |
>| pathogenyImageAddress | varchar(255) | 病因图片地址 | 空       |
>| state                 | varchar(255) | 0是有  1是无 | 空       |
>| time                  | datetime     | 时间         | 空       |

- 种植病因子表（pathogenyson）

>| 字段                     | 数据类型     | 说明       | 默认值   |
>| ------------------------ | ------------ | ---------- | -------- |
>| pathogenyId              | int          | 病因Id     | 自动增长 |
>| pathogenySonTitle        | varchar(255) | 病因子标题 | 空       |
>| pathogenySonText         | varchar(255) | 病因子内容 | 空       |
>| pathogenySonImageAddress | varchar(255) | 病因子图片 | 空       |

- 种植技巧表（planttechnique）

>| 字段                       | 数据类型      | 说明              | 默认值   |
>| -------------------------- | ------------- | ----------------- | -------- |
>| plantTechniqueId           | int           | 种植技巧id        | 自动增长 |
>| plantTechniqueTitle        | varchar(255)  | 种植标题          | 空       |
>| plantTechniqueText         | varchar(1000) | 种植内容          | 空       |
>| plantTechniqueImageAddress | varchar(255)  | 种植首页图片      | 空       |
>| state                      | varchar(255)  | 0是未删除 1是删除 | 空       |
>| time                       | datetime      | 上传时间          | 空       |

- 种植技巧子表（planttechniqueson）

>| 字段                          | 数据类型      | 说明       | 默认值   |
>| ----------------------------- | ------------- | ---------- | -------- |
>| plantTechniqueId              | int           | 种植技巧id | 自动增长 |
>| plantTechniqueSonTitle        | varchar(255)  | 标题       | 空       |
>| plantTechniqueSonText         | varchar(1000) | 内容       | 空       |
>| plantTechniqueSonImageAddress | varchar(255)  | 图片       | 空       |

- 用户表（user）

>| 字段     | 数据类型     | 说明                       | 默认值   |
>| -------- | ------------ | -------------------------- | -------- |
>| userid   | int          | 用户id                     | 自动增长 |
>| username | varchar(255) | 用户名称                   | 空       |
>| password | varchar(255) | 用户密码                   | 空       |
>| state    | varchar(255) | ‘1’代表删除，'0'代表未删除 | 空       |
>| email    | varchar(255) | 用户绑定的邮箱             | 空       |
>| token    | varchar(255) | 用户登录token              | 空       |

- 用户头像表（user_portrait_address）

>| 字段             | 数据类型     | 说明         | 默认值   |
>| ---------------- | ------------ | ------------ | -------- |
>| userid           | int          | 用户id       | 自动增长 |
>| portrait_Address | varchar(255) | 用户头像地址 | 空       |

- 用户权限表表（user_role）

>| 字段   | 数据类型     | 说明           | 默认值   |
>| ------ | ------------ | -------------- | -------- |
>| userid | int          | user表的userid | 自动增长 |
>| role   | varchar(255) | user的权限     | 空       |

### 2. 相关SQL

#### 2.1 建库
     CREATE SCHEMA `yinong` DEFAULT CHARACTER SET utf8 ;

#### 2.2 建表
- 百草谱类别表（class）  
>      CREATE TABLE `class` (
>        `classId` int NOT NULL COMMENT '类别id',
>        `className` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '类别名称',
>        `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '‘1’代表删除，''0''代表未删除',
>        PRIMARY KEY (`classId`) USING BTREE
>      ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 收藏表（collects）  
>      CREATE TABLE `collects` (
>        `collectsId` int NOT NULL AUTO_INCREMENT COMMENT '收藏Id',
>        `userId` int DEFAULT NULL COMMENT '收藏者Id',
>        `commentId` int DEFAULT NULL COMMENT '帖子Id',
>        `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '’0‘代表为删除 ’1‘代表删除',
>        `lastCollectsTime` datetime DEFAULT NULL COMMENT '最后收藏时间',
>        PRIMARY KEY (`collectsId`) USING BTREE
>      ) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 帖子表（comment）  

>      CREATE TABLE `comment` (
>        `commentId` int NOT NULL AUTO_INCREMENT COMMENT '评论id',
>        `userid` int DEFAULT NULL COMMENT '评论者id',
>        `commentText` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '评论者评论',
>        `commentTime` datetime DEFAULT NULL COMMENT '评论者上传时间',
>        `likes` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '点赞数',
>        `collects` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收藏数',
>        `comments` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '评论数',
>        `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '‘1’代表删除，''0''代表未删除',
>        `commentCategoryId` int DEFAULT NULL COMMENT '发帖类别id',
>        PRIMARY KEY (`commentId`) USING BTREE
>      ) ENGINE=InnoDB AUTO_INCREMENT=214 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 帖子图片表（commentAddress）  

>      CREATE TABLE `commentAddress` (
>        `commentId` int NOT NULL COMMENT 'commentId',
>        `commentAddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'comment地址'
>      ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 帖子类别表（commentCategory）  

>      CREATE TABLE `commentCategory` (
>        `commentCategoryId` int NOT NULL AUTO_INCREMENT COMMENT '帖子类别Id',
>        `commentCategoryClass` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '帖子类别',
>        `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '‘1’代表删除，''0''代表未删除',
>        PRIMARY KEY (`commentCategoryId`) USING BTREE
>      ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 帖子评论表（commentSon）  

>      CREATE TABLE `commentSon` (
>        `commentSonId` int NOT NULL AUTO_INCREMENT COMMENT '帖子子评论Id',
>        `userId` int DEFAULT NULL COMMENT '发布评论者Id',
>        `commentId` int DEFAULT NULL COMMENT '父帖子Id',
>        `commentSonText` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '帖子子评论内容',
>        `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '‘1’代表删除，''0''代表未删除',
>        `date` datetime DEFAULT NULL COMMENT '评论时间',
>        PRIMARY KEY (`commentSonId`) USING BTREE
>      ) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 反馈表（feedBack）  

>      CREATE TABLE `feedBack` (
>        `feedBackId` int NOT NULL AUTO_INCREMENT COMMENT '反馈Id',
>        `feedBakcText` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '反馈内容',
>        `userId` int DEFAULT NULL COMMENT '用户Id',
>        `phoneOrEmail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '电话或邮箱',
>        `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '0有  1 无',
>        PRIMARY KEY (`feedBackId`) USING BTREE
>      ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 首页图片表（homeImage）  

>      CREATE TABLE `homeImage` (
>        `homeImageId` int NOT NULL COMMENT '首页图片Id',
>        `homeImageAddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '首页图片路径',
>        PRIMARY KEY (`homeImageId`) USING BTREE
>      ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 百草谱表（image）  

>      CREATE TABLE `image` (
>        `imageId` int NOT NULL AUTO_INCREMENT COMMENT '图片的自增id',
>        `userid` int DEFAULT NULL COMMENT '图片上用户id',
>        `imageTitle` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '图片标题',
>        `imageText` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '图片内容',
>        `classId` int DEFAULT NULL COMMENT '类别id',
>        `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '‘1’代表删除，''0''代表未删除',
>        `date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '上传时间',
>        `imageContent` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细内容',
>        PRIMARY KEY (`imageId`) USING BTREE
>      ) ENGINE=InnoDB AUTO_INCREMENT=323 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 百草谱图片表（image_Address）  

>      CREATE TABLE `image_Address` (
>        `imageId` int NOT NULL COMMENT '图片id',
>        `imageAddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '图片地址',
>        PRIMARY KEY (`imageId`) USING BTREE
>      ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 点赞表（likes）  

>      CREATE TABLE `likes` (
>        `likesId` int NOT NULL AUTO_INCREMENT COMMENT '喜欢Id',
>        `userId` int DEFAULT NULL COMMENT '用户Id',
>        `commentId` int DEFAULT NULL COMMENT '帖子Id',
>        `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '‘1’代表删除，''0''代表未删除',
>        `lastLikeTime` datetime DEFAULT NULL COMMENT '最后点赞的时间',
>        PRIMARY KEY (`likesId`) USING BTREE
>      ) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 种植病因表（pathogeny）  

>      CREATE TABLE `pathogeny` (
>        `pathogenyId` int NOT NULL AUTO_INCREMENT COMMENT '病因Id',
>        `pathogenyTitle` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '病因标题',
>        `pathogenyText` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '病因内容',
>        `pathogenyImageAddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '病因图片地址',
>        `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '0是有  1是无',
>        `time` datetime DEFAULT NULL COMMENT '时间',
>        PRIMARY KEY (`pathogenyId`) USING BTREE
>      ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 种植病因子表（pathogenySon）  

>      CREATE TABLE `pathogenySon` (
>        `pathogenyId` int NOT NULL COMMENT '病因Id',
>        `pathogenySonTitle` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '病因子标题',
>        `pathogenySonText` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '病因子内容',
>        `pathogenySonImageAddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '病因子图片',
>        PRIMARY KEY (`pathogenyId`) USING BTREE
>      ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 种植技巧表（plantTechnique）  

>      CREATE TABLE `plantTechnique` (
>        `plantTechniqueId` int NOT NULL AUTO_INCREMENT COMMENT '种植技巧id',
>        `plantTechniqueTitle` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '种植标题',
>        `plantTechniqueText` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '种植内容',
>        `plantTechniqueImageAddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '种植首页图片',
>        `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '0是未删除 1是删除',
>        `time` datetime DEFAULT NULL COMMENT '上传时间',
>        PRIMARY KEY (`plantTechniqueId`) USING BTREE
>      ) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 种植技巧子表（plantTechniqueSon）  

>      CREATE TABLE `plantTechniqueSon` (
>        `plantTechniqueId` int DEFAULT NULL COMMENT '种植技巧id',
>        `plantTechniqueSonTitle` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '标题',
>        `plantTechniqueSonText` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '内容',
>        `plantTechniqueSonImageAddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '图片'
>      ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 用户表（user）  

>      CREATE TABLE `user` (
>        `userid` int NOT NULL AUTO_INCREMENT COMMENT '用户id',
>        `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户名称',
>        `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户密码',
>        `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '‘1’代表删除，''0''代表未删除',
>        `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户绑定的邮箱',
>        `token` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户登录token',
>        PRIMARY KEY (`userid`) USING BTREE
>      ) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 用户头像表（user_Portrait_Address）  

>      CREATE TABLE `user_Portrait_Address` (
>        `userid` int NOT NULL COMMENT '用户id',
>        `portrait_Address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户头像地址',
>        PRIMARY KEY (`userid`) USING BTREE
>      ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

- 用户权限表（user_Role）  

>      CREATE TABLE `user_Role` (
>        `userid` int NOT NULL COMMENT 'user表的userid',
>        `role` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'user的权限',
>        PRIMARY KEY (`userid`) USING BTREE
>      ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

#### 2.3 测试数据
    /*class测试数据*/
    INSERT INTO class VALUES('1','123','1');
    
    /*collects测试数据*/
    INSERT INTO collects VALUES('1','1','1','123','2022/6/9')
    
    /*comment测试数据*/
    INSERT INTO comment VALUES('1','1','123','2022/6/9','123','123','123','123','1')
    
    /*commentaddress测试数据*/
    INSERT INTO commentaddress VALUES('1','123')
    
    /*commentcategory测试数据*/
    INSERT INTO commentcategory VALUES('1','123','123')
    
    /*commentson测试数据*/
    INSERT INTO commentson VALUES('1','1','1','123','123','2022/6/9')
    
    /*feedback测试数据*/
    INSERT INTO feedback VALUES('1','123','1','123','123')
    
    /*homeimage测试数据*/
    INSERT INTO homeimage VALUES('1','123')
    
    /*image测试数据*/
    INSERT INTO image VALUES('1','1','123','123','1','123','2022/6/9','123')
    
    /*image_address测试数据*/
    INSERT INTO image_address VALUES('1','123')
    
    /*likes测试数据*/
    INSERT INTO likes VALUES('1','1','1','123','2022/6/9')
    
    /*pathogeny测试数据*/
    INSERT INTO pathogeny VALUES('1','123','123','123','123','2022/6/9')
    
    /*pathogenyson测试数据*/
    INSERT INTO pathogenyson VALUES('1','123','123','123')
    
    /*planttechnique测试数据*/
    INSERT INTO planttechnique VALUES('1','123','123','123','123','2022/6/9')
    
    /*planttechniqueson测试数据*/
    INSERT INTO planttechniqueson VALUES('1','123','123','123')
    
    /*user测试数据*/
    INSERT INTO user VALUES('1','123','123','123','123','123')
    
    /*user_portrait_address测试数据*/
    INSERT INTO user_portrait_address VALUES('1','123')
    
    /*user_role测试数据*/
    INSERT INTO user_role VALUES('1','123') 


### 3. 接口设计
#### 3.1 ClassController
**@GetMapping("/getAllClassName")**

>接口说明 ：类别查询
>接口地址 ：https://www.xiaochenya.xyz:8085/getAllClassName
>输入参数 ：无
>
>返回值 ：code=5    date=classNameListAndCountClass
>返回值说明 ：code=5		查询成功
>
>​								date			查询到的总类别和总条数

 **@PostMapping("/selectByClassName")**
>接口说明 ：根据类别查询全部图片
>接口地址 ：https://www.xiaochenya.xyz:8085/selectByClassName
>
>输入参数 ：json对象参数 { 
>
>​				'className' : '类别'
>
>​				} 
>
>返回值 ：code=5&&data:images   code=-10
>返回值说明 ：code=5		查询成功  data:images 图片数组
>
>​								code=-10	查询失败，未查询到数据

**@PostMapping("/selectByClassName1")**

>接口说明 ：根据类别在image表查询全部信息并分页显示
>接口地址 ：https://www.xiaochenya.xyz:8085/selectByClassName1
>
>输入参数 ：json对象参数 { 
>
>​				"className":"类别"
>
>​				"pages":"第几页"
>
>​				} 
>
>返回值 ：code=20&&data=m1
>返回值说明 ：code=20:查询成功 data:查询到的值

 **@PostMapping("/selectByImageId")**

>接口说明 ：根据图片id查询全部图片
>接口地址 ：https://www.xiaochenya.xyz:8085/selectByImageId
>
>输入参数 ：json对象参数 { 
>
>​				'imageId' : '图片Id'
>
>​				} 
>
>返回值 ：code=5&&data:images   code=-10
>返回值说明 ：code=5		查询成功 data:images图片数组
>
>​								code=-10	查询失败，未查询到数据

#### 3.2 CollectsController
**@PostMapping("/collects")**

>接口说明 ：收藏
>接口地址 ：https://www.xiaochenya.xyz:8085/collects
>
>输入参数 ：json对象参数 { 
>
>​				'userId' : '用户Id'
>
>​				'commentId':'被收藏帖id'
>
>​				'token':'token'
>
>​				} 
>
>返回值 ：code=14		code=15		code=16		code=-13
>返回值说明 ：code=14		收藏成功 之前未收藏
>
>​								code=15		修改成功 取消收藏
>
>​								code=16		修改成功 收藏
>
>​								code=-13		登录失效，请重新登录

#### 3.3 CommentCategoryController
 **@GetMapping("/selectAllCommentCategory")**

>接口说明 ：查询全部comment类别
>接口地址 ：https://www.xiaochenya.xyz:8085/selectAllCommentCategory
>输入参数 ：json对象参数 { 
>
>​				无'
>
>} 
>
>返回值 ：code=5  
>返回值说明 ：code=5		查询成功

#### 3.4 CommentController

 **@PostMapping("/selectCommentByIdAndTokenAndLike")**

>接口说明 ：根据userid和token查询全部likes的comment
>接口地址 ：https://www.xiaochenya.xyz:8085/selectCommentByIdAndTokenAndLike
>输入参数 ：json对象参数 { 
>
>​				'userid':'userid'
>
>​				'token' : 'token'
>
>} 
>
>返回值 ：code=5  code=-13
>返回值说明 ：code=5		查询成功
>
>​								code=-13      登录失效，请重新登录

 **@PostMapping("/selectCommentByIdAndTokenAndCollect")**

>接口说明 ：根据userid和token查询全部collects的comment
>接口地址 ：https://www.xiaochenya.xyz:8085/selectCommentByIdAndTokenAndCollect
>输入参数 ：json对象参数 { 
>
>​				'userid':'userid'
>
>​				'token' : 'token'
>
>} 
>
>返回值 ：code=5  code=-13
>返回值说明 ：code=5		查询成功
>
>​								code=-13      登录失效，请重新登录

**@PostMapping("/deleteCommentIdByUserId")**

>接口说明 ：根据userid和token和commentId删除帖子
>接口地址 ：https://www.xiaochenya.xyz:8085/deleteCommentIdByUserId
>输入参数 ：json对象参数 { 
>
>​				'userid':'userid'
>
>​				'token' : 'token'
>
>​				'commentId':'commentId'
>
>} 
>
>返回值 ：code=22  code=-13
>返回值说明 ：code=22		删除成功
>
>​								code=-13      登录失效，请重新登录

**@PostMapping("/deleteCommentIdByAdminUserId")**

>接口说明 ：根据userid和token和commentId删除帖子  管理员删除
>接口地址 ：https://www.xiaochenya.xyz:8085/deleteCommentIdByAdminUserId
>输入参数 ：json对象参数 { 
>
>​				'userid':'userid'
>
>​				'token' : 'token'
>
>​				'commentId':'commentId'
>
>} 
>
>返回值 ：code=30  code=-13
>返回值说明 ：code=30		下架成功
>
>​								code=-13      登录失效，请重新登录

**@PostMapping("/unDeleteCommentIdByAdminUserId")**

>接口说明 ：根据userid和token和commentId上架帖子  管理员上架
>接口地址 ：https://www.xiaochenya.xyz:8085/unDeleteCommentIdByAdminUserId
>输入参数 ：json对象参数 { 
>
>​				'userid':'userid'
>
>​				'token' : 'token'
>
>​				'commentId':'commentId'
>
>} 
>
>返回值 ：code=29  code=-13
>返回值说明 ：code=29		上架成功
>
>​								code=-13      登录失效，请重新登录

**@GetMapping("/selectAllCommentByAdminDelete")**

>接口说明 ：查询全部下架的帖子
>接口地址 ：https://www.xiaochenya.xyz:8085/selectAllCommentByAdminDelete
>
>输入参数 ：参数 { 
>
>​				'userid':'userid'
>
>​				'index':'页数'
>
>​				} 
>
>返回值 ：code=5  date:comments  code=23
>返回值说明 ：code=5:查询成功
>
>​								code=23:查询成功 已经是最后一页
>
>​								date:查询到的数据

**@PostMapping("/selectCommentByCommentIdAndAdminDelete")**

>接口说明 ：通过Id查询管理员删除的帖子
>接口地址 ：https://www.xiaochenya.xyz:8085/selectCommentByCommentIdAndAdminDelete
>输入参数 ：json对象参数 { 
>
>​				'commentId':'commentId'
>
>} 
>
>返回值 ：code=5 code=-13
>返回值说明 ：code=5		查询成功
>
>​								code=-13      登录失效，请重新登录

 **@PostMapping("/selectCommentByCommentId")**

>接口说明 ：根据帖子id查询帖子
>接口地址 ：https://www.xiaochenya.xyz:8085/selectCommentByCommentId
>
>输入参数 ：json对象参数 { 
>
>​				"commentId":"帖子id"
>
>​				} 
>
>返回值 ：code=5  date:comments
>返回值说明 ：code=5:查询成功
>
>​								date:查询到的数据

 **@GetMapping("/selectAllComment")**

>接口说明 ：查询全部的帖子
>接口地址 ：https://www.xiaochenya.xyz:8085/selectAllComment
>
>输入参数 ：参数 { 
>
>​				'userid':'userid'
>
>​				'index':'页数'
>
>​				} 
>
>返回值 ：code=5  date:comments  code=23
>返回值说明 ：code=5:查询成功
>
>​								code=23:查询成功 已经是最后一页
>
>​								date:查询到的数据

**@GetMapping("/selectAllCommentOrderByLikes")**

>接口说明 ：查询全部的帖子按照喜欢数量返回
>接口地址 ：https://www.xiaochenya.xyz:8085/selectAllCommentOrderByLikes
>
>输入参数 ：参数 { 
>
>​				'userid':'userid'
>
>​				'index':'页数'
>
>​				} 
>
>返回值 ：code=5  date:comments  code=23
>返回值说明 ：code=5:查询成功
>
>​								code=23:查询成功 已经是最后一页
>
>​								date:查询到的数据

 **@PostMapping("/selectCommentByCommentCategoryClass")**

>接口说明 ：根据类别查询帖子
>接口地址 ：https://www.xiaochenya.xyz:8085/selectCommentByCommentCategoryClass
>
>输入参数 ：json对象参数 { 
>
>​				"commentCategoryId":"类别名字"
>
>​				"userid":"用户id"
>
>​				"index":"页数"
>
>​				} 
>
>返回值 ：code=-16      code=5  date:comments   code=23
>返回值说明 ：code=5:查询成功
>
>​								code=23:查询成功 已经是最后一页
>
>​								code=-16:查询失败，未查询到该类
>
>​								date:查询到的数据

**@PostMapping("/selectCommentsByUserId")**

>接口说明 ：根据userid和token查询全部帖子
>接口地址 ：https://www.xiaochenya.xyz:8085/selectCommentsByUserId
>输入参数 ：json对象参数 { 
>
>​				'userid':'userid'
>
>​				'token' : 'token'
>
>} 
>
>返回值 ：code=5  code=-13
>返回值说明 ：code=5		查询成功
>
>​								code=-13      登录失效，请重新登录

 **@PostMapping("/commentQianZhi")**

>接口说明 ：先发布无图片的帖子
>接口地址 ：https://www.xiaochenya.xyz:8085/commentQianZhi
>
>输入参数 ：form data参数 { 
>
>​				'userId' : '用户Id'
>
>​				'commentText':'文字'
>
>​				'token':'token'
>
>​				'commentCategoryClass':'帖子类别'
>
>​				} 
>
>返回值 ：code=-15     code=-13     code=17 && date=commentId
>返回值说明 ：code=-15		发帖类别不存在
>
>​								code=-13	登录失效，请重新登录
>
>​								code=17	插入comment成功   commentId=帖子id

**@PostMapping("/commentAddImage")**

>接口说明 ：实现文件上传
>接口地址 ：https://www.xiaochenya.xyz:8085/commentAddImage
>
>输入参数 ：form data参数 { 
>
>​				'userId' : '用户Id'
>
>​				'commentId':'帖子Id'
>
>​				'token':'token'
>
>​				'files':'文件'
>
>​				} 
>
>返回值 ：code=18     code=-13  
>
>返回值说明 ：	code=-13	登录失效，请重新登录
>
>​								code=18	根据commentId向commentAddress插入数据成功

#### 3.5 CommentSonController

 **@PostMapping("/updateCommentSonState")**

>接口说明 ：删除帖子评论
>接口地址 ：https://www.xiaochenya.xyz:8085/updateCommentSonState
>输入参数 ：json对象参数 { 
>
>​				"userId":"用户id"
>
>​				"commentSonId":"帖子评论Id"
>
>​				"token":"token"
>
>​				} 
>
>返回值 ：code=28   code=-13
>返回值说明 ：code=28		删除评论成功
>
>​								code=-13      登录失效，请重新登录

**@PostMapping("/commentSon")**

>接口说明 ：评论
>接口地址 ：https://www.xiaochenya.xyz:8085/commentSon
>
>输入参数 ：json对象参数 { 
>
>​				'userId' : '用户Id'
>
>​				'commentId':'父帖子id'
>
>​				'commentSonText':'评论文字'
>
>​				'token':'token'
>
>​				} 
>
>返回值 ：code=10		code=-13
>返回值说明 ：code=10		评论成功
>
>​								code=-13		登录失效，请重新登录

**@PostMapping("/selectCommentSonByCommentId")**

>接口说明 ：根据帖子id查询评论
>接口地址 ：https://www.xiaochenya.xyz:8085/selectCommentSonByCommentId
>
>输入参数 ：json对象参数 { 
>
>​				"commentId":"帖子id"
>
>​				} 
>
>返回值 ：code=5  date:commentSonList
>返回值说明 ：code=5:查询成功
>
>​								date:查询到的数据

**@PostMapping("/selectCommentSonByAmdinDeleteCommentId")**

>接口说明 ：通过Id查询管理员下架帖子的评论
>接口地址 ：https://www.xiaochenya.xyz:8085/selectCommentSonByAmdinDeleteCommentId
>输入参数 ：json对象参数 { 
>
>​				'commentId':'commentId'
>
>} 
>
>返回值 ：code=5 
>返回值说明 ：code=5		查询成功

#### 3.6 FeedBackController

 **@PostMapping("/insertFeedBack")**

>接口说明 ：提交反馈
>接口地址 ：https://www.xiaochenya.xyz:8085/insertFeedBack
>输入参数 ：formdata参数 { 
>
>​				"userId":"用户id"
>
>​				"token":"token"
>
>​				"feedBakcText":"反馈内容"
>
>​				"phoneOrEmail":"电话号码或邮箱''
>
>} 
>
>返回值 ：	code=36				code=-13		
>
>返回值说明 ：	code=36		提交反馈成功
>
>​									code=-13		登录失效，请重新登录

**@GetMapping("/selectAllFeedBackByPage")**

>接口说明 ：查询全部反馈 分页显示
>接口地址 ：https://www.xiaochenya.xyz:8085/selectAllFeedBackByPage
>输入参数 ：参数 { 
>
>​				"page":"页数"
>
>} 
>
>返回值 ：code=23		code=5		
>
>返回值说明 ：code=23		查询成功已是最后一页
>
>​								code=5		查询成功

**@PostMapping("/updateFeedBackState")**

>接口说明 ：删除反馈
>接口地址 ：https://www.xiaochenya.xyz:8085/updateFeedBackState
>输入参数 ：formdata参数 { 
>
>​				"userId":"userId"
>
>​				"token":"token"
>
>​				"feedBackId":"反馈id"
>
>} 
>
>返回值 ：code=37		code=-13		
>
>返回值说明 ：code=37		删除反馈成功
>
>​								code=-13		登录失效，请重新登录

#### 3.7 HomeImageController

**@GetMapping("/selectHomeImageAddress")**

>接口说明 ：查询图片路径
>接口地址 ：https://www.xiaochenya.xyz:8085/selectHomeImageAddress
>输入参数 ：参数 { 
>
>​				无
>
>} 
>
>返回值 ：code=5  
>返回值说明 ：code=5		查询成功

**@PostMapping("/changeHomeAddimage")**

>接口说明 ：修改首页图片
>接口地址 ：https://www.xiaochenya.xyz:8085/changeHomeAddimage
>输入参数 ：formdata参数 { 
>
>​				"userId":"用户id"
>
>​				"token":"token"
>
>​				"files":"文件"
>
>} 
>
>返回值 ：code=21     code=-13  
>返回值说明 ：code=21		修改成功，更新图片
>
>​								code=-13      	登录失效，请重新登录

#### 3.8 ImageController

 **@PostMapping("/changeAddimages")**

>接口说明 ：修改图片
>接口地址 ：https://www.xiaochenya.xyz:8085/changeAddimages
>输入参数 ：form data参数 { 
>
>​				'imageId':'imageid'
>
>​				'userId' : '管理员id'
>
>​				'files':'图片'	
>
>​				'token':'token'
>
>​				} 
>
>返回值 ：code=21   code=-13
>返回值说明 ：code=6		修改成功
>
>​								code=-13      登录失效，请重新登录

**@PostMapping("/changeAddimages2")**

>接口说明 ：修改数据
>接口地址 ：https://www.xiaochenya.xyz:8085/changeAddimages2
>输入参数 ：form data参数 { 
>
>​				'imageId':'imageid'
>
>​				'userId' : '管理员id'
>
>​				'imageTitle':'标题'
>
>​				'imageText':'内容'
>
>​				'className':'类别'
>
>​				'token':'token'
>
>​				'imageContent':'详细内容'
>
>​				} 
>
>返回值 ：code=21   code=-13
>返回值说明 ：code=6		修改成功
>
>​								code=-13      登录失效，请重新登录

**@PostMapping("/deleteAddimages")**

>接口说明 ：删除addimage
>接口地址 ：https://www.xiaochenya.xyz:8085/deleteAddimages
>
>输入参数 ：json对象参数 { 
>
>​				"imageId":"id"
>
>​				} 
>
>返回值 ：code=18
>返回值说明 ：code=18:删除addimage成功

**@PostMapping("/addimages")**

>接口说明 ：图片上传
>接口地址 ：https://www.xiaochenya.xyz:8085/addimages
>输入参数 ：form data参数 { 
>
>​				'userId' : '管理员id'
>
>​				'imageTitle':'标题'
>
>​				'imageText':'内容'
>
>​				'className':'类别'
>
>​				'files':'图片'	
>
>​				'token':'token'
>
>​				'imageContent':'详细内容'
>
>​				} 
>
>返回值 ：code=6   code=-13
>返回值说明 ：code=6		上传成功
>
>​								code=-13      登录失效，请重新登录

#### 3.9 LikesController

**@PostMapping("/likes")**

>接口说明 ：点赞
>接口地址 ：https://www.xiaochenya.xyz:8085/likes
>
>输入参数 ：json对象参数 { 
>
>​				'userId' : '用户Id'
>
>​				'commentId':'被点赞帖id'
>
>​				'token':'token'
>
>​				} 
>
>返回值 ：code=11		code=12		code=13		code=-13
>返回值说明 ：code=11		点赞成功 之前未点赞
>
>​								code=12		修改成功 取消赞
>
>​								code=13		修改成功 点赞
>
>​								code=-13		登录失效，请重新登录

#### 4.0 PathogenyController

**@PostMapping("/selectPathogney")**

>接口说明 ：根据标题like查询病因
>接口地址 ：https://www.xiaochenya.xyz:8085/selectPathogney
>输入参数 ：formdata参数 { 
>
>​				"page":"页数"
>
>​				"pathogenyTitle":"标题"
>
>} 
>
>返回值 ：code=23		code=5		
>
>返回值说明 ：code=23		查询成功已是最后一页
>
>​								code=5		查询成功

**@PostMapping("/updatePathogneyByPathogneyId")**

>接口说明 ：根据pathogneyId删除pathogney
>接口地址 ：https://www.xiaochenya.xyz:8085/updatePathogneyByPathogneyId
>输入参数 ：formdata参数 { 
>
>​				"userId":"用户id"
>
>​				"token":"token"
>
>​				"pathogneyId":"pathogneyId"
>
>} 
>
>返回值 ：	code=43		code=-23		code=-13		
>
>返回值说明 ：	code=43		删除病因查询成功
>
>​									code=-23		删除病因查询失败
>
>​									code=-13		登录失效，请重新登录

**@PostMapping("/selectAllPathogenySon")**

>接口说明 ：根据pathogenyId获取全部病因查询子信息
>接口地址 ：https://www.xiaochenya.xyz:8085/selectAllPathogenySon
>输入参数 ：formdata参数 { 
>
>​				"pathogenyId":"pathogenyId"
>
>} 
>
>返回值 ：	code=5		
>
>返回值说明 ：	code=5		查询成功

**@GetMapping("/selectAllPathogeny")**

>接口说明 ：获取全部病因查询 分页显示
>接口地址 ：https://www.xiaochenya.xyz:8085/selectAllPathogeny
>输入参数 ：参数 { 
>
>​				"page":"页数"
>
>} 
>
>返回值 ：code=23		code=5		
>
>返回值说明 ：code=23		查询成功已是最后一页
>
>​								code=5		查询成功

**@PostMapping("/addPathogenyQianZhi")**

>接口说明 ：实现上传病因查询前置
>接口地址 ：https://www.xiaochenya.xyz:8085/addPathogenyQianZhi
>输入参数 ：formdata参数 { 
>
>​				"userId":"上传者Id"
>
>​				"token":"token"
>
>​				"pathogenyTitle":"标题"
>
>​				"pathogenyText":"内容"
>
>​				"pathogenyImageAddress":"文件"
>
>} 
>
>返回值 ：code=31&data		code=-13
>
>返回值说明 ：code=41		插入病因成功   date=pathogenyId
>
>​								code=-13		登录失效，请重新登录

**@PostMapping("/addPathogenyHouZhi")**

>接口说明 ：上传病因查询后置
>接口地址 ：https://www.xiaochenya.xyz:8085/addPathogenyHouZhi
>输入参数 ：formdata参数 { 
>
>​				"userId":"上传者Id"
>
>​				"token":"token"
>
>​				"pathogenyId":"病因查询id"
>
>​				"pathogenySonTitle":"病因查询SonTitle"
>
>​				"pathogenySonText":"病因查询SonText"
>
>​				"pathogenySonImageAddress":"文件"
>
>} 
>
>返回值 ：code=42		code=-13
>
>返回值说明 ：code=42		插入病因查询Son成功  
>
>​								code=-13		登录失效，请重新登录

#### 4.1 PlantTechniqueController

**@PostMapping("/selectPlantTechnique")**

>接口说明 ：根据标题like查询技巧
>接口地址 ：https://www.xiaochenya.xyz:8085/selectPlantTechnique
>输入参数 ：formdata参数 { 
>
>​				"page":"页数"
>
>​				"plantTechniqueTitle":"标题"
>
>} 
>
>返回值 ：code=23		code=5		
>
>返回值说明 ：code=23		查询成功已是最后一页
>
>​								code=5		查询成功

**@GetMapping("/getPlantTechniqueSonText")**

>接口说明 ：随机返回种植技巧里面的一个技巧内容
>接口地址 ：https://www.xiaochenya.xyz:8085/getPlantTechniqueSonText
>输入参数 ：参数 { 
>
>​				无
>
>} 
>
>返回值 ：code=44
>
>返回值说明 ：code=44 随机返回技巧成功

**@PostMapping("/updatePlantTechniqueByPlantTechniqueId")**

>接口说明 ：根据plantTechniqueId删除plantTechnique
>接口地址 ：https://www.xiaochenya.xyz:8085/updatePlantTechniqueByPlantTechniqueId
>输入参数 ：formdata参数 { 
>
>​				"userId":"用户id"
>
>​				"token":"token"
>
>​				"plantTechniqueId":"plantTechniqueId"
>
>} 
>
>返回值 ：	code=35		code=-21		code=-13		
>
>返回值说明 ：	code=35		删除种植技巧成功
>
>​									code=-21		删除种植技巧失败
>
>​									code=-13		登录失效，请重新登录

**@PostMapping("/selectAllPlantTechniqueSon")**

>接口说明 ：根据plantTechniqueId获取全部plantTechniqueSon信息
>接口地址 ：https://www.xiaochenya.xyz:8085/selectAllPlantTechniqueSon
>输入参数 ：formdata参数 { 
>
>​				"plantTechniqueId":"plantTechniqueId"
>
>} 
>
>返回值 ：	code=5		
>
>返回值说明 ：	code=5		查询成功

**@GetMapping("/selectAllPlantTechnique")**

>接口说明 ：获取全部种植技巧 分页显示
>接口地址 ：https://www.xiaochenya.xyz:8085/selectAllPlantTechnique
>输入参数 ：参数 { 
>
>​				"page":"页数"
>
>} 
>
>返回值 ：code=23		code=5		
>
>返回值说明 ：code=23		查询成功已是最后一页
>
>​								code=5		查询成功

**@PostMapping("/addPlantTechniqueQianZhi")**

>接口说明 ：实现上传种植技巧前置
>接口地址 ：https://www.xiaochenya.xyz:8085/addPlantTechniqueQianZhi
>输入参数 ：formdata参数 { 
>
>​				"userId":"上传者Id"
>
>​				"token":"token"
>
>​				"plantTechniqueTitle":"标题"
>
>​				"plantTechniqueText":"内容"
>
>​				"plantTechinqueImageAddress":"文件"
>
>} 
>
>返回值 ：code=31&data		code=-13
>
>返回值说明 ：code=31		插入种植技巧成功   date=plantTechniqueId
>
>​								code=-13		登录失效，请重新登录

**@PostMapping("/addPlantTechniqueHouZhi")**

>接口说明 ：上传种植技巧后置
>接口地址 ：https://www.xiaochenya.xyz:8085/addPlantTechniqueHouZhi
>输入参数 ：formdata参数 { 
>
>​				"userId":"上传者Id"
>
>​				"token":"token"
>
>​				"plantTechniqueId":"种植技巧id"
>
>​				"plantTechniqueSonTitle":"种植技巧SonTitle"
>
>​				"plantTechniqueSonText":"种植技巧SonText"
>
>​				"plantTechniqueSonImageAddress":"文件"
>
>} 
>
>返回值 ：code=32		code=-13
>
>返回值说明 ：code=32		插入种植技巧Son成功  
>
>​								code=-13		登录失效，请重新登录

#### 4.2 UserController

**@PostMapping("/updateUserRole")**

>接口说明 ：修改管理员权限     admin和unAdmin互相转换
>接口地址 ：https://www.xiaochenya.xyz:8085/updateUserRole
>输入参数 ：formdata参数 { 
>
>​				"userId":"操作者Id"
>
>​				"token":"token"
>
>​				"adminUserId":"被操作者Id"
>
>} 
>
>返回值 ：code=39			code=40			code=-22		code=-13			
>
>返回值说明 ：code=39		修改成功 变为umAdmin
>
>​								code=40			修改成功 变为admin
>
>​									code=-22			不是超级管理员不可操作
>
>​									code=-13			登录失效，请重新登录

**@GetMapping("/selectAllAdminAndUnAdmin")**

>接口说明 ：查询全部管理员用户和被下权限的管理员用户     查询admin用户和unAdmin用户
>接口地址 ：https://www.xiaochenya.xyz:8085/selectAllAdminAndUnAdmin
>输入参数 ：参数 { 
>
>​				无
>
>} 
>
>返回值 ：code=38			
>
>返回值说明 ：code=38		查询管理员和被下权限的管理员成功

**@PostMapping("/updateUserState")**

>接口说明 ：删除用户        superAdmin为超级管理员  admin为管理员  user为用户
>接口地址 ：https://www.xiaochenya.xyz:8085/updateUserState
>输入参数 ：formdata参数 { 
>
>​				"adminUserId":"管理员Id"
>
>​				"token":"token"
>
>​				"userId":"用户id"
>
>} 
>
>返回值 ：code=33		code=34		code=-20		code=-13
>
>返回值说明 ：code=33		超级管理员删除普通用户或管理员成功
>
>​								code=34		管理员删除普通用户成功
>
>​								code=-20		权限不允许
>
>​								code=-13		登录失效，请重新登录

**@GetMapping("/selectUserByUserName")**

>接口说明 ：like查询用户
>接口地址 ：https://www.xiaochenya.xyz:8085/selectUserByUserName
>输入参数 ：参数 { 
>
>​				'userName':'用户名'
>
>} 
>
>返回值 ：code=5  code=-19
>返回值说明 ：code=5		查询成功
>
>​								code=-19		查询失败 没有对应的用户

**@PostMapping("/selectAllUser")**

>接口说明 ：查询全部用户分页展示
>接口地址 ：https://www.xiaochenya.xyz:8085/selectAllUser
>输入参数 ：formdata参数 { 
>
>​				"page":"页数"
>
>} 
>
>返回值 ：code=5
>
>返回值说明 ：code=5		查询成功

**@PostMapping("/selectCommentId")**

>接口说明 ：根据userid查询用户喜欢和收藏的帖子id
>接口地址 ：https://www.xiaochenya.xyz:8085/selectCommentId
>
>输入参数 ：json对象参数 { 
>
>​				"userid":"id"
>
>​				} 
>
>返回值 ：code=19
>返回值说明 ：code=19:查询成功

**@PostMapping("/loginCheck")**

>接口说明 ：用户登录接口 
>接口地址 ：https://www.xiaochenya.xyz:8085/loginCheck  
>输入参数 ：JSON {
>
>​					 'usernameOrEmail' : '账户名称或者邮箱账号',
>
>​					'password' : '账户密码' 
>
>​				}  
>返回值 ：code =-5		code=3	&&	data	&&	token	&&	role
>返回值说明 ：code=-5:账号不存在或密码错误 登录失败
>
>​						code=3:登录成功	&&	data=user	&&	token	&&	role:用户权限

 **@PostMapping("/register")**

>接口说明 ：用户注册接口  
>接口地址 ：https://www.xiaochenya.xyz:8085/register  
>
>输入参数 ：JSON { 
>
>​				'username' : '账户名称',	
>
>​				'password' : '新账户密码'，
>
>​				’email‘:'账户想绑定的邮箱 邮箱必须写全 '，
>
>​				'captcha1':'点击发送验证码得到的验证码',
>
>​				'captcha2':'用户输入的验证码' 
>
>​				}
>
>返回值 ：code=0		code=-1		code=1	&&	data
>返回值说明 ：code=0:账号或者密码或者验证码或者邮箱为空 失败
>
>​						code=-1:该账号已经注册,用户已存在
>
>​						code=1:注册成功	&&	data:注册条数

**@PostMapping("changePassword")**

>接口说明 ：用户修改密码接口  
>接口地址 ：https://www.xiaochenya.xyz:8085/changePassword  
>输入参数 ：JSON { 
>
>​					'userid' : '账户id',
>
>​					'password' : '账户新密码' 
>
>​				}  
>返回值 ：code=2	&&	data		code=-2
>返回值说明 ：code=2:修改密码成功	&&	data:修改条数
>
>​						code=-2:修改密码失败 账号不存在

**@PostMapping("/forgetPassword")**

>接口说明 ：用户忘记密码接口  
>接口地址 ：https://www.xiaochenya.xyz:8085/forgetPassword  
>输入参数 ：JSON { 
>
>​				'username' : '账户名称',	
>
>​				'password' : '新账户密码'，
>
>​				’email‘:'账户想绑定的邮箱 邮箱必须写全'，
>
>​				'captcha1':'点击发送验证码得到的验证码',
>
>​				'captcha2':'用户输入的验证码' 
>
>​				} 
>
>返回值 ：code=0		code=-3		code=2	&&	data
>返回值说明 ：code=0:账号或者密码或者验证码或者邮箱为空 失败
>
>​						code=-3:账号不存在
>
>​						code=2:修改密码成功	&&	data=修改条数

 **@PostMapping("/verifyUsername")**

>接口说明 ：校验用户名按钮  
>接口地址 ：https://www.xiaochenya.xyz:8085/verifyUsername
>输入参数 ：JSON { 
>
>​				'username' : '用户名'
>
>​				} 
>
>返回值 ：code=1		code=-4
>返回值说明 ：code=1:账号不存在 可以注册   
>
>​						code=4 :账号已经存在 注册失败

 **@PostMapping("/verifyEmailAndSendEmail")**

>接口说明 ：校验邮箱并发送验证码  
>接口地址 ：https://www.xiaochenya.xyz:8085/verifyEmailAndSendEmail
>输入参数 ：JSON { 
>
>​				'email' : '邮箱'
>
>​				} 
>
>返回值 ：code=1&&msg	code=-1	code=-3
>返回值说明 ：code=1:发送成功&&msg:验证码  
>
>​								code=-1:邮箱格式错误
>
>​								code=-3:账号不存在

**@PostMapping("/beforeVerifyChangePassword")**

>接口说明 ：校验完成之后的修改密码
>接口地址 ：https://www.xiaochenya.xyz:8085/beforeVerifyChangePassword
>输入参数 ：JSON { 
>
>​				'email' : '邮箱'
>
>​				'password' : '密码'	
>
>​				} 
>
>返回值 ：code=-8		code=2
>返回值说明 ：code=-8:密码为空，请输入密码
>
>​								code=4:修改密码成功

**@PostMapping("/getUsernameAndEmail")**

>接口说明 ：校验完成之后的修改密码
>接口地址 ：https://www.xiaochenya.xyz:8085/getUsernameAndEmail
>输入参数 ：JSON { 
>
>​				'userid' : '用户id'	
>
>​				} 
>
>返回值 ：code=-9		code=5
>返回值说明 ：code=-9:查询失败，用户不存在								
>
>​								code=5:查询成功

**@GetMapping("/selectCountPlantTechniqueAndPathogeny")**

>接口说明 ：返回病因技巧的总数和种植技巧的总数
>接口地址 ：https://www.xiaochenya.xyz:8085/selectCountPlantTechniqueAndPathogeny
>输入参数 ：formdata参数 { 
>
>​				无
>
>} 
>
>返回值 ：		code=5		
>
>返回值说明 ：code=5		查询成功

#### 4.3 UserPortraitAddressController

 **@PostMapping("/addUserPortrait")**

>接口说明 ：上传头像
>接口地址 ：https://www.xiaochenya.xyz:8085/addUserPortrait
>
>输入参数 ：from data参数 { 
>
>​				'userId' : '用户Id'
>
>​				'files' : '头像路径'
>
>​				} 
>
>返回值 ：code=6   code=-11   code=-12
>返回值说明 ：code=6		上传成功
>
>​								code=-11	上传失败，用户不存在
>
>​								code=-12		上传失败,用户已经存在头像

#### 4.4 MsgSendController

  **@GetMapping("/qqMsgSend")**

>接口说明 ：发送邮箱验证码校验按钮  
>接口地址 ：https://www.xiaochenya.xyz:8085/qqMsgSend 
>输入参数 ：JSON { 
>
>​				'qq' : '邮箱'
>
>​				} 
>
>返回值 ：code=1	&&	data
>返回值说明 ：code=1:成功	&&	data=发送到邮箱的验证码
